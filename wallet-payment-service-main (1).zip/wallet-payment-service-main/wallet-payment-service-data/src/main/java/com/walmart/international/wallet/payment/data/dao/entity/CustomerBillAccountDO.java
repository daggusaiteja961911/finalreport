package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "CUSTOMER_BILL_ACCOUNT")
public class CustomerBillAccountDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "CUSTOMER_BILL_ACCOUNT_ID")
    private UUID customerBillAccountId;

    @ManyToOne(optional = false, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "BILLER_ID")
    private BillerDO billerDO;

    @Column(name = "PROCESSOR_BILLER_ID")
    private String processorBillerId;

    @Column(name = "CUSTOMER_ACCOUNT_ID")
    private UUID customerAccountId;

    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;

    @Column(name = "DUE_AMOUNT")
    private BigDecimal dueAmount;

    @Enumerated(EnumType.STRING)
    @Column(name = "DUE_AMOUNT_CURRENCY")
    private CurrencyUnit dueAmountCurrencyUnit;

    @Column(name = "LAST_PAID_AMOUNT")
    private BigDecimal lastPaidAmount;

    @Enumerated(EnumType.STRING)
    @Column(name = "LAST_PAID_AMOUNT_CURRENCY")
    private CurrencyUnit lastPaidAmountCurrencyUnit;

    @Column(name = "NUDGE_BUCKET")
    private String nudgeBucket;

    @Column(name = "IS_SAVED")
    private boolean isSaved;

    @Column(name = "IS_DELETED")
    private boolean isDeleted;

    @Column(name = "ALIAS")
    private String alias;

    @Column(name = "DUE_DATE")
    private Date dueDate;

    @Column(name = "LAST_PAID_DATE")
    private Date lastPaidDate;

    @Column(name = "DUE_INFO_UPDATED_AT")
    private Date dueInfoUpdatedAt;

    @Column(name = "DUE_INFO_UPDATED_BY")
    private String dueInfoUpdatedBy;

    @Column(name = "REVISED_ACCOUNT_NUMBER")
    private String revisedAccountNumber;

    @Column(name = "PROCESSOR_BILL_ACCOUNT_ID")
    private String processorBillAccountId;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "NAME_ON_ACCOUNT")
    private String nameOnAccount;

    @Column(name = "SKIP_REMINDER_TILL_DATE")
    private LocalDateTime skipReminderTillDate;
}
