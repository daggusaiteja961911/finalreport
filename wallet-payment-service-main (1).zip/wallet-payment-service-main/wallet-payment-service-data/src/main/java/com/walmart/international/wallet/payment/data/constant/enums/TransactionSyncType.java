package com.walmart.international.wallet.payment.data.constant.enums;

public enum TransactionSyncType {
    LOAD_MONEY,
    BILL_PAY
}
