package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionSubType;
import com.walmart.international.wallet.payment.data.helper.TxnOrderIdGenerator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@Slf4j
@Table(name = "BILL_PAY_TRANSACTION")
public class BillPayTransactionDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "BILL_PAY_TRANSACTION_ID")
    private UUID billPayTransactionId;

    @ManyToOne(optional = false, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "BILLER_ID")
    private BillerDO billerDO;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(name = "CURRENCY_UNIT")
    private CurrencyUnit currencyUnit;

    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;

    @Column(name = "CLIENT_REQ_ID")
    private String clientReqId;

    @Column(name = "CUSTOMER_ACCOUNT_ID")
    private UUID customerAccountId;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATE")
    private TransactionStateEnum state;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATE_REASON")
    private BillPayTxnStateReason stateReason;

    @Column(name = "ABORT_REASON")
    private String abortReason;

    @Column(name = "PROCESSOR_TRANSACTION_ID")
    private String processorTransactionId;

    @Column(name = "CASHI_ORDER_ID")
    private String cashiOrderId;

    @Column(name = "DEVICE_IP_ADDRESS")
    private String deviceIpAddress;

    @Column(name = "DEVICE_ID")
    private String deviceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BILL_DETAIL_ID")
    private BillDetailDO billDetailDO;

    @Column(name = "VENDOR_ID")
    private Integer vendorId;

    @Column(name = "HOURS_TO_FULFILL")
    private BigDecimal hoursToFulfill;

    @Column(name = "AUTH_TEXT")
    private String authText;

    @Column(name = "PIN")
    private String pin;

    @Column(name = "TXN_REQ_COMPLETED_DATE")
    private LocalDateTime txnReqCompletedDate;

    @Column(name = "LAST_EVENT_DATE")
    private LocalDateTime lastEventDate;

    public BillPayTransactionDO() {
        // The order id to be generated for every Wallet Txn.
        String cashiOrderId = null;
        try {
            cashiOrderId = TxnOrderIdGenerator.generateCashiOrderId(TransactionSubType.REGULAR);
        } catch (Exception exception) {
            log.error("Error while processing COF topup: [{}]", exception.getMessage());
        }
        this.cashiOrderId = cashiOrderId;
    }

    public void updateTxnReqCompletedDate() {
        this.txnReqCompletedDate = LocalDateTime.now();
    }

    public void updateLastEventDate() {
        this.lastEventDate = LocalDateTime.now();
    }
}
