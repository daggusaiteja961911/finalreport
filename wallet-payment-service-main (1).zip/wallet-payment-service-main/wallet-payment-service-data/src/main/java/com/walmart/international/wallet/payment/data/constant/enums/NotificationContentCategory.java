package com.walmart.international.wallet.payment.data.constant.enums;

public enum NotificationContentCategory {

    REMINDER, NUDGE

}
