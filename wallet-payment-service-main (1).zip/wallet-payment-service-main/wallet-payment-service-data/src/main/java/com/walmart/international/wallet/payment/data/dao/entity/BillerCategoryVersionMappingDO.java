package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "BILLER_CATEGORY_VERSION_MAPPING")
public class BillerCategoryVersionMappingDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "CATEGORY_VERSION_ID")
    private UUID categoryVersionId;

    @ManyToOne(optional = false, fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "CATEGORY_ID")
    private BillerCategoryDO billerCategory;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "billerCategoryVersionMapping")
    private List<BillerCategoryBillerMappingDO> billerCatgeoryMappings;

    @Column(name = "IMAGE_URL")
    private String imageUrl;

    @Column(name = "BILLER_CATEGORY_VERSION")
    private Integer billerCategoryVersion;

    @Column(name = "CATEGORY_ORDER")
    private int categoryOrder;

    @Column(name = "ENABLE")
    private boolean isEnabled;
}
