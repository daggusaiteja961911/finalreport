package com.walmart.international.wallet.payment.data.constant.enums;

public enum NotificationContentIdentifierType {
    BILLER_SEGMENT, BILLER_ID, TELCEL("13603");
    private String billerId;

    NotificationContentIdentifierType(String billerId) {
        this.billerId  = billerId;
    }

    NotificationContentIdentifierType() {
    }

    public String getBillerId() {
        return billerId;
    }
}
