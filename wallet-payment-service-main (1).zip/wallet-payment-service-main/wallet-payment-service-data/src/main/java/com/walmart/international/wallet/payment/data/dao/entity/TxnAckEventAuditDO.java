package com.walmart.international.wallet.payment.data.dao.entity;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
@DynamicUpdate
@Table(name = "TXN_ACK_EVENT_AUDIT")
public class TxnAckEventAuditDO {
    @Id
    @Column(name = "TXN_ID")
    private UUID transactionId;

    @Column(name = "LAST_ACK_DATE")
    private Date lastAckDate;

    @Column(name = "LAST_ACKD_EVENT_DESC")
    private String lastAcknowledgedEventDesc;
}
