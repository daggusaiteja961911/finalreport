package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.BaseEntity;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentCategory;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentIdentifierType;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentSubcategory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "NOTIFICATION_CONTENT")
public class NotificationContentDO extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "NOTIFICATION_CONTENT_ID")
    private UUID notificationContentId;

    @Column(name = "CATEGORY")
    @Enumerated(EnumType.STRING)
    private NotificationContentCategory category;

    @Column(name = "SUBCATEGORY")
    @Enumerated(EnumType.STRING)
    private NotificationContentSubcategory subcategory;

    @Column(name = "MESSAGE")
    private String message;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "NOTIFICATION_DAYS_COUNT")
    private Integer notificationDaysCount;

    @Column(name = "IDENTIFIER")
    private String identifier;

    @Column(name = "IDENTIFIER_TYPE")
    @Enumerated(EnumType.STRING)
    private NotificationContentIdentifierType identifierType;

}
