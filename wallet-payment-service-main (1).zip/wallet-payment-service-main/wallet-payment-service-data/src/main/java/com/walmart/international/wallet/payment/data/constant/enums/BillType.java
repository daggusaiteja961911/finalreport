package com.walmart.international.wallet.payment.data.constant.enums;

public enum BillType {

    ALL,
    DUE,
    PAID,
    OVERDUE
}