package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;
import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "BILL_DETAIL")
public class BillDetailDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "BILL_DETAIL_ID")
    private UUID billDetailId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BILL_PLAN_ID")
    private BillPlanDO billPlan;

    @Column(name = "BILL_AMOUNT")
    private BigDecimal billAmount;

    @Column(name = "ENABLE")
    private boolean isEnabled;

    @Column(name = "SEQ_NUMBER")
    private int appDisplaySequenceNumber;

    @Column(name = "NAME")
    private String name;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "DURATION")
    private int duration;

    @Column(name = "DURATION_UNIT")
    private String durationUnit;

    @Column(name = "VALIDITY")
    private String validity;

    @Column(name = "SOCIAL_MEDIA_ICONS")
    private String socialMediaIcons;
}
