package com.walmart.international.wallet.payment.data.constant.enums;

public enum TransactionType {
    BILL_PAY, COF_TOPUP, MERCHANT_PAY
}
