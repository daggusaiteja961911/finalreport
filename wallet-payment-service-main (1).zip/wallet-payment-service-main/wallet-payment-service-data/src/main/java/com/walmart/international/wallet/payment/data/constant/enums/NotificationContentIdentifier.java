package com.walmart.international.wallet.payment.data.constant.enums;

public enum NotificationContentIdentifier {
    S1, S2, S3, S4
}
