package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "BILLER_SEARCH")
public class BillerSearchDO extends CashiAudit {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "BILLER_SEARCH_ID")
    private UUID billerSearchId;

    @Column(name = "INCORRECT_KEYWORD")
    private String incorrectKeyword;

    @Column(name = "ENABLED")
    private boolean isEnabled;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "BILLERS_INCORRECT_KEYWORD_MAPPING", joinColumns = @JoinColumn(name = "BILLER_SEARCH_ID"), inverseJoinColumns = @JoinColumn(name = "BILLER_ID"))
    private List<BillerDO> billers;

}
