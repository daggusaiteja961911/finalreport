package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "BILLER_CATEGORY_BILLER_MAPPING")
public class BillerCategoryBillerMappingDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "CATEGORY_MAPPING_ID")
    private UUID billerCategoryMappingId;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "BILLER_ID")
    @NotFound(action = NotFoundAction.IGNORE)
    private BillerDO biller;

    @ManyToOne
    @JoinColumn(name = "CATEGORY_VERSION_ID", referencedColumnName = "CATEGORY_VERSION_ID")
    private BillerCategoryVersionMappingDO billerCategoryVersionMapping;

    @Column(name = "ENABLE")
    private boolean isEnabled;

    @Column(name = "SEQ_NUMBER")
    private int appDisplaySequenceNumber;
}
