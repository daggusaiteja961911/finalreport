package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionSubType;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionType;
import com.walmart.international.wallet.payment.data.helper.TxnOrderIdGenerator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@Slf4j
@Table(name = "COF_TOPUP_TRANSACTION")
public class CoFTopupTransactionDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "COF_TOPUP_TRANSACTION_ID")
    private UUID coFTopupTransactionId;

    @Column(name = "CUSTOMER_ACCOUNT_ID")
    private UUID customerAccountId;

    @Column(name = "AMOUNT_REQUESTED")
    private BigDecimal amountRequested;

    @Column(name = "AMOUNT_PROCESSED")
    private BigDecimal amountProcessed;

    @Enumerated(EnumType.STRING)
    @Column(name = "CURRENCY_UNIT")
    private CurrencyUnit currencyUnit;

    @Column(name = "CASHI_ORDER_ID")
    private String cashiOrderId;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATE")
    private TransactionStateEnum state;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATE_REASON")
    private CoFTopupTxnStateReason stateReason;

    @Column(name = "ABORT_REASON")
    private String abortReason;

    @Column(name = "TXN_REFERENCE_ID")
    private String txnReferenceId;

    @Column(name = "DEVICE_IP_ADDRESS")
    private String deviceIpAddress;

    @Column(name = "DEVICE_ID")
    private String deviceId;

    @Column(name = "CLIENT_REQ_ID")
    private String clientReqId;

    @Column(name = "LAST_EVENT_DATE")
    private Date lastEventDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "PARENT_TRANSACTION_TYPE")
    private TransactionType parentTransactionType;

    public CoFTopupTransactionDO() {
        // The order id to be generated for every Wallet Txn.
        String cashiOrderId = null;
        try {
            cashiOrderId = TxnOrderIdGenerator.generateCashiOrderId(TransactionSubType.REGULAR);
        } catch (Exception exception) {
            log.error("Error while processing COF topup: [{}]", exception.getMessage());
        }
        this.cashiOrderId = cashiOrderId;
    }

    public void updateLastEventDate() {
        this.lastEventDate = new Date();
    }
}