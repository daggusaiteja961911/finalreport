package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import com.walmart.international.wallet.payment.data.constant.enums.InputType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "BILLER")
public class BillerDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "BILLER_ID")
    private UUID billerId;

    @Column(name = "MIN_AMOUNT")
    private BigDecimal minAmount;

    @Column(name = "MAX_AMOUNT")
    private BigDecimal maxAmount;

    @Column(name = "SUPPORTS_PARTIAL_PAYMENTS")
    private Boolean supportsPartialPayments;

    @Column(name = "PARTIAL_MIN_AMOUNT")
    private BigDecimal partialMinAmount;

    @Column(name = "BILLER_NAME")
    private String billerName;

    @Column(name = "PROCESSOR")
    private String processor;

    @Column(name = "PROCESSOR_BILLER_ID", nullable = false)
    private String processorBillerId;

    @Column(name = "BILL_TYPE")
    private String billType;

    @Column(name = "BILLER_TYPE")
    private String billerType;

    @Column(name = "CAN_CHECK_BALANCE")
    private Boolean canCheckBalance;

    @Column(name = "PARTIAL_ACCEPT_ONLY_PESOS")
    private Boolean partialAcceptOnlyPesos;

    @Column(name = "PREPAID")
    private Boolean prepaid;

    @Column(name = "HOURS_TO_FULFILL")
    private Integer hoursToFulfill;

    @Column(name = "BILLER_ACCOUNT_NUMBER")
    private String billerAccountNumber;

    @Column(name = "VENDOR_ID")
    private Integer vendorId;

    @Column(name = "REDEEM_URL")
    private String redeemURL;

    @Column(name = "TERMS_AND_CONDITIONS")
    private String termsAndConditions;

    @Column(name = "INFORMATION")
    private String information;

    @Column(name = "METADATA")
    private byte[] metaData;

    @Column(name = "INPUT_TYPE")
    @Enumerated(EnumType.STRING)
    private InputType inputType = InputType.ALPHANUMERIC;

    @Column(name = "INPUT_PLACEHOLDER_TEXT")
    private String inputPlaceholderText;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARENT_BILLER_ID")
    private BillerDO parentBiller;

    //TODO fetch lazy instead.
    @OneToMany(mappedBy = "parentBiller", fetch = FetchType.EAGER)
    private List<BillerDO> subBillers;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "biller")
    private List<BillPlanDO> billPlans;

    @Column(name = "COMMISSION")
    private String commission;

    @Column(name = "PRODUCT_DISPLAY_NAME")
    private String productDisplayName;

    @Column(name = "COUNTRY")
    private String country;

    @Column(name = "CURRENCY")
    private String currency;

    @Column(name = "DISCLAIMER")
    private String disclaimer;

    @Column(name = "REDEEM_INSTRUCTIONS")
    private String redeemInstructions;

    @Column(name = "TOPUP_COMMISSION")
    private String topupCommission;

    @Column(name = "ARCUS_AUTH_KEY_VERSION")
    private int arcusAuthKeyVersion;

    @Column(name = "ENABLE")
    private Boolean enabled;

    @Column(name = "IMAGE_URL")
    private String imageURL;

    @Column(name = "DISPLAY_NAME")
    private String displayName;

    @Column(name = "TAGS")
    private String tags;

    @Column(name = "NEW_BILLER")
    private Boolean newBiller;

    @Column(name = "SUB_BILLER_SHOWN_AS_PRODUCT")
    private Boolean subBillerShownAsProduct;

    @Column(name = "SEQ_NUMBER")
    private int appDisplaySequenceNumber;

    @Column(name = "AVAILABLE_TOPUP_AMOUNTS")
    private String availableTopupAmount;

    @Column(name = "CUSTOM_AMOUNT_ENABLED")
    private Boolean customAmountEnabled;
    
    @Column(name = "POPULAR_BILLER_SEQUENCE_NUMBER")
    private int popularBillerSequenceNumber;
}
