package com.walmart.international.wallet.payment.data.dao.entity;

import com.walmart.international.digiwallet.service.web.rest.data.model.CashiAudit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "BILLER_CATEGORY")
public class BillerCategoryDO extends CashiAudit.Versioned {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "CATEGORY_ID")
    private UUID categoryId;

    @Column(name = "CATEGORY_NAME")
    private String categoryName;
}
