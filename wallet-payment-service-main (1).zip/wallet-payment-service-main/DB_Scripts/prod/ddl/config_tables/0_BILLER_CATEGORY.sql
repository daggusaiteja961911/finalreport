CREATE TABLE dbo.BILLER_CATEGORY (
    CATEGORY_ID varbinary(16) NOT NULL,
    CATEGORY_NAME varchar(255)  NULL,
    CREATE_DATE datetime2(0) NULL,
    UPDATE_DATE datetime2(0) NULL,
    CREATED_BY varchar(255)  NULL,
    UPDATED_BY varchar(255)  NULL,
    VERSION bigint DEFAULT 1 NOT NULL,
    CONSTRAINT BILLER_CATEGORY_PK PRIMARY KEY (CATEGORY_ID)
    );


/*
DECLARE  @dbEnv VARCHAR(50) = 'wallet-payment-service-stg',
         @dbName varchar(10) = 'udp',
         @dbVal varchar(100),
         @q_table varchar(max)

set @dbVal = concat('[',@dbEnv,'].',@dbName,'.')
print ''+@dbVal

set @q_table = '
drop table if exists '+@dbVal+'BILLER_CATEGORY_1;
create table '+@dbVal+'BILLER_CATEGORY_1 (
    CATEGORY_ID varbinary(16) NOT NULL,
    CATEGORY_NAME varchar(255)  NULL,
    CREATE_DATE datetime2(0) NULL,
    UPDATE_DATE datetime2(0) NULL,
    CREATED_BY varchar(255)  NULL,
    UPDATED_BY varchar(255)  NULL,
    VERSION bigint NULL,
    CONSTRAINT BILLER_CATEGORY_PK PRIMARY KEY (CATEGORY_ID)
    );'

print ''+@q_table;

exec (@q_table);
commit; */