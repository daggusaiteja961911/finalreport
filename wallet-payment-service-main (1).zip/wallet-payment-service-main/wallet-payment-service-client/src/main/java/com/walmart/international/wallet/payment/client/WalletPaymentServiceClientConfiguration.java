package com.walmart.international.wallet.payment.client;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;
import io.strati.ccm.utils.client.annotation.UseObjectMapper;

import java.util.Map;

@Configuration(configName = WalletPaymentServiceClientConfiguration.CCM_ENTRY_NAME)
public interface WalletPaymentServiceClientConfiguration {
    String CCM_ENTRY_NAME = "wallet-payment-service-client-config";
    @Property(propertyName = "wallet.service.base.url")
    String getBaseUrl();

    @UseObjectMapper
    @Property(propertyName = "wallet.service.headers")
    Map<String, String> getHeaders();
}
