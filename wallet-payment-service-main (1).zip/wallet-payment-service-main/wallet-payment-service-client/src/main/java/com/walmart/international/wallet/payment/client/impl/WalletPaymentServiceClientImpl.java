package com.walmart.international.wallet.payment.client.impl;

import com.walmart.international.services.digitalwallet.httpclient.service.HttpClient;
import com.walmart.international.wallet.payment.client.WalletPaymentServiceClient;
import com.walmart.international.wallet.payment.client.WalletPaymentServiceClientConfiguration;
import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
@Slf4j
public class WalletPaymentServiceClientImpl implements WalletPaymentServiceClient {

    @Autowired
    private HttpClient httpClient;

    @ManagedConfiguration
    private WalletPaymentServiceClientConfiguration walletPaymentServiceClientConfiguration;

    private static final String COF_TOPUP_URL = "%s/internal/services/cof/v1/topup";

    private static final String VALIDATE_COF_TOPUP_URL = "%s/internal/services/cof/v1/validate-topup";

    @Override
    public ResponseEntity<CoFTopupResponse> coFTopUp(CoFTopupRequest coFTopupRequest, HttpHeaders headers) {
        String url = String.format(COF_TOPUP_URL, walletPaymentServiceClientConfiguration.getBaseUrl());
        log.info("Calling Wallet Payment Service for CoF Topup with request:[{}]", coFTopupRequest);
        ResponseEntity<CoFTopupResponse> coFTopupResponseEntity = null;
        try {
            coFTopupResponseEntity = httpClient.post(url, null, headers, coFTopupRequest, CoFTopupResponse.class);
            log.info("Response:[{}] on calling CoF Topup with request:[{}]", coFTopupResponseEntity.getBody(), coFTopupRequest);
        } catch (Throwable e) {
            log.error("Error while calling CoF Topup with request:[{}]. Error message:[{}]", coFTopupRequest, e.getMessage(), e);
        }

        return coFTopupResponseEntity;
    }

    @Override
    public ValidateCoFTopupResponse validateCoFTopup(ValidateCoFTopupRequest validateCoFTopupRequest, HttpHeaders headers) {
        String url = String.format(VALIDATE_COF_TOPUP_URL, walletPaymentServiceClientConfiguration.getBaseUrl());
        log.info("Calling Wallet Payment Service for Validate CoF Topup with request:[{}]", validateCoFTopupRequest);
        ResponseEntity<ValidateCoFTopupResponse> validateCoFTopupResponseEntity = null;
        try {
            validateCoFTopupResponseEntity = httpClient.post(url, null, headers, validateCoFTopupRequest, ValidateCoFTopupResponse.class);
            log.info("Response:[{}] on calling Validate CoF Topup with request:[{}]", validateCoFTopupResponseEntity.getBody(), validateCoFTopupRequest);
        } catch (Throwable e) {
            log.error("Error while calling Validate CoF Topup with request:[{}]. Error message:[{}]", validateCoFTopupRequest, e.getMessage(), e);
        }
        if (validateCoFTopupResponseEntity == null || validateCoFTopupResponseEntity.getBody() == null) {
            return null;
        }
        return validateCoFTopupResponseEntity.getBody();
    }

    private HttpHeaders getWalletServiceHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("WM_QOS.CORRELATION_ID", MDC.get("WM_QOS.CORRELATION_ID"));
        return headers;
    }
}
