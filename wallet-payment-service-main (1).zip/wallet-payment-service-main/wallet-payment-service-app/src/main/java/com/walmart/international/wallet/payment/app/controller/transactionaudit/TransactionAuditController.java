package com.walmart.international.wallet.payment.app.controller.transactionaudit;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.transaction.audit.TransactionAckRequest;
import com.walmart.international.wallet.payment.dto.request.transaction.audit.TransactionSyncRequest;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnAckResponse;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnSyncResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/services/transaction/audit")
@Tag(name = "Transaction Audit API", description = "APIs to perform Transaction Audit activities.")
public interface TransactionAuditController {

    @PostMapping(value = "/v2/transactions/sync", consumes = "application/json", produces = "application/json")
    TxnSyncResponse transactionSync(@RequestBody TransactionSyncRequest transactionSyncRequest,
                                    @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v2/transaction/ack", consumes = "application/json", produces = "application/json")
    TxnAckResponse acknowledgeTransactionFromTAS(@RequestBody TransactionAckRequest transactionAckRequest,
                                                 @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;


}
