package com.walmart.international.wallet.payment.app.config;


import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.AnnotationIntrospectorPair;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;
import com.walmart.international.digiwallet.service.strati.telemetry.filter.WebClientMetricsFilter;
import com.walmart.international.digiwallet.service.web.rest.logging.WebClientLoggingFilter;
import com.walmart.international.services.digitalwallet.httpclient.config.HttpCircuitBreakerConfig;
import com.walmart.platform.txn.webclient.filter.SpringWebClientTxnMarkingExchangeFilterFunction;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.tunr.utils.client.ServiceConfigClientFactory;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.HttpProxy;
import org.eclipse.jetty.client.ProxyConfiguration;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.reactive.JettyClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.TimeoutException;

import static com.walmart.international.digiwallet.service.basic.constants.CommonConstant.CORRELATION_ID;
import static com.walmart.international.digiwallet.service.basic.constants.CommonConstant.DEFAULT_VALUE;

@Slf4j
@Configuration
public class WebClientWithProxyConfig {

    private static final int DEFAULT_HTTP_PROXY_PORT = 8080;
    private static final String DEFAULT_HTTP_PROXY_HOST = "sysproxy.wal-mart.com";
    @ManagedConfiguration
    private static HttpCircuitBreakerConfig circuitBreakerConfig;
    @Autowired
    WebClientLoggingFilter webClientLoggingFilter;
    @Autowired
    WebClientMetricsFilter webClientMetricsFilter;

    @Bean("webClientWithProxy")
    @Primary
    public WebClient webClient() {
        HttpClient httpClient = webClientLoggingFilter.getHttpClient();
        ProxyConfiguration proxyConfiguration = httpClient.getProxyConfiguration();
        HttpProxy httpProxy = getHttpProxyFromSystemProperties();
        proxyConfiguration.getProxies().add(httpProxy);
        httpClient.setFollowRedirects(false);
        return WebClient.builder()
                .exchangeStrategies(getExchangeStrategies())
                .clientConnector(new JettyClientHttpConnector(httpClient))
                .filter(headerProcessor())
                .filter(webClientMetricsFilter.requestMetricsfilter())
                .filter(webClientMetricsFilter.responseMetricsFilter())
                .filter(SpringWebClientTxnMarkingExchangeFilterFunction.create())
                .build();
    }
    @NotNull
    private static HttpProxy getHttpProxyFromSystemProperties() {
        String httpProxyHost = System.getProperty("http.proxyHost", DEFAULT_HTTP_PROXY_HOST);
        String httpProxyPort = System.getProperty("http.proxyPort");
        int httpProxyPortNumber = DEFAULT_HTTP_PROXY_PORT;
        if (Objects.nonNull(httpProxyHost)) {
            try {
                httpProxyPortNumber = Integer.parseInt(httpProxyPort);
            } catch (NumberFormatException e) {
                log.warn("Unable to parse http.proxyPort:{}", httpProxyPort);
                httpProxyPortNumber = DEFAULT_HTTP_PROXY_PORT;
            }
        }
        HttpProxy httpProxy = new HttpProxy(httpProxyHost, httpProxyPortNumber);
        String nonProxyHosts = System.getProperty("http.nonProxyHosts");
        if (Objects.nonNull(nonProxyHosts) && !nonProxyHosts.isBlank()) {
            httpProxy.getExcludedAddresses().addAll(Arrays.asList(nonProxyHosts.split("|")));
        }
        return httpProxy;
    }

    private ExchangeStrategies getExchangeStrategies() {
        ObjectMapper mapper = new ObjectMapper();
        AnnotationIntrospector jaxbAnnotationIntrospector =
                new JaxbAnnotationIntrospector(mapper.getTypeFactory());
        AnnotationIntrospector jacksonAnnotationIntrospector = new JacksonAnnotationIntrospector();
        AnnotationIntrospector annotationIntrospector = new AnnotationIntrospectorPair(jacksonAnnotationIntrospector, jaxbAnnotationIntrospector);
        mapper.setAnnotationIntrospector(annotationIntrospector);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JavaTimeModule());

        return ExchangeStrategies.builder()
                .codecs(configurer -> {
                    configurer.defaultCodecs().jackson2JsonEncoder(new Jackson2JsonEncoder(mapper));
                    configurer.defaultCodecs().jackson2JsonDecoder(new Jackson2JsonDecoder(mapper));
                })
                .build();
    }

    private ExchangeFilterFunction headerProcessor() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            webClientLoggingFilter.setCorrelationId((clientRequest.headers().containsKey(CORRELATION_ID) ?
                    clientRequest.headers().get(CORRELATION_ID).get(0) :
                    DEFAULT_VALUE));

            return (clientRequest.headers().containsKey("WM_SVC.NAME")) ?
                    Mono.just(clientRequest) :
                    Mono.just(ClientRequest.from(clientRequest).header("WM_SVC.NAME", DEFAULT_VALUE).build());
        });
    }

    public static CircuitBreaker defaultCircuitBreaker() {
        if (circuitBreakerConfig == null) {
            log.warn("Setting Circuit-Breaker-config via service config client factory!");
            circuitBreakerConfig = ServiceConfigClientFactory.getInstance()
                    .getServiceConfigVersionCache()
                    .getResolvedConfiguration("circuit-breaker-config", HttpCircuitBreakerConfig.class, null);
        }
        log.info("Creating Circuit breaker config with default config values");
        io.github.resilience4j.circuitbreaker.CircuitBreakerConfig circuitBreakerConfiguration = io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.custom()
                .failureRateThreshold(circuitBreakerConfig.getFailureRateThreshold())
                .slowCallRateThreshold(circuitBreakerConfig.getSlowCallRateThreshold())
                .slowCallDurationThreshold(Duration.ofMillis(circuitBreakerConfig.getSlowCallDurationThreshold()))
                .minimumNumberOfCalls(circuitBreakerConfig.getMinimumNumberOfCalls())
                .permittedNumberOfCallsInHalfOpenState(circuitBreakerConfig.getPermittedNumberOfCallsInHalfOpenState())
                .waitDurationInOpenState(Duration.ofMillis(circuitBreakerConfig.getWaitDurationInOpenState()))
                .automaticTransitionFromOpenToHalfOpenEnabled(circuitBreakerConfig.getAutomaticTransitionFromOpenToHalfOpenEnabled())
                .slidingWindowType(io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.SlidingWindowType.valueOf(circuitBreakerConfig.getSlidingWindowType()))
                .slidingWindowSize(circuitBreakerConfig.getSlidingWindowSize())
                .recordException(e -> e.getCause() instanceof TimeoutException || e.getCause() instanceof SocketTimeoutException ||
                        e.getCause() instanceof SocketException)
                .recordResult(response -> ((ResponseEntity) response).getStatusCode().is5xxServerError())
                .build();
        log.info("Default circuit breaker config {}", circuitBreakerConfiguration);
        CircuitBreakerRegistry circuitBreakerRegistry =
                CircuitBreakerRegistry.of(circuitBreakerConfiguration);
        return circuitBreakerRegistry.circuitBreaker("resilienceCircuitBreaker");
    }
}

