package com.walmart.international.wallet.payment.app.controller.topup;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.topup.CancelCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.FetchCoFTopupPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.response.topup.CancelCoFTopUpResponse;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@RequestMapping(value = {"/services/cof", "/internal/services/cof"})
@Tag(name = "CoFTopupController API", description = "APIs to perform CoF Topup related activities.")
public interface CoFTopupController {
    @PostMapping(value = "/v1/topup", consumes = "application/json", produces = "application/json")
    CoFTopupResponse coFTopup(@RequestBody @Valid CoFTopupRequest cofTopupRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v1/topup/abort", consumes = "application/json", produces = "application/json")
    CancelCoFTopUpResponse cancelCoFTopup(@RequestBody CancelCoFTopupRequest cancelCoFTopupRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @GetMapping(value = "/v1/options", consumes = "application/json", produces = "application/json")
    FetchCoFTopupPaymentInstrumentsResponse fetchCoFTopupPaymentInstruments(@RequestBody @Valid FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @GetMapping(value = "/v2/options", consumes = "application/json", produces = "application/json")
    FetchCoFTopupPaymentInstrumentsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(@RequestBody @Valid FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v1/validate-topup", consumes = "application/json", produces = "application/json")
    ValidateCoFTopupResponse validateCoFTopup(@RequestBody ValidateCoFTopupRequest validateCoFTopupRequest,
                                              @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;
}
