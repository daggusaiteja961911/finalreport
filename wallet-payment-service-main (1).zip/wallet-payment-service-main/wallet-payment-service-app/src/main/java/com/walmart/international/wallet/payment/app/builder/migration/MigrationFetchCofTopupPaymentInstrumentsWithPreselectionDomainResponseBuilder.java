package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationCoFTopupMapper;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.PaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.PaymentPreferenceDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class MigrationFetchCofTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder extends BaseDomainResponseBuilder<FetchPaymentOptionsWithPreselectionResponse, CoFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext> {

    private MigrationCoFTopupMapper migrationCofTopupMapper = MigrationCoFTopupMapper.INSTANCE;
    @Override
    public CoFTopupTxnResponseDomainContext buildDomainResponse(CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext) throws ApplicationException {
        return CoFTopupTxnResponseDomainContext.builder().build();
    }

    @Override
    public FetchPaymentOptionsWithPreselectionResponse buildDomainResponse(CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext cofTopupTxnResponseDomainContext) throws ApplicationException {
        List<PaymentInstrument> paymentInstrumentList = cofTopupTxnResponseDomainContext.getTransaction().getCofTopupPaymentOptions().getPaymentInstruments().getPaymentInstrumentList();
        List<PaymentPreferenceDTO> paymentPreferenceDTOs = paymentInstrumentList.stream().map(instrument -> {
            if (instrument instanceof CardPaymentInstrument) {
                return migrationCofTopupMapper.mapCardPaymentInstrumentToPaymentPreferenceDTO((CardPaymentInstrument) instrument);
            }
            return null;
        }).collect(Collectors.toList());

        return FetchPaymentOptionsWithPreselectionResponse.builder()
                .paymentOptions(paymentPreferenceDTOs)
                .build();
    }
}
