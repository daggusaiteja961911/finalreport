package com.walmart.international.wallet.payment.app.service.impl.mapper;

import com.walmart.international.wallet.payment.core.domain.model.request.AlreadyPaidRequest;
import com.walmart.international.wallet.payment.core.domain.model.response.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.dto.request.billpay.AlreadyPaidRequestDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.AlreadyPaidResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AlreadyPaidMapper {

    AlreadyPaidMapper INSTANCE = Mappers.getMapper(AlreadyPaidMapper.class);

    AlreadyPaidRequest mapAlreadyPaidRequestDTOToDomainRequest(AlreadyPaidRequestDTO alreadyPaidRequestDTO);

    AlreadyPaidResponseDTO mapAlreadyPaidResponseFromDomainResponseToDTO(AlreadyPaidResponse alreadyPaidResponse);

}
