package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.Transaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class CancelPayBillInitTransactionDomainRequestBuilder extends BaseDomainRequestBuilder<CancelPayBillInitRequest, BillPayTxnRequestDomainContext> {
    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(CancelPayBillInitRequest cancelPayBillInitRequest, MultiValueMap<String, String> headers, Tenant tenant) {
        Customer customer = Customer.builder()
                .customerAccountId(cancelPayBillInitRequest.getCustomerAccountId())
                .build();

        Transaction transaction = Transaction.builder()
                .transactionId(cancelPayBillInitRequest.getTransactionId())
                .transactionType(TransactionType.BILL_PAY)
                .abortReason(cancelPayBillInitRequest.getAbortReason())
                .customer(customer)
                .build();

        return BillPayTxnRequestDomainContext.builder()
                .transaction(transaction)
                .headers(headers)
                .build();
    }
}
