package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
public class CoFTopupFlowFactory extends FlowFactory<CoFTopupTxnRequestDomainContext> {

    @Override
    public FlowType deriveFlow(CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext, Tenant tenant) {
        switch (tenant) {
            case MX:
                return deriveTopupFlowforMexico(cofTopupTxnRequestDomainContext);
            case CA:
            case UNKNOWN:
            default:
                break;
        }
        return null;
    }

    private FlowType deriveTopupFlowforMexico(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) {
        UUID transactionId = coFTopupTxnRequestDomainContext.getTransaction().getTransactionId();
        Optional<UUID> oCardSubTransactionId = coFTopupTxnRequestDomainContext.getTransaction().getCardSubTransactionId();
        if (Objects.nonNull(transactionId) || oCardSubTransactionId.isPresent()) {
            return MXFlowType.VALIDATE_COF_TOPUP;
        }
        return MXFlowType.COF_TOPUP;
    }
}
