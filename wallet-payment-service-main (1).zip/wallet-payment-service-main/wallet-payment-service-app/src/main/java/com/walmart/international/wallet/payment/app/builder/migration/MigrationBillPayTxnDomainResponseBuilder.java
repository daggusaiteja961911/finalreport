package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationBillPayMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.migration.PayInitResponseEWS;
import org.springframework.stereotype.Component;

@Component
public class MigrationBillPayTxnDomainResponseBuilder extends BaseDomainResponseBuilder<PayInitResponseEWS, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {

    private MigrationBillPayMapper migrationBillPayMapper = MigrationBillPayMapper.INSTANCE;

    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) throws ApplicationException {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public PayInitResponseEWS buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) throws ApplicationException {
        return migrationBillPayMapper.mapToMigrationPayInitResponseEWSFromContext(billPayTxnResponseDomainContext);
    }
}
