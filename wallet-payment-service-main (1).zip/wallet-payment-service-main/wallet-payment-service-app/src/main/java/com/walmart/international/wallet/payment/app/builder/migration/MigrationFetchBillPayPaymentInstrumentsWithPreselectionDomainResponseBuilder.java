package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationBillPayMapper;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.PaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.PaymentPreferenceDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class MigrationFetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder extends BaseDomainResponseBuilder<FetchPaymentOptionsWithPreselectionResponse, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {

    MigrationBillPayMapper billPayMapper = MigrationBillPayMapper.INSTANCE;

    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public FetchPaymentOptionsWithPreselectionResponse buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        List<PaymentInstrument> paymentInstrumentList = billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getPaymentInstruments().getPaymentInstrumentList();
        List<PaymentPreferenceDTO> paymentPreferenceDTOs = paymentInstrumentList.stream().map(instrument -> {
            if (instrument instanceof CardPaymentInstrument) {
                return billPayMapper.mapCardPaymentInstrumentToPaymentPreferenceDTO((CardPaymentInstrument) instrument);
            } else if (instrument instanceof GiftCardPaymentInstrument) {
                return billPayMapper.mapGiftCardPaymentInstrumentToPaymentPreferenceDTO((GiftCardPaymentInstrument) instrument);
            }
            return null;
        }).collect(Collectors.toList());

        return FetchPaymentOptionsWithPreselectionResponse.builder()
                .transaction(billPayMapper.mapTransactionToTransactionDTO(billPayTxnResponseDomainContext.getTransaction()))
                .paymentOptions(paymentPreferenceDTOs)
                .isMSIAllowedForSplit(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getIsMSIAllowedForSplitPayment())
                .allowCoFBillPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowCoFForBillPayment())
                .allowB2BSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowB2BForSplitPayment())
                .allowMultipleB2BSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowMultipleB2BForSplitPayment()).build();
    }
}