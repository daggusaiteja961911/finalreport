package com.walmart.international.wallet.payment.app.router;

import com.google.common.collect.ImmutableMap;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.DomainContextTemplate;
import com.walmart.international.digiwallet.service.flow.builder.FlowBuilder;
import com.walmart.international.wallet.payment.app.builder.CoFTopupTxnDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.CreateBillDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.CreateBillDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.FetchBillPayPaymentInstrumentsDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.FetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.FetchCoFTopupPaymentInstrumentsDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.FetchCoFTopupPaymentInstrumentsDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.ValidateCoFTopupTxnDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.ValidateCoFTopupTxnDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationBillPayTxnDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationBillPayTxnDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCancelCoFTopupTransactionDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCancelCoFTopupTransactionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCancelPayBillInitTransactionDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCancelPayBillInitTransactionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCoFTopupTxnDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCoFTopupTxnDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCreateBillDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationCreateBillDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationFetchBillPayPaymentInstrumentsDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationFetchBillPayPaymentInstrumentsDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationFetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationFetchCoFTopupPaymentInstrumentsDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationFetchCoFTopupPaymentInstrumentsDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationFetchCofTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationUpdateCustomerBillAccountDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationUpdateCustomerBillAccountDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationValidateCoFTopupTxnDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationValidateChargeInitDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.MigrationValidateChargeInitDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.flowfactory.BillPayFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.CancelCoFTopupTransactionFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.CancelPayBillInitTransactionFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.CoFTopupFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.CreateBillFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.FetchBillPayPaymentInstrumentsFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.FetchBillPayPaymentInstrumentsWithPreselectionFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.FetchCoFTopupPaymentInstrumentsFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.FetchCoFTopupPaymentInstrumentsWithPreselectionFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.UpdateCustomerBillAccountFlowFactory;
import com.walmart.international.wallet.payment.app.flowfactory.ValidateChargeInitFlowFactory;
import com.walmart.international.wallet.payment.app.builder.CancelCoFTopupTransactionDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.CancelCoFTopupTransactionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.CancelPayBillInitTransactionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.CancelPayBillInitTransactionDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.CoFTopupTxnDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.FetchBillPayPaymentInstrumentsDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.FetchCoFTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.UpdateCustomerBillAccountDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.UpdateCustomerBillAccountDomainResponseBuilder;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.request.migration.CancelPayBillInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.CancelCoFTopupRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.CreateBillRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.FetchBillPayPaymentInstrumentsRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.FetchCoFTopupPaymentInstrumentsRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.LoadMoneyRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.PayInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.topup.CancelCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeRequestEWS;
import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.FetchCoFTopupPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.CreateBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.dto.response.migration.CancelCoFTopupResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelPayBillInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CreateBillV2DTO;
import com.walmart.international.wallet.payment.dto.response.migration.FetchBillPayPaymentInstrumentsResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.PayInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountResponseDTO;
import com.walmart.international.wallet.payment.dto.response.migration.UnifiedPaymentResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UpdateSavedBillerAccountRequest;
import com.walmart.international.wallet.payment.dto.response.migration.ValidateChargeInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.topup.CancelCoFTopUpResponse;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import javax.annotation.PostConstruct;
import java.util.Map;

@Component
public class WalletServiceRouter {

    public enum Functionality {
        COF_TOPUP, MIGRATION_COF_TOPUP,
        VALIDATE_COF_TOPUP, MIGRATION_VALIDATE_COF_TOPUP,
        CANCEL_COF_TOPUP, MIGRATION_CANCEL_COF_TOPUP,
        BILL_PAYMENT, PAY_BILL_INIT, MIGRATION_PAY_BILL_INIT, MIGRATION_VALIDATE_CHARGE_INIT,
        CANCEL_PAY_BILL_INIT, MIGRATION_CANCEL_PAY_BILL_INIT,
        UPDATE_CUSTOMER_BILL_ACCOUNT, MIGRATION_UPDATE_CUSTOMER_BILL_ACCOUNT,
        CREATE_BILL, MIGRATION_CREATE_BILL,
        FETCH_COFTOPUP_PAYMENT_INSTRUMENTS, MIGRATION_FETCH_COFTOPUP_PAYMENT_INSTRUMENTS, FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION, MIGRATION_FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION,
        FETCH_BILL_PAY_PAYMENT_INSTRUMENTS, MIGRATION_FETCH_BILL_PAY_PAYMENT_INSTRUMENTS, FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION, MIGRATION_FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION
    }

    @Autowired
    CoFTopupTxnDomainRequestBuilder coFTopupTxnDomainRequestBuilder;
    @Autowired
    CoFTopupTxnDomainResponseBuilder coFTopupTxnDomainResponseBuilder;
    @Autowired
    MigrationCoFTopupTxnDomainRequestBuilder migrationCoFTopupTxnDomainRequestBuilder;
    @Autowired
    MigrationCoFTopupTxnDomainResponseBuilder migrationCoFTopupTxnDomainResponseBuilder;
    @Autowired
    ValidateCoFTopupTxnDomainRequestBuilder validateCoFTopupTxnDomainRequestBuilder;
    @Autowired
    ValidateCoFTopupTxnDomainResponseBuilder validateCoFTopupTxnDomainResponseBuilder;
    @Autowired
    MigrationValidateCoFTopupTxnDomainRequestBuilder migrationValidateCoFTopupTxnDomainRequestBuilder;
    @Autowired
    CoFTopupFlowFactory coFTopupFlowFactory;

    @Autowired
    MigrationBillPayTxnDomainRequestBuilder migrationBillPayTxnDomainRequestBuilder;
    @Autowired
    MigrationBillPayTxnDomainResponseBuilder migrationBillPayTxnDomainResponseBuilder;
    @Autowired
    BillPayFlowFactory billPayFlowFactory;

    @Autowired
    MigrationValidateChargeInitDomainRequestBuilder migrationValidateChargeInitDomainRequestBuilder;

    @Autowired
    MigrationValidateChargeInitDomainResponseBuilder migrationValidateChargeInitDomainResponseBuilder;

    @Autowired
    ValidateChargeInitFlowFactory validateChargeInitFlowFactory;

    @Autowired
    CancelCoFTopupTransactionDomainRequestBuilder cancelCoFTopupTransactionDomainRequestBuilder;
    @Autowired
    CancelCoFTopupTransactionDomainResponseBuilder cancelCoFTopupTransactionDomainResponseBuilder;
    @Autowired
    MigrationCancelCoFTopupTransactionDomainRequestBuilder migrationCancelCoFTopupTransactionDomainRequestBuilder;
    @Autowired
    MigrationCancelCoFTopupTransactionDomainResponseBuilder migrationCancelCoFTopupTransactionDomainResponseBuilder;
    @Autowired
    CancelCoFTopupTransactionFlowFactory cancelCoFTopupTransactionFlowFactory;

    @Autowired
    CancelPayBillInitTransactionDomainRequestBuilder cancelPayBillInitTransactionDomainRequestBuilder;
    @Autowired
    CancelPayBillInitTransactionDomainResponseBuilder cancelPayBillInitTransactionDomainResponseBuilder;
    @Autowired
    MigrationCancelPayBillInitTransactionDomainRequestBuilder migrationCancelPayBillInitTransactionDomainRequestBuilder;
    @Autowired
    MigrationCancelPayBillInitTransactionDomainResponseBuilder migrationCancelPayBillInitTransactionDomainResponseBuilder;
    @Autowired
    CancelPayBillInitTransactionFlowFactory cancelPayBillInitTransactionFlowFactory;

    @Autowired
    FetchBillPayPaymentInstrumentsDomainRequestBuilder fetchBillPayPaymentInstrumentsDomainRequestBuilder;
    @Autowired
    FetchBillPayPaymentInstrumentsDomainResponseBuilder fetchBillPayPaymentInstrumentsDomainResponseBuilder;
    @Autowired
    FetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder fetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder;
    @Autowired
    MigrationFetchBillPayPaymentInstrumentsDomainRequestBuilder migrationFetchBillPayPaymentInstrumentsDomainRequestBuilder;
    @Autowired
    MigrationFetchBillPayPaymentInstrumentsDomainResponseBuilder migrationFetchBillPayPaymentInstrumentsDomainResponseBuilder;
    @Autowired
    FetchBillPayPaymentInstrumentsFlowFactory fetchBillPayPaymentInstrumentsFlowFactory;

    @Autowired
    UpdateCustomerBillAccountDomainRequestBuilder updateCustomerBillAccountDomainRequestBuilder;
    @Autowired
    UpdateCustomerBillAccountDomainResponseBuilder updateCustomerBillAccountDomainResponseBuilder;
    @Autowired
    MigrationUpdateCustomerBillAccountDomainRequestBuilder migrationUpdateCustomerBillAccountDomainRequestBuilder;
    @Autowired
    MigrationUpdateCustomerBillAccountDomainResponseBuilder migrationUpdateCustomerBillAccountDomainResponseBuilder;
    @Autowired
    UpdateCustomerBillAccountFlowFactory updateCustomerBillAccountFlowFactory;

    @Autowired
    CreateBillDomainRequestBuilder createBillDomainRequestBuilder;
    @Autowired
    CreateBillDomainResponseBuilder createBillDomainResponseBuilder;
    @Autowired
    MigrationCreateBillDomainRequestBuilder migrationCreateBillDomainRequestBuilder;
    @Autowired
    MigrationCreateBillDomainResponseBuilder migrationCreateBillDomainResponseBuilder;
    @Autowired
    CreateBillFlowFactory createBillFlowFactory;

    @Autowired
    FetchCoFTopupPaymentInstrumentsDomainRequestBuilder fetchCoFTopupPaymentInstrumentsDomainRequestBuilder;
    @Autowired
    FetchCoFTopupPaymentInstrumentsDomainResponseBuilder fetchCoFTopupPaymentInstrumentsDomainResponseBuilder;
    @Autowired
    FetchCoFTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder fetchCoFTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder;
    @Autowired
    MigrationFetchCoFTopupPaymentInstrumentsDomainRequestBuilder migrationFetchCoFTopupPaymentInstrumentsDomainRequestBuilder;
    @Autowired
    MigrationFetchCoFTopupPaymentInstrumentsDomainResponseBuilder migrationFetchCoFTopupPaymentInstrumentsDomainResponseBuilder;
    @Autowired
    FetchCoFTopupPaymentInstrumentsFlowFactory fetchCoFTopupPaymentInstrumentsFlowFactory;
    @Autowired
    FetchCoFTopupPaymentInstrumentsWithPreselectionFlowFactory fetchCoFTopupPaymentInstrumentsWithPreselectionFlowFactory;
    @Autowired
    FetchBillPayPaymentInstrumentsWithPreselectionFlowFactory fetchBillPayPaymentInstrumentsWithPreselectionFlowFactory;
    @Autowired
    MigrationFetchCofTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder migrationFetchCofTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder;
    @Autowired
    MigrationFetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder migrationFetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder;
    @Autowired
    FlowBuilder flowBuilder;

    Map<Functionality, DomainContextTemplate> domainTemplateMap;

    @PostConstruct
    public void buildMap() {
        domainTemplateMap = ImmutableMap
                .<Functionality, DomainContextTemplate>builder()
                .put(Functionality.COF_TOPUP,
                        DomainContextTemplate.of(coFTopupTxnDomainRequestBuilder, coFTopupTxnDomainResponseBuilder, coFTopupFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_COF_TOPUP,
                        DomainContextTemplate.of(migrationCoFTopupTxnDomainRequestBuilder, migrationCoFTopupTxnDomainResponseBuilder, coFTopupFlowFactory, flowBuilder))
                .put(Functionality.VALIDATE_COF_TOPUP,
                        DomainContextTemplate.of(validateCoFTopupTxnDomainRequestBuilder, validateCoFTopupTxnDomainResponseBuilder, coFTopupFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_VALIDATE_COF_TOPUP,
                        DomainContextTemplate.of(migrationValidateCoFTopupTxnDomainRequestBuilder, migrationCoFTopupTxnDomainResponseBuilder, coFTopupFlowFactory, flowBuilder))
                .put(Functionality.CANCEL_COF_TOPUP,
                        DomainContextTemplate.of(cancelCoFTopupTransactionDomainRequestBuilder, cancelCoFTopupTransactionDomainResponseBuilder, cancelCoFTopupTransactionFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_CANCEL_COF_TOPUP,
                        DomainContextTemplate.of(migrationCancelCoFTopupTransactionDomainRequestBuilder, migrationCancelCoFTopupTransactionDomainResponseBuilder, cancelCoFTopupTransactionFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_PAY_BILL_INIT,
                        DomainContextTemplate.of(migrationBillPayTxnDomainRequestBuilder, migrationBillPayTxnDomainResponseBuilder, billPayFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_VALIDATE_CHARGE_INIT,
                        DomainContextTemplate.of(migrationValidateChargeInitDomainRequestBuilder, migrationValidateChargeInitDomainResponseBuilder, validateChargeInitFlowFactory, flowBuilder))
                .put(Functionality.CANCEL_PAY_BILL_INIT,
                        DomainContextTemplate.of(cancelPayBillInitTransactionDomainRequestBuilder, cancelPayBillInitTransactionDomainResponseBuilder, cancelPayBillInitTransactionFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_CANCEL_PAY_BILL_INIT,
                        DomainContextTemplate.of(migrationCancelPayBillInitTransactionDomainRequestBuilder, migrationCancelPayBillInitTransactionDomainResponseBuilder, cancelPayBillInitTransactionFlowFactory, flowBuilder))
                .put(Functionality.UPDATE_CUSTOMER_BILL_ACCOUNT,
                        DomainContextTemplate.of(updateCustomerBillAccountDomainRequestBuilder, updateCustomerBillAccountDomainResponseBuilder, updateCustomerBillAccountFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_UPDATE_CUSTOMER_BILL_ACCOUNT,
                        DomainContextTemplate.of(migrationUpdateCustomerBillAccountDomainRequestBuilder, migrationUpdateCustomerBillAccountDomainResponseBuilder, updateCustomerBillAccountFlowFactory, flowBuilder))
                .put(Functionality.CREATE_BILL,
                        DomainContextTemplate.of(createBillDomainRequestBuilder, createBillDomainResponseBuilder, createBillFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_CREATE_BILL,
                        DomainContextTemplate.of(migrationCreateBillDomainRequestBuilder, migrationCreateBillDomainResponseBuilder, createBillFlowFactory, flowBuilder))
                .put(Functionality.FETCH_COFTOPUP_PAYMENT_INSTRUMENTS,
                        DomainContextTemplate.of(fetchCoFTopupPaymentInstrumentsDomainRequestBuilder, fetchCoFTopupPaymentInstrumentsDomainResponseBuilder, fetchCoFTopupPaymentInstrumentsFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_FETCH_COFTOPUP_PAYMENT_INSTRUMENTS,
                        DomainContextTemplate.of(migrationFetchCoFTopupPaymentInstrumentsDomainRequestBuilder, migrationFetchCoFTopupPaymentInstrumentsDomainResponseBuilder, fetchCoFTopupPaymentInstrumentsFlowFactory, flowBuilder))
                .put(Functionality.FETCH_BILL_PAY_PAYMENT_INSTRUMENTS,
                        DomainContextTemplate.of(fetchBillPayPaymentInstrumentsDomainRequestBuilder, fetchBillPayPaymentInstrumentsDomainResponseBuilder, fetchBillPayPaymentInstrumentsFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_FETCH_BILL_PAY_PAYMENT_INSTRUMENTS,
                        DomainContextTemplate.of(migrationFetchBillPayPaymentInstrumentsDomainRequestBuilder, migrationFetchBillPayPaymentInstrumentsDomainResponseBuilder, fetchBillPayPaymentInstrumentsFlowFactory, flowBuilder))
                .put(Functionality.FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION,
                        DomainContextTemplate.of(fetchCoFTopupPaymentInstrumentsDomainRequestBuilder, fetchCoFTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder, fetchCoFTopupPaymentInstrumentsWithPreselectionFlowFactory, flowBuilder))
                .put(Functionality.FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION,
                        DomainContextTemplate.of(fetchBillPayPaymentInstrumentsDomainRequestBuilder, fetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder, fetchBillPayPaymentInstrumentsWithPreselectionFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION,
                        DomainContextTemplate.of(migrationFetchCoFTopupPaymentInstrumentsDomainRequestBuilder, migrationFetchCofTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder, fetchCoFTopupPaymentInstrumentsWithPreselectionFlowFactory, flowBuilder))
                .put(Functionality.MIGRATION_FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION,
                DomainContextTemplate.of(migrationFetchBillPayPaymentInstrumentsDomainRequestBuilder, migrationFetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder, fetchBillPayPaymentInstrumentsWithPreselectionFlowFactory, flowBuilder))
                .build();
    }

    public CoFTopupResponse coFTopup(CoFTopupRequest cofTopupRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (CoFTopupResponse) domainTemplateMap.get(Functionality.COF_TOPUP).process(cofTopupRequest, headers);
    }

    public UnifiedPaymentResponse migrationCoFTopup(LoadMoneyRequestEWS loadMoneyRequestEWS, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (UnifiedPaymentResponse) domainTemplateMap.get(Functionality.MIGRATION_COF_TOPUP).process(loadMoneyRequestEWS, headers);
    }

    public ValidateCoFTopupResponse validateCoFTopup(ValidateCoFTopupRequest validateCoFTopupRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (ValidateCoFTopupResponse) domainTemplateMap.get(Functionality.VALIDATE_COF_TOPUP).process(validateCoFTopupRequest, headers);
    }

    public UnifiedPaymentResponse migrationValidateCoFTopup(ValidateChargeRequestEWS validateChargeRequestEWS, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (UnifiedPaymentResponse) domainTemplateMap.get(Functionality.MIGRATION_VALIDATE_COF_TOPUP).process(validateChargeRequestEWS, headers);
    }

    public CancelCoFTopUpResponse cancelCoFTopupTransaction(CancelCoFTopupRequest cancelCoFTopupRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (CancelCoFTopUpResponse) domainTemplateMap.get(Functionality.CANCEL_COF_TOPUP).process(cancelCoFTopupRequest, headers);
    }

    public CancelCoFTopupResponseEWS migrationCancelCoFTopup(CancelCoFTopupRequestEWS cancelCoFTopupRequestEWS, MultiValueMap<String, String> headers) {
        return (CancelCoFTopupResponseEWS) domainTemplateMap.get(Functionality.MIGRATION_CANCEL_COF_TOPUP).process(cancelCoFTopupRequestEWS, headers);
    }

    public PayBillResponse payBill(PayBillRequest payBillRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (PayBillResponse) domainTemplateMap.get(Functionality.BILL_PAYMENT).process(payBillRequest, headers);
    }

    public PayInitResponseEWS migrationPayBillinit(PayInitRequestEWS payInitRequestEWS, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (PayInitResponseEWS) domainTemplateMap.get(Functionality.MIGRATION_PAY_BILL_INIT).process(payInitRequestEWS, headers);
    }

    public CancelPayBillInitResponse cancelPayBillInitTransaction(CancelPayBillInitRequest request, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (CancelPayBillInitResponse) domainTemplateMap.get(Functionality.CANCEL_PAY_BILL_INIT).process(request, headers);
    }

    public CancelPayBillInitResponseEWS migrationCancelPayBillInitTransaction(CancelPayBillInitRequestEWS cancelPayBillInitRequestEWS, MultiValueMap<String, String> headers) {
        return (CancelPayBillInitResponseEWS) domainTemplateMap.get(Functionality.MIGRATION_CANCEL_PAY_BILL_INIT).process(cancelPayBillInitRequestEWS, headers);
    }

    public UpdateCustomerBillAccountResponse updateCustomerBillAccount(UpdateCustomerBillAccountRequest request, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (UpdateCustomerBillAccountResponse) domainTemplateMap.get(Functionality.UPDATE_CUSTOMER_BILL_ACCOUNT).process(request, headers);
    }

    public SavedBillerAccountResponseDTO migrationUpdateCustomerBillAccount(UpdateSavedBillerAccountRequest request, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (SavedBillerAccountResponseDTO) domainTemplateMap.get(Functionality.MIGRATION_UPDATE_CUSTOMER_BILL_ACCOUNT).process(request, headers);
    }

    public FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (FetchBillPayPaymentInstrumentsResponse) domainTemplateMap.get(Functionality.FETCH_BILL_PAY_PAYMENT_INSTRUMENTS).process(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    public FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (FetchBillPayPaymentInstrumentsWithPreselectionResponse) domainTemplateMap.get(Functionality.FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION).process(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    public FetchBillPayPaymentInstrumentsResponseEWS migrationFetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) {
        return (FetchBillPayPaymentInstrumentsResponseEWS) domainTemplateMap.get(Functionality.MIGRATION_FETCH_BILL_PAY_PAYMENT_INSTRUMENTS).process(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    public FetchPaymentOptionsWithPreselectionResponse migrationFetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) {
        return (FetchPaymentOptionsWithPreselectionResponse) domainTemplateMap.get(Functionality.MIGRATION_FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION).process(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    public CreateBillResponse createBill(CreateBillRequest createBillRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (CreateBillResponse) domainTemplateMap.get(Functionality.CREATE_BILL).process(createBillRequest, headers);
    }

    public CreateBillV2DTO migrationCreateBill(CreateBillRequestEWS createBillRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (CreateBillV2DTO) domainTemplateMap.get(Functionality.MIGRATION_CREATE_BILL).process(createBillRequest, headers);
    }

    public FetchCoFTopupPaymentInstrumentsResponse fetchCoFTopupPaymentInstruments(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, final MultiValueMap<String, String> headers) throws ApplicationException {
        return (FetchCoFTopupPaymentInstrumentsResponse) domainTemplateMap.get(Functionality.FETCH_COFTOPUP_PAYMENT_INSTRUMENTS).process(fetchCoFTopupPaymentInstrumentsRequest, headers);
    }

    public FetchCoFTopupPaymentInstrumentsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, MultiValueMap<String, String> headers) {
        return (FetchCoFTopupPaymentInstrumentsWithPreselectionResponse) domainTemplateMap.get(Functionality.FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION).process(fetchCoFTopupPaymentInstrumentsRequest, headers);
    }

    public FetchPaymentOptionsResponse migrationFetchCoFTopupPaymentInstruments(FetchCoFTopupPaymentInstrumentsRequestEWS fetchCoFTopupPaymentInstrumentsRequestEWS, MultiValueMap<String, String> headers) {
        return (FetchPaymentOptionsResponse) domainTemplateMap.get(Functionality.MIGRATION_FETCH_COFTOPUP_PAYMENT_INSTRUMENTS).process(fetchCoFTopupPaymentInstrumentsRequestEWS, headers);
    }

    public FetchPaymentOptionsWithPreselectionResponse migrationFetchCoFTopupPaymentInstrumentsWithPreselection(FetchCoFTopupPaymentInstrumentsRequestEWS fetchCoFTopupPaymentInstrumentsRequestEWS, MultiValueMap<String, String> headers) {
        return (FetchPaymentOptionsWithPreselectionResponse) domainTemplateMap.get(Functionality.MIGRATION_FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION).process(fetchCoFTopupPaymentInstrumentsRequestEWS, headers);
    }

    public ValidateChargeInitResponseEWS migrationValidateChargeInit(ValidateChargeInitRequestEWS validateChargeInitRequestEWS, MultiValueMap<String, String> headers) {
        return (ValidateChargeInitResponseEWS) domainTemplateMap.get(Functionality.MIGRATION_VALIDATE_CHARGE_INIT).process(validateChargeInitRequestEWS, headers);
    }
}
