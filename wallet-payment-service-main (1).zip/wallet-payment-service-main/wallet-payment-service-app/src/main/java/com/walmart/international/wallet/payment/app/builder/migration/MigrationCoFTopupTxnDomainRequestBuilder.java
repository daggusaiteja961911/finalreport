package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationTransactionMapper;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.LoadMoneyRequestEWS;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class MigrationCoFTopupTxnDomainRequestBuilder extends BaseDomainRequestBuilder<LoadMoneyRequestEWS, CoFTopupTxnRequestDomainContext> {

    private MigrationTransactionMapper migrationTransactionMapper = MigrationTransactionMapper.INSTANCE;

    @Override
    public CoFTopupTxnRequestDomainContext buildDomainRequest(LoadMoneyRequestEWS loadMoneyRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        CoFTopUpTransaction.CoFTopUpTransactionBuilder coFTopUpTransactionBuilder = CoFTopUpTransaction.builder()
                .transactionType(TransactionType.COF_TOPUP)
                .amountRequested(Amount.builder()
                        .value(loadMoneyRequestEWS.getAmount())
                        .currencyUnit(CurrencyUnit.valueOf(loadMoneyRequestEWS.getAmountCurrency().name()))
                        .build())
                .customer(Customer.builder()
                        .customerAccountId(loadMoneyRequestEWS.getCustomerAccountId())
                        .build());

        CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                .paymentInstrumentId(loadMoneyRequestEWS.getPaymentPreferenceId())
                .cardTokenInformation(migrationTransactionMapper.mapCardTokenInformationFromDTOToContext(loadMoneyRequestEWS.getCardTokenInformation()))
                .fraudInfo(migrationTransactionMapper.mapFraudInfoFromDTOToContext(loadMoneyRequestEWS.getFraudInfo()))
                .amount(Amount.builder()
                        .value(loadMoneyRequestEWS.getAmount())
                        .currencyUnit(CurrencyUnit.valueOf(loadMoneyRequestEWS.getAmountCurrency().name()))
                        .build())
                .affiliationType(AffiliationType.valueOf(loadMoneyRequestEWS.getAffiliationType().name()))
                .build();
        coFTopUpTransactionBuilder.cardPaymentTransactionList(cardPaymentTransaction);

        return CoFTopupTxnRequestDomainContext.builder()
                .clientRequestId(String.valueOf(headers.get(WPSConstants.Headers.CLIENT_REQ_ID).get(0)))
                .transaction(coFTopUpTransactionBuilder.build())
                .headers(headers)
                .build();
    }

}
