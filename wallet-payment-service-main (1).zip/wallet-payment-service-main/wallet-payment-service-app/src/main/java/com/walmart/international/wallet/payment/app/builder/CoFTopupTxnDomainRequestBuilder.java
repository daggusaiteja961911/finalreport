package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.TransactionMapper;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.common.CardMetadata;
import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.util.Objects;

@Component
@Slf4j
public class CoFTopupTxnDomainRequestBuilder extends BaseDomainRequestBuilder<CoFTopupRequest, CoFTopupTxnRequestDomainContext> {

    private TransactionMapper transactionMapper = TransactionMapper.INSTANCE;

    @Override
    public CoFTopupTxnRequestDomainContext buildDomainRequest(CoFTopupRequest cofTopupRequest, MultiValueMap<String, String> headers, Tenant tenant) {
        CoFTopUpTransaction.CoFTopUpTransactionBuilder coFTopUpTransactionBuilder = CoFTopUpTransaction.builder()
                .transactionType(TransactionType.COF_TOPUP)
                .transactionReferenceId(cofTopupRequest.getTransactionReferenceId())
                .amountRequested(Amount.builder()
                        .value(cofTopupRequest.getAmount())
                        .currencyUnit(CurrencyUnit.valueOf(cofTopupRequest.getCurrencyUnit().name()))
                        .build())
                .customer(Customer.builder()
                        .customerAccountId(cofTopupRequest.getCustomerAccountId())
                        .build());

        if (Objects.nonNull(cofTopupRequest.getParentTransactionType())) {
            coFTopUpTransactionBuilder.parentTransactionType(TransactionType.valueOf(cofTopupRequest.getParentTransactionType().name()));
        }

        GiftCardTransaction giftCardLoadTransaction = null;
        if (Objects.nonNull(cofTopupRequest.getGiftCardLoadDetail()) && Objects.nonNull(cofTopupRequest.getGiftCardLoadDetail().getPaymentInstrumentId())) {
            giftCardLoadTransaction = GiftCardTransaction.builder()
                    .paymentInstrumentId(cofTopupRequest.getGiftCardLoadDetail().getPaymentInstrumentId())
                    .amount(Amount.builder()
                            .value(cofTopupRequest.getAmount())
                            .currencyUnit(CurrencyUnit.valueOf(cofTopupRequest.getCurrencyUnit().name()))
                            .build())
                    .giftCardTransactionType(GiftCardTransactionType.LOAD)
                    .build();
            coFTopUpTransactionBuilder.giftCardLoadTransactionList(giftCardLoadTransaction);
        }

        CardMetadata cardMetadata = cofTopupRequest.getCardPaymentDetail().getCardMetadata();
        CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                .paymentInstrumentId(cofTopupRequest.getCardPaymentDetail().getPaymentInstrumentId())
                .cardTokenInformation(transactionMapper.mapCardTokenInformationFromDTOToContext(cardMetadata.getCardTokenInformation()))
                .fraudInfo(transactionMapper.mapFraudInfoFromDTOToContext(cardMetadata.getFraudInfo()))
                .amount(Amount.builder()
                        .value(cofTopupRequest.getAmount())
                        .currencyUnit(CurrencyUnit.valueOf(cofTopupRequest.getCurrencyUnit().name()))
                        .build())
                .affiliationType(AffiliationType.valueOf(cofTopupRequest.getAffiliationType().name()))
                .build();
        coFTopUpTransactionBuilder.cardPaymentTransactionList(cardPaymentTransaction);

        return CoFTopupTxnRequestDomainContext.builder()
                .clientRequestId(String.valueOf(headers.get(WPSConstants.Headers.CLIENT_REQ_ID).get(0)))
                .transaction(coFTopUpTransactionBuilder.build())
                .headers(headers)
                .build();
    }
}
