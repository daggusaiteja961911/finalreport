package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.transaction.audit.TransactionAckRequest;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnAckResponse;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnSyncResponse;

import java.util.List;
import java.util.UUID;

public interface TransactionAuditService {

    TxnSyncResponse reSyncTransactionsToTAS(List<UUID> transactionIds, String correlationId) throws ApplicationException;

    TxnAckResponse acknowledgeProcessedTransactionFromTAS(TransactionAckRequest transactionAckRequest);
}