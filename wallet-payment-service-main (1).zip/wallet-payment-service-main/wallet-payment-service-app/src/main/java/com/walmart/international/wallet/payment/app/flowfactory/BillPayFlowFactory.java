package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import org.springframework.stereotype.Component;

@Component
public class BillPayFlowFactory extends FlowFactory<BillPayTxnRequestDomainContext> {

    @Override
    public FlowType deriveFlow(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, Tenant tenant) {
        switch (tenant) {
            case MX:
                return deriveTopupFlowforMexico(billPayTxnRequestDomainContext);
            case CA:
            case UNKNOWN:
            default:
                break;
        }
        return null;
    }

    private FlowType deriveTopupFlowforMexico(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {

//        if (walletRequestDomainContext.getDecisions() != null &&
//                Boolean.TRUE.equals(walletRequestDomainContext.getDecisions().get("cardAndGiftCardCombo"))) {
//            return MXFlowType.BILL_PAY_WITH_LOAD;
//        }
        return MXFlowType.PAY_BILL_INIT;
    }
}
