package com.walmart.international.wallet.payment.app.controller.billpay.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.migration.BillerDataUpdatePollRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.BillProviderInfoDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerCategoriesDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerDataUpdatePollResponse;
import com.walmart.international.wallet.payment.dto.response.migration.BillersListResponseDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.ws.rs.QueryParam;

@RequestMapping("/ews-internal")
@Tag(name = "MigrationBillerController API", description = "Migration APIs to perform Biller data related activities.")
public interface MigrationBillerController {

    @GetMapping(value = "/V3/billpay/categories", produces = "application/json")
    BillerCategoriesDTO getBillerCategories();

    @GetMapping(value = "/V3/billpay/billers/popular", produces = "application/json")
    BillersListResponseDTO getPopularBillers() throws ApplicationException;

    @GetMapping(value = "/V5/billpay/billprovider/{billerId}", produces = "application/json")
    BillProviderInfoDTO getBillProviderInfo(@PathVariable(value = "billerId") String processorBillerId) throws ApplicationException;

    @PostMapping(value = "/billpay/billerData/updates", consumes = "application/json", produces = "application/json")
    BillerDataUpdatePollResponse getBillerDataUpdateInfo(@RequestBody BillerDataUpdatePollRequest billerDataUpdatePollRequest);

    @GetMapping(value = "/v1/biller/promotions", produces = "application/json")
    BillerPromotionsResponse getPromotions(@RequestParam(required = false) String billerCategoryIds, @RequestParam(required = false) String billerIds);
}
