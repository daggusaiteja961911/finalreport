package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import org.springframework.stereotype.Component;

@Component
public class CancelCoFTopupTransactionFlowFactory extends FlowFactory<CoFTopupTxnRequestDomainContext> {

    @Override
    public FlowType deriveFlow(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext, Tenant tenant) {
        switch (tenant) {
            case MX:
                return deriveCancelCoFTopupFlowForMexico();
            case CA:
            case UNKNOWN:
            default:
                String msg = String.format("Invalid tenantId [%s] for CancelCoFTopup flow", tenant);
                throw new ProcessingException(ErrorConstants.CancelCoFTopupTransaction.FLOW_FACTORY_INVALID_TENANT_ID, msg);
        }
    }

    private FlowType deriveCancelCoFTopupFlowForMexico() {
        return MXFlowType.CANCEL_COF_TOPUP;
    }
}
