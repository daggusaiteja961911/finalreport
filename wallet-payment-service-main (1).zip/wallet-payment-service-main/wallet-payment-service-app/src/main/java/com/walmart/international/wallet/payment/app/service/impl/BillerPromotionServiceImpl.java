package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.wallet.payment.app.service.BillerPromotionService;
import com.walmart.international.wallet.payment.app.service.impl.mapper.BillerPromotionDTOMappper;
import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;
import com.walmart.international.wallet.payment.core.service.BillerPromotionCoreService;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class BillerPromotionServiceImpl implements BillerPromotionService {

    @Autowired
    private BillerPromotionCoreService billerPromotionCoreService;

    private static final BillerPromotionDTOMappper billerPromotionDTOMappper = BillerPromotionDTOMappper.INSTANCE;

    @Override
    public BillerPromotionsResponse getBillerPromotions(String billerCategoryIds, String processorBillerIds, int billerCategoryVersion) {
        HashMap<String, List<BillerPromotionDTO>> billerPromotions = new HashMap<>();
        Map<String, List<BillerPromotion>> billerPromotionsForPromotionCategory = billerPromotionCoreService.getAllPromotionsForPromotionCategory(billerCategoryIds, processorBillerIds, billerCategoryVersion);
        for (Map.Entry<String, List<BillerPromotion>> billerPromotionsByBillerId : billerPromotionsForPromotionCategory.entrySet()) {
            billerPromotions.put(billerPromotionsByBillerId.getKey(), billerPromotionDTOMappper.mapBillerPromotionsToBillerPromotionDTOs(billerPromotionsByBillerId.getValue()));
        }
        return BillerPromotionsResponse.builder()
                .promotionMap(billerPromotions)
                .build();
    }
}
