package com.walmart.international.wallet.payment.app.service.migration.impl.mapper;

import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.dto.response.migration.Bill;
import com.walmart.international.wallet.payment.dto.response.migration.BillerCategoryDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerInformation;
import com.walmart.international.wallet.payment.dto.response.migration.BillerPlanDetailsUpdateInfo;
import com.walmart.international.wallet.payment.dto.response.migration.SimpleBillerDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SimpleBillerProviderDTO;
import io.strati.libs.commons.collections.CollectionUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Mapper
@Component
public interface MigrationBillerDTOMapper {

    MigrationBillerDTOMapper INSTANCE = Mappers.getMapper(MigrationBillerDTOMapper.class);

    List<BillerCategoryDTO> mapBillerCategoriesListToBillerCategoryDTOList(List<BillerCategory> billerCategoriesList);


    @Mapping(target = "billerVersion", source = "billerCategoryVersion")
    @Mapping(target = "billers", source = "billers", qualifiedByName = "mapBillerListToGetBillerCategorySimpleBillerDTOList")
    BillerCategoryDTO mapBillerCategoryToBillerCategoryDTO(BillerCategory billerCategory);

    @Named("mapBillerListToGetBillerCategorySimpleBillerDTOList")
    default List<SimpleBillerDTO> mapBillerListToGetBillerCategorySimpleBillerDTOList(List<Biller> billers) {
        List<SimpleBillerDTO> billerDTOList = null;
        if (CollectionUtils.isNotEmpty(billers)) {
            billerDTOList = new ArrayList<>();
            for (Biller biller : billers) {
                billerDTOList.add(mapBillerToGetBillerCategoriesBillerDTO(biller));
            }
        }
        return billerDTOList;
    }

    default SimpleBillerDTO mapBillerToGetBillerCategoriesBillerDTO(Biller biller) {
        return SimpleBillerDTO.builder()
                .id(biller.getBillerId())
                .billerId(Integer.parseInt(biller.getProcessorBillerId()))
                .displayName(biller.getDisplayName())
                .billerType(biller.getBillerType())
                .imageURL(biller.getImageURL())
                .isNewBiller(biller.getNewBiller())
                .tags(biller.getTags())
                .products(mapBillerListToGetBillerCategorySimpleBillerDTOList(biller.getSubBillers()))
                .build();
    }

    default List<SimpleBillerDTO> mapBillerListToGetPopularBillersSimpleBillerDTOList(List<Biller> billers) {
        List<SimpleBillerDTO> billerDTOList = null;
        if (CollectionUtils.isNotEmpty(billers)) {
            billerDTOList = new ArrayList<>();
            for (Biller biller : billers) {
                billerDTOList.add(mapBillerToGetPopularBillersSimpleBillerDTO(biller));
            }
        }
        return billerDTOList;
    }

    default SimpleBillerDTO mapBillerToGetPopularBillersSimpleBillerDTO(Biller biller) {
        return SimpleBillerDTO.builder()
                .id(biller.getBillerId())
                .billerId(Integer.parseInt(biller.getProcessorBillerId()))
                .displayName(biller.getDisplayName())
                .billerType(biller.getBillerType())
                .imageURL(biller.getImageURL())
                .isNewBiller(biller.getNewBiller())
                .billerAccountNumber(biller.getBillerAccountNumber())
                .products(mapBillerListToGetPopularBillersSimpleBillerDTOList(biller.getSubBillers()))
                .build();
    }

    @Mapping(target = "id", source = "billerId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "name", source = "displayName")
    @Mapping(target = "productName", source = "productDisplayName")
    BillerInformation mapBillerInformation(Biller biller);

    @Mapping(target = "id", source = "billerId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "name", source = "displayName")
    @Mapping(target = "plans", source = "billPlans")
    @Mapping(target = "supportsAutoPay", constant = "false")
    SimpleBillerProviderDTO mapBillerToDTO(Biller biller);

    List<SimpleBillerProviderDTO> mapBillersToDTOs(List<Biller> billers);

    @Mapping(target = "id", source = "billDetailId")
    Bill mapToBill(BillDetail billDetail);

    default List<BillerPlanDetailsUpdateInfo> mapBillerDataLastUpdatedAtMap(Map<String, Object> billerDataLastUpdatedAtMap) {
        List<BillerPlanDetailsUpdateInfo> billerPlanDetailUpdates = new ArrayList<>();
        if (Objects.nonNull(billerDataLastUpdatedAtMap)) {
            billerDataLastUpdatedAtMap.forEach((key, value) -> billerPlanDetailUpdates.add(BillerPlanDetailsUpdateInfo.builder()
                    .billerId(Integer.valueOf(key.substring(0, key.indexOf(WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT))))
                    .lastUpdatedAt(Date.from(((LocalDateTime) value).toInstant(ZoneOffset.UTC)))
                    .build()));
        }
        return billerPlanDetailUpdates;
    }


}
