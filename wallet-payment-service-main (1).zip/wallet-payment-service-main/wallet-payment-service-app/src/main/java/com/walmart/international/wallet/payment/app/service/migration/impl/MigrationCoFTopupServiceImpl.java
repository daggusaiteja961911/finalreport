package com.walmart.international.wallet.payment.app.service.migration.impl;

import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.app.service.migration.MigrationCoFTopupService;
import com.walmart.international.wallet.payment.dto.request.migration.CancelCoFTopupRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.FetchCoFTopupPaymentInstrumentsRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.LoadMoneyRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelCoFTopupResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UnifiedPaymentResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.util.UUID;

@Component
public class MigrationCoFTopupServiceImpl implements MigrationCoFTopupService {

    @Autowired
    WalletServiceRouter walletServiceRouter;
    @Override
    public FetchPaymentOptionsResponse fetchCoFTopupPaymentInstruments(UUID customerAccountId, MultiValueMap<String, String> headers) {
        FetchCoFTopupPaymentInstrumentsRequestEWS fetchCoFTopupPaymentInstrumentsRequestEWS = FetchCoFTopupPaymentInstrumentsRequestEWS.builder().customerAccountId(customerAccountId).build();
        return walletServiceRouter.migrationFetchCoFTopupPaymentInstruments(fetchCoFTopupPaymentInstrumentsRequestEWS, headers);
    }

    @Override
    public UnifiedPaymentResponse loadMoney(UUID customerAccountId, LoadMoneyRequestEWS loadMoneyRequestEWS, MultiValueMap<String, String> headers) {
        loadMoneyRequestEWS.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationCoFTopup(loadMoneyRequestEWS, headers);
    }

    @Override
    public UnifiedPaymentResponse validateCharge(UUID customerAccountId, ValidateChargeRequestEWS validateChargeRequestEWS, MultiValueMap<String, String> headers) {
        validateChargeRequestEWS.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationValidateCoFTopup(validateChargeRequestEWS, headers);
    }

    @Override
    public CancelCoFTopupResponseEWS cancelPayment(UUID customerAccountId, UUID transactionId, CancelCoFTopupRequestEWS cancelCoFTopupRequestEWS, MultiValueMap<String, String> headers) {
        cancelCoFTopupRequestEWS.setTransactionId(transactionId);
        cancelCoFTopupRequestEWS.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationCancelCoFTopup(cancelCoFTopupRequestEWS, headers);
    }

    @Override
    public FetchPaymentOptionsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(UUID customerAccountId, MultiValueMap<String, String> headers) {
        FetchCoFTopupPaymentInstrumentsRequestEWS fetchCoFTopupPaymentInstrumentsRequestEWS = FetchCoFTopupPaymentInstrumentsRequestEWS.builder().customerAccountId(customerAccountId).build();
        return walletServiceRouter.migrationFetchCoFTopupPaymentInstrumentsWithPreselection(fetchCoFTopupPaymentInstrumentsRequestEWS, headers);

    }
}
