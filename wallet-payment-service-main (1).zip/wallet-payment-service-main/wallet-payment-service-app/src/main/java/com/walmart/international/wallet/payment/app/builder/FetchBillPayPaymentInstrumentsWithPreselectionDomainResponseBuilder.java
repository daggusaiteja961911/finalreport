package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.PaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.common.PaymentInstrumentDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class FetchBillPayPaymentInstrumentsWithPreselectionDomainResponseBuilder extends BaseDomainResponseBuilder<FetchBillPayPaymentInstrumentsWithPreselectionResponse, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {

    BillPayMapper billPayMapper = BillPayMapper.INSTANCE;

    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public FetchBillPayPaymentInstrumentsWithPreselectionResponse buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        List<PaymentInstrument> paymentInstrumentList = billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getPaymentInstruments().getPaymentInstrumentList();
        List<PaymentInstrumentDTO> paymentInstrumentDTOS = paymentInstrumentList.stream().map(instrument -> {
            if (instrument instanceof CardPaymentInstrument) {
                return billPayMapper.mapCardPaymentInstrumentToPaymentInstrumentDTO((CardPaymentInstrument) instrument);
            } else if (instrument instanceof GiftCardPaymentInstrument) {
                return billPayMapper.mapGiftCardPaymentInstrumentToGiftCardPaymentInstrumentDTO((GiftCardPaymentInstrument) instrument);
            }
            return null;
        }).collect(Collectors.toList());

        return FetchBillPayPaymentInstrumentsWithPreselectionResponse.builder()
                .transaction(billPayMapper.mapBillPayTransactionToTransactionDTO(billPayTxnResponseDomainContext.getTransaction()))
                .paymentOptions(paymentInstrumentDTOS)
                .isMSIAllowedForSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getIsMSIAllowedForSplitPayment())
                .allowCoFForBillPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowCoFForBillPayment())
                .allowB2BSplitForBillPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowB2BForSplitPayment())
                .allowMultipleB2BForSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowMultipleB2BForSplitPayment()).build();
    }
}