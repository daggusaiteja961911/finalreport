package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillResponse;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.app.service.BillPaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import javax.validation.Valid;

@Component
@Slf4j
public class BillPaymentServiceImpl implements BillPaymentService {

    @Autowired
    private WalletServiceRouter walletServiceRouter;

    public FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.fetchBillPayPaymentInstruments(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) {
        return walletServiceRouter.fetchBillPayPaymentInstrumentsWithPreselection(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    public PayBillResponse payBill(@Valid PayBillRequest request,
                                   MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.payBill(request, headers);
    }

    public CancelPayBillInitResponse cancelPayBillInit(@Valid CancelPayBillInitRequest request,
                                                       MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.cancelPayBillInitTransaction(request, headers);
    }
}
