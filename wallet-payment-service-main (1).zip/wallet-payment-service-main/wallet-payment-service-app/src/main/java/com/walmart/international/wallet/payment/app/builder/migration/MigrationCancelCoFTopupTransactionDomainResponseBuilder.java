package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationCoFTopupMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.constants.WPSConstants;
import com.walmart.international.wallet.payment.dto.response.migration.CancelCoFTopupResponseEWS;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class MigrationCancelCoFTopupTransactionDomainResponseBuilder extends BaseDomainResponseBuilder<CancelCoFTopupResponseEWS, CoFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext> {

    MigrationCoFTopupMapper migrationCoFTopupMapper = MigrationCoFTopupMapper.INSTANCE;

    @Override
    public CoFTopupTxnResponseDomainContext buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) {
        return CoFTopupTxnResponseDomainContext.builder().build();
    }

    @Override
    public CancelCoFTopupResponseEWS buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CancelCoFTopupResponseEWS cancelCoFTopupResponseEWS = migrationCoFTopupMapper.mapToCancelCoFTopupResponseFromContext(coFTopupTxnResponseDomainContext);
        cancelCoFTopupResponseEWS.setDisplayMessage(getDisplayMessageForAbortReason(coFTopupTxnRequestDomainContext.getTransaction().getAbortReason()));
        cancelCoFTopupResponseEWS.getTransaction().setState(WPSConstants.CancelCoFTopup.CANCEL_TRANSACTION_STATE);
        cancelCoFTopupResponseEWS.getTransaction().setStateReason(WPSConstants.CancelCoFTopup.CANCEL_TRANSACTION_STATE_REASON);
        cancelCoFTopupResponseEWS.getTransaction().setWalletTransactionType("LOAD_MONEY");
        return cancelCoFTopupResponseEWS;
    }

    private String getDisplayMessageForAbortReason(String abortReason) {
        switch (abortReason.toUpperCase(Locale.ROOT)) {
            case WPSConstants.CancelTransaction.BANK_PAGE_ERROR: {
                return WPSConstants.CancelTransaction.CANCEL_TRANSACTION_BANK_PAGE_ERROR_DISPLAY_MESSAGE;
            }
            case WPSConstants.CancelTransaction.TIMEOUT: {
                return WPSConstants.CancelTransaction.CANCEL_TRANSACTION_TIMEOUT_DISPLAY_MESSAGE;
            }
            default: {
                return WPSConstants.CancelTransaction.CANCEL_TRANSACTION_DEFAULT_DISPLAY_MESSAGE;
            }
        }
    }

}
