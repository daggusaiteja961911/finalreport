package com.walmart.international.wallet.payment.app.controller.impl.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.wallet.payment.app.controller.billpay.BillController;
import com.walmart.international.wallet.payment.app.service.BillService;
import com.walmart.international.wallet.payment.dto.request.billpay.AlreadyPaidRequestDTO;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.DeleteCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetBillsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetSavedCustomerBillAccountsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.AlreadyPaidResponseDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.CreateBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.DeleteCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetSavedCustomerBillAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class BillControllerImpl implements BillController {

    @Autowired
    private BillService billService;

    @Override
    @Metered(level1 = "Bill", level2 = "GetBills", level3 = "All", metricName = "CASHI_CUSTOMER")
    public GetBillsResponse getBills(GetBillsRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        return billService.getBills(request, headers);
    }

    @Override
    @Metered(level1 = "Bill", level2 = "UpdateCustomerBillAccount", level3 = "All", metricName = "CASHI_CUSTOMER")
    public UpdateCustomerBillAccountResponse updateCustomerBillAccount(UpdateCustomerBillAccountRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        return billService.updateCustomerBillAccount(request, headers);
    }

    @Override
    @Metered(level1 = "Bill", level2 = "DeleteCustomerBillAccount", level3 = "All", metricName = "CASHI_CUSTOMER")
    public DeleteCustomerBillAccountResponse deleteCustomerBillAccount(DeleteCustomerBillAccountRequest deleteCustomerBillAccountRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return billService.deleteCustomerBillAccount(deleteCustomerBillAccountRequest, headers);
    }

    @Override
    @Metered(level1 = "Bill", level2 = "CreateBill", level3 = "All", metricName = "CASHI_CUSTOMER")
    public CreateBillResponse createBill(CreateBillRequest createBillRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return billService.createBill(createBillRequest, headers);
    }

    @Override
    @Metered(level1 = "Bill", level2 = "GetSavedCustomerBillAccountsForCustomer", level3 = "All", metricName = "CASHI_CUSTOMER")
    public GetSavedCustomerBillAccountsResponse getSavedCustomerBillAccountsForCustomer(GetSavedCustomerBillAccountsRequest getSavedCustomerBillAccountsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return billService.getSavedCustomerBillAccountsForCustomer(getSavedCustomerBillAccountsRequest, headers);
    }

    @Override
    @Metered(level1 = "Bill", level2 = "AlreadyPaid", level3 = "All", metricName = "CASHI_TRANSACTION")
    public AlreadyPaidResponseDTO markAlreadyPaid(AlreadyPaidRequestDTO alreadyPaidRequest, UUID customerAccountId,
                                                   UUID customerBillAccountId, MultiValueMap<String, String> headers) throws ApplicationException {
        return billService.markAlreadyPaid(alreadyPaidRequest, customerAccountId, customerBillAccountId, headers);
    }
}
