package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;

public interface BillerPromotionService {
    BillerPromotionsResponse getBillerPromotions(String billerCategoryIds, String processorBillerIds, int billerCategoryVersion);
}
