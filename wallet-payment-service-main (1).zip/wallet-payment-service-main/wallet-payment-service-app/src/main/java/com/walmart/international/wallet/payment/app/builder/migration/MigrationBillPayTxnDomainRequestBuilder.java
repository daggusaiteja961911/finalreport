package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationTransactionMapper;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.PayInitRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CardPaymentDetails;
import com.walmart.international.wallet.payment.dto.response.migration.GiftcardPaymentDetails;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.util.Objects;
import java.util.UUID;

@Component
public class MigrationBillPayTxnDomainRequestBuilder extends BaseDomainRequestBuilder<PayInitRequestEWS, BillPayTxnRequestDomainContext> {

    MigrationTransactionMapper migrationTransactionMapper = MigrationTransactionMapper.INSTANCE;

    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(PayInitRequestEWS payInitRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        BillPayTransaction.BillPayTransactionBuilder billPayTransactionBuilder = BillPayTransaction.builder()
                .transactionType(TransactionType.BILL_PAY)
                .customerBillAccount(CustomerBillAccount.builder()
                        .processorBillerId(String.valueOf(payInitRequestEWS.getBillerDetails().getBillerId()))
                        .accountNumber(payInitRequestEWS.getBillerDetails().getAccountNumber())
                        .processorBillAccountId(payInitRequestEWS.getBillerDetails().getCustomerBillId())
                        .build())
                .amountRequested(Amount.builder()
                        .value(payInitRequestEWS.getBillerDetails().getAmount())
                        .currencyUnit(CurrencyUnit.valueOf(payInitRequestEWS.getBillerDetails().getCurrencyUnit()))
                        .build());

        if (Objects.nonNull(payInitRequestEWS.getBillerDetails().getBillDetailId())) {
            billPayTransactionBuilder.billDetail(BillDetail.builder()
                    .billDetailId(payInitRequestEWS.getBillerDetails().getBillDetailId())
                    .name(payInitRequestEWS.getBillerDetails().getItemName())
                    .build());
        }

        for (CardPaymentDetails cardPaymentDetails : payInitRequestEWS.getPaymentDetails().getCardPaymentDetails()) {
            CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                    .paymentInstrumentId(cardPaymentDetails.getPaymentPreferenceId())
                    .cardTokenInformation(migrationTransactionMapper.mapCardTokenInformationFromDTOToContext(cardPaymentDetails.getCardTokenInformation()))
                    .fraudInfo(migrationTransactionMapper.mapFraudInfoFromDTOToContext(cardPaymentDetails.getFraudInfo()))
                    .amount(Amount.builder()
                            .value(cardPaymentDetails.getAmount().getCurrencyAmount())
                            .currencyUnit(CurrencyUnit.valueOf(cardPaymentDetails.getAmount().getCurrencyUnit().name()))
                            .build())
                    .affiliationType(AffiliationType.valueOf(cardPaymentDetails.getAffiliationType().name()))
                    .build();
            billPayTransactionBuilder.cardPaymentTransactionList(cardPaymentTransaction);
        }

        for (GiftcardPaymentDetails giftcardPaymentDetails : payInitRequestEWS.getPaymentDetails().getGiftcardPaymentDetails()) {
            GiftCardTransaction giftCardPaymentTransaction = GiftCardTransaction.builder()
                    .paymentInstrumentId(UUID.fromString(giftcardPaymentDetails.getPaymentPreference().getPaymentId()))
                    .amount(Amount.builder()
                            .value(giftcardPaymentDetails.getAmount().getCurrencyAmount())
                            .currencyUnit(CurrencyUnit.valueOf(giftcardPaymentDetails.getAmount().getCurrencyUnit().name()))
                            .build())
                    .giftCardTransactionType(GiftCardTransactionType.PAY)
                    .build();
            billPayTransactionBuilder.giftCardPaymentTransactionList(giftCardPaymentTransaction);
        }

        billPayTransactionBuilder.customer(Customer.builder()
                .customerAccountId(payInitRequestEWS.getCustomerAccountId())
                .build());

        return BillPayTxnRequestDomainContext.builder()
                .clientRequestId(Objects.nonNull(headers.get(WPSConstants.Headers.CLIENT_REQ_ID)) ? String.valueOf(headers.get(WPSConstants.Headers.CLIENT_REQ_ID).get(0)) : null)
                .transaction(billPayTransactionBuilder.build())
                .headers(headers)
                .build();
    }
}
