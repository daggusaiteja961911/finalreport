package com.walmart.international.wallet.payment.app.config;

import com.walmart.platform.txn.springboot.filters.SpringBootServerTxnMarkingInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new SpringBootServerTxnMarkingInterceptor());
    }
}

