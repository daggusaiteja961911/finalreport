package com.walmart.international.wallet.payment.app.controller.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@RequestMapping("/services/bill-payment")
@Tag(name = "BillPaymentController API", description = "APIs to perform Bill Payment related activities.")
public interface BillPaymentController {
    @GetMapping(value = "/v1/options", consumes = "application/json", produces = "application/json")
    FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(@RequestBody @Valid FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @GetMapping(value = "/v2/options", consumes = "application/json", produces = "application/json")
    FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(@RequestBody @Valid FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    // TODO - remove this API ?
    @PostMapping(value = "/v1/bill-payment/pay", consumes = "application/json", produces = "application/json")
    PayBillResponse payBillV1(@RequestBody PayBillRequest request,
                              @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v1/bill-payment/abort", consumes = "application/json", produces = "application/json")
    CancelPayBillInitResponse cancelPayBillInit(@RequestBody CancelPayBillInitRequest cancelPayBillInitRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;
}
