package com.walmart.international.wallet.payment.app.builder.mapper;

import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.dto.response.common.CardPaymentInstrumentDTO;
import com.walmart.international.wallet.payment.dto.response.common.GiftCardPaymentInstrumentDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.TransactionDTO;
import org.codehaus.plexus.util.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 *  Mapping from ResponseContext to API response - to be used in Builder classes
 */
@Mapper
@Component
public interface BillPayMapper {

    BillPayMapper INSTANCE = Mappers.getMapper(BillPayMapper.class);

    @Named("mapBillTransaction")
    default PayBillResponse.Transaction mapBillTransaction(BillPayTransactionDO transactionDO) {
        BillerDO billerDO = transactionDO.getBillerDO();
        PayBillResponse.BillerDto billerDto = PayBillResponse.BillerDto.builder()
                .billerId(String.valueOf(billerDO.getBillerId()))
                .accountNumber(billerDO.getBillerAccountNumber())
                .name(billerDO.getBillerName())
                .redeemURL(billerDO.getRedeemURL())
                .information(billerDO.getInformation())
                .termsAndConditions(billerDO.getTermsAndConditions())
                .build();
        return PayBillResponse.Transaction.builder()
                .id(transactionDO.getBillPayTransactionId())
                .amount(transactionDO.getAmount())
                .biller(billerDto)
                .processorTransactionId(transactionDO.getProcessorTransactionId())
                .build();
    }

    @Mapping(target = "amount", source = "amountRequested.value")
    @Mapping(target = "amountCurrency", source = "amountRequested.currencyUnit")
    @Mapping(target = "accountNumber", source = "billAccountNumber")
    TransactionDTO mapBillPayTransactionToTransactionDTO(BillPayTransaction transaction);

    List<GiftCardPaymentInstrumentDTO> mapGiftCardPaymentInstrumentListToGiftCardPaymentInstrumentDTOList(List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList);

    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    GiftCardPaymentInstrumentDTO mapGiftCardPaymentInstrumentToGiftCardPaymentInstrumentDTO(GiftCardPaymentInstrument giftCardPaymentInstrument);

    List<CardPaymentInstrumentDTO> mapCardPaymentInstrumentListToCardPaymentInstrumentDTO(List<CardPaymentInstrument> cardPaymentInstrumentList);

    @Mapping(target = "cardholderName", source = "metadata.cardholderName")
    @Mapping(target = "aliasName", source = "metadata.aliasName")
    @Mapping(target = "cardNumber", source = "metadata.cardNumber")
    @Mapping(target = "last4Digits", source = "metadata.last4Digits")
    @Mapping(target = "expirationMonth", source = "expirationDate", qualifiedByName = "mapExpirationDateToMonth")
    @Mapping(target = "expirationYear", source = "expirationDate", qualifiedByName = "mapExpirationDateToYear")
    @Mapping(target = "brand", source = "metadata.brand")
    @Mapping(target = "tokenId", source = "adapterMetadata.tokenId")
    @Mapping(target = "cvvVerified", source = "metadata.cvvVerified")
    @Mapping(target = "cvvRequired", source = "metadata.cvvRequired")
    @Mapping(target = "billingAddress.countryCode", source = "billingAddress.country")
    @Mapping(target = "binDetails", source = "binDetails", qualifiedByName = "mapBinDetails")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    CardPaymentInstrumentDTO mapCardPaymentInstrumentToPaymentInstrumentDTO(CardPaymentInstrument cardPaymentInstrument);

    @Named("mapBinDetails")
    default CardPaymentInstrumentDTO.BinDetails binDetailsToBinDetails(CardPaymentInstrument.BinDetails binDetails) {
        if ( binDetails == null ) {
            return null;
        }

        CardPaymentInstrumentDTO.BinDetails binDetails1 = new CardPaymentInstrumentDTO.BinDetails();

        if (Objects.nonNull(binDetails.getBin())) {
            binDetails1.setBin(binDetails.getBin());
        }

        if (StringUtils.isNotEmpty(binDetails.getBankName())) {
            binDetails1.setBankName(binDetails.getBankName());
        }
        if (StringUtils.isNotEmpty(binDetails.getBankLogo())) {
            binDetails1.setBankLogo(binDetails.getBankLogo());
        }
        binDetails1.setBrandName( binDetails.getBrandName() );
        binDetails1.setBrandLogo( binDetails.getBrandLogo() );
        binDetails1.setBankColor( binDetails.getBankColor() );
        binDetails1.setTextColor( binDetails.getTextColor() );

        return binDetails1;
    }

    @Named("mapExpirationDateToMonth")
    default String mapExpirationDateToMonth(Date expirationDate) {
        LocalDate localDate = expirationDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        String expirationMonth = String.valueOf(localDate.getMonthValue());
        if (expirationMonth.length() < 2) {
            expirationMonth = "0" + expirationMonth;
        }
        return expirationMonth;
    }

    @Named("mapExpirationDateToYear")
    default String mapExpirationDateToYear(Date expirationDate) {
        LocalDate localDate = expirationDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        String expirationYear = String.valueOf(localDate.getYear());
        if (expirationYear.length() > 2) {
            expirationYear = expirationYear.substring(2);
        }
        return expirationYear;
    }
}
