package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationBillMapper;
import com.walmart.international.wallet.payment.dto.response.migration.CreateBillV2DTO;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MigrationCreateBillDomainResponseBuilder extends BaseDomainResponseBuilder<CreateBillV2DTO, BillRequestDomainContext, BillResponseDomainContext> {

    MigrationBillMapper migrationBillMapper = MigrationBillMapper.INSTANCE;

    @Override
    public BillResponseDomainContext buildDomainResponse(BillRequestDomainContext billRequestDomainContext) {
        return BillResponseDomainContext.builder().build();
    }

    @Override
    public CreateBillV2DTO buildDomainResponse(BillRequestDomainContext billRequestDomainContext, BillResponseDomainContext billResponseDomainContext) {
        return migrationBillMapper.mapCustomerBillAccountToCreateBillV2DTO(billRequestDomainContext.getCustomerBillAccount());
    }
}
