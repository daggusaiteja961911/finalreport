package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class CreateBillDomainRequestBuilder extends BaseDomainRequestBuilder<CreateBillRequest, BillRequestDomainContext> {

    @Override
    public BillRequestDomainContext buildDomainRequest(CreateBillRequest createBillRequest, MultiValueMap<String, String> map, Tenant tenant) {
        CustomerBillAccount customerBillAccount = CustomerBillAccount.builder()
                .billerId(createBillRequest.getBillerId())
                .accountNumber(createBillRequest.getAccountNumber())
                .customerAccountId(createBillRequest.getCustomerAccountId())
                .processorBillerId(createBillRequest.getProcessorBillerId()).build();
        return BillRequestDomainContext.builder()
                .customerBillAccount(customerBillAccount)
                .build();
    }
}
