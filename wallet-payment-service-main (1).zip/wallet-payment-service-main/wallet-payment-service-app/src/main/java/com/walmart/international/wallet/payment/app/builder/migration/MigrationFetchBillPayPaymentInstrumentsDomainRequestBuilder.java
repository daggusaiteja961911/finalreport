package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.FetchBillPayPaymentInstrumentsRequestEWS;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class MigrationFetchBillPayPaymentInstrumentsDomainRequestBuilder extends BaseDomainRequestBuilder<FetchBillPayPaymentInstrumentsRequestEWS, BillPayTxnRequestDomainContext> {
    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        Customer customer = Customer.builder()
                .customerAccountId(fetchBillPayPaymentInstrumentsRequestEWS.getCustomerAccountId())
                .build();

        BillPayTransaction billPayTransaction = BillPayTransaction.builder()
                .amountRequested(Amount.builder()
                        .value(fetchBillPayPaymentInstrumentsRequestEWS.getAmount())
                        .currencyUnit(CurrencyUnit.valueOf(fetchBillPayPaymentInstrumentsRequestEWS.getAmountCurrency()))
                        .build())
                .billAccountNumber(fetchBillPayPaymentInstrumentsRequestEWS.getAccountNumber())
                .processorBillerId(fetchBillPayPaymentInstrumentsRequestEWS.getBillerId().toString())
                .customer(customer)
                .build();

        return BillPayTxnRequestDomainContext.builder()
                .transaction(billPayTransaction)
                .headers(headers)
                .build();
    }
}
