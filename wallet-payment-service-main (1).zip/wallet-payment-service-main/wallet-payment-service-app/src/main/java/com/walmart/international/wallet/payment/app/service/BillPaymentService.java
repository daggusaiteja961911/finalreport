package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillResponse;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import org.springframework.util.MultiValueMap;

import javax.validation.Valid;

public interface BillPaymentService {

    FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers);

    FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers);

    PayBillResponse payBill(@Valid PayBillRequest request, MultiValueMap<String, String> headers) throws ApplicationException;

    CancelPayBillInitResponse cancelPayBillInit(@Valid CancelPayBillInitRequest request, MultiValueMap<String, String> headers) throws ApplicationException;
}
