package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.dto.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.topup.CancelCoFTopUpResponse;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class CancelCoFTopupTransactionDomainResponseBuilder extends BaseDomainResponseBuilder<CancelCoFTopUpResponse, CoFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext> {

    CoFTopupMapper coFTopupMapper = CoFTopupMapper.INSTANCE;

    @Override
    public CoFTopupTxnResponseDomainContext buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) {
        return CoFTopupTxnResponseDomainContext.builder().build();
    }

    @Override
    public CancelCoFTopUpResponse buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CancelCoFTopUpResponse cancelCoFTopUpResponse = coFTopupMapper.mapToCancelCoFTopupResponseFromContext(coFTopupTxnResponseDomainContext);
        cancelCoFTopUpResponse.setDisplayMessage(getDisplayMessageForAbortReason(coFTopupTxnRequestDomainContext.getTransaction().getAbortReason()));
        return cancelCoFTopUpResponse;
    }

    private String getDisplayMessageForAbortReason(String abortReason) {
        switch (abortReason.toUpperCase(Locale.ROOT)) {
            case WPSConstants.CancelTransaction.BANK_PAGE_ERROR: {
                return WPSConstants.CancelTransaction.CANCEL_TRANSACTION_BANK_PAGE_ERROR_DISPLAY_MESSAGE;
            }
            case WPSConstants.CancelTransaction.TIMEOUT: {
                return WPSConstants.CancelTransaction.CANCEL_TRANSACTION_TIMEOUT_DISPLAY_MESSAGE;
            }
            default: {
                return WPSConstants.CancelTransaction.CANCEL_TRANSACTION_DEFAULT_DISPLAY_MESSAGE;
            }
        }
    }

}
