package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.PaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.common.PaymentInstrumentDTO;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsWithPreselectionResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class FetchCoFTopupPaymentInstrumentsWithPreselectionDomainResponseBuilder extends BaseDomainResponseBuilder<FetchCoFTopupPaymentInstrumentsWithPreselectionResponse, CoFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext> {

    private CoFTopupMapper cofTopupMapper = CoFTopupMapper.INSTANCE;

    @Override
    public CoFTopupTxnResponseDomainContext buildDomainResponse(CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext) throws ApplicationException {
        return CoFTopupTxnResponseDomainContext.builder().build();
    }

    @Override
    public FetchCoFTopupPaymentInstrumentsWithPreselectionResponse buildDomainResponse(CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext cofTopupTxnResponseDomainContext) throws ApplicationException {
        List<PaymentInstrument> paymentInstrumentList = cofTopupTxnResponseDomainContext.getTransaction().getCofTopupPaymentOptions().getPaymentInstruments().getPaymentInstrumentList();
        List<PaymentInstrumentDTO> paymentInstrumentDTOS = paymentInstrumentList.stream().map(instrument -> {
            if (instrument instanceof CardPaymentInstrument) {
                return cofTopupMapper.mapCardPaymentInstrumentToPaymentInstrumentDTO((CardPaymentInstrument) instrument);
            }
            return null;
        }).collect(Collectors.toList());

        return FetchCoFTopupPaymentInstrumentsWithPreselectionResponse.builder()
                .paymentOptions(paymentInstrumentDTOS)
                .build();
    }
}