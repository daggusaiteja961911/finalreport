package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeInitRequestEWS;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class MigrationValidateChargeInitDomainRequestBuilder extends BaseDomainRequestBuilder<ValidateChargeInitRequestEWS, BillPayTxnRequestDomainContext> {
    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(ValidateChargeInitRequestEWS validateChargeInitRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                .cardSubTransaction(CardPaymentTransaction.CardSubTransaction.builder()
                        .id(validateChargeInitRequestEWS.getCardTransactionId())
                        .build())
                .build();

        return BillPayTxnRequestDomainContext.builder()
                .transaction(BillPayTransaction.builder()
                        .transactionType(TransactionType.BILL_PAY)
                        .cardPaymentTransactionList(cardPaymentTransaction)
                        .customer(Customer.builder()
                                .customerAccountId(validateChargeInitRequestEWS.getCustomerAccountId())
                                .build())
                        .build())
                .headers(headers)
                .build();
    }
}
