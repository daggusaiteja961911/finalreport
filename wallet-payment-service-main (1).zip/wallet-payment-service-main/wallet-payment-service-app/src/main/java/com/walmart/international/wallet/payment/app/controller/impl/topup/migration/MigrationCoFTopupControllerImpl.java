package com.walmart.international.wallet.payment.app.controller.impl.topup.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.wallet.payment.app.controller.topup.migration.MigrationCoFTopupController;
import com.walmart.international.wallet.payment.app.service.migration.MigrationCoFTopupService;
import com.walmart.international.wallet.payment.dto.request.migration.CancelCoFTopupRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.LoadMoneyRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelCoFTopupResponseEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UnifiedPaymentResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class MigrationCoFTopupControllerImpl implements MigrationCoFTopupController {

    @Autowired
    MigrationCoFTopupService migrationCoFTopupService;

    @Override
    @Metered(level1 = "Payment", level2 = "fetchCoFTopupPaymentInstruments", level3 = "All", metricName = "CASHI_TRANSACTION")
    public FetchPaymentOptionsResponse fetchCoFTopupPaymentInstruments(UUID customerAccountId, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationCoFTopupService.fetchCoFTopupPaymentInstruments(customerAccountId, headers);
    }

    @Override
    public FetchPaymentOptionsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(UUID customerAccountId, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationCoFTopupService.fetchCoFTopupPaymentInstrumentsWithPreselection(customerAccountId, headers);
    }

    @Override
    public UnifiedPaymentResponse loadMoney(UUID customerAccountId, LoadMoneyRequestEWS loadMoneyRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationCoFTopupService.loadMoney(customerAccountId, loadMoneyRequestEWS, headers);
    }

    @Override
    public UnifiedPaymentResponse validateCharge(UUID customerAccountId, ValidateChargeRequestEWS validateChargeRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationCoFTopupService.validateCharge(customerAccountId, validateChargeRequestEWS, headers);
    }

    @Override
    @Metered(level1 = "Payment", level2 = "cancelCoFTopup", level3 = "All", metricName = "CASHI_TRANSACTION")
    public CancelCoFTopupResponseEWS cancelPayment(UUID customerAccountId, UUID transactionId, CancelCoFTopupRequestEWS cancelCoFTopupRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationCoFTopupService.cancelPayment(customerAccountId, transactionId, cancelCoFTopupRequestEWS, headers);
    }
}
