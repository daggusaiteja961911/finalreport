package com.walmart.international.wallet.payment.app.controller.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheEvictRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheReloadRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataUpdateInfoRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerCategoriesResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataCacheAlterResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataUpdateInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerIncorrectSearchKeywordsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PopularBillersResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.UUID;

@RequestMapping("/services/biller-data")
@Tag(name = "BillerController API", description = "APIs to perform Biller data related activities.")
public interface BillerController {
    @GetMapping(value = "/v1/biller/categories", produces = "application/json")
    BillerCategoriesResponse getBillerCategories(@RequestParam int billerCategoryVersion);

    @GetMapping(value = "/v1/biller/popular", produces = "application/json")
    PopularBillersResponse getPopularBillers() throws ApplicationException;

    @GetMapping(value = {"/v1/biller", "/v1/biller/{billerId}"}, produces = "application/json")
    BillerByIdResponse getBillerById(@PathVariable(required = false) UUID billerId,
                                     @RequestParam(required = false) String processorBillerId) throws ApplicationException;

    @PostMapping(value = "/updateInfo", consumes = "application/json", produces = "application/json")
    BillerDataUpdateInfoResponse getBillerDataUpdateInfo(@RequestBody BillerDataUpdateInfoRequest billerDataUpdateInfoRequest);

    @PutMapping(value = "/cache/reload", consumes = "application/json", produces = "application/json")
    BillerDataCacheAlterResponse reloadCacheForBillerData(@RequestBody BillerDataCacheReloadRequest billerDataCacheReloadRequest) throws ApplicationException;

    @PostMapping(value = "/cache/evict", consumes = "application/json", produces = "application/json")
    BillerDataCacheAlterResponse evictCacheForBillerData(@RequestBody BillerDataCacheEvictRequest billerDataCacheEvictRequest);

    @GetMapping(value = "/v1/biller/promotions", produces = "application/json")
    BillerPromotionsResponse getBillerPromotions(@RequestParam(required = false) String billerCategoryIds, @RequestParam(required = false) String processorBillerIds);

    @GetMapping(value = "/incorrect-search-keywords", produces = "application/json")
    BillerIncorrectSearchKeywordsResponse getBillerIncorrectSearchKeywords() throws ApplicationException;
}
