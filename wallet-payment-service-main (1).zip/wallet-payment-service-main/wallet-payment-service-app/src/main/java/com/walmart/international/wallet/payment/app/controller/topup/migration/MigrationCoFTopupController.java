package com.walmart.international.wallet.payment.app.controller.topup.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.migration.CancelCoFTopupRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.LoadMoneyRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelCoFTopupResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UnifiedPaymentResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.UUID;

@RequestMapping("/ews-internal")
@Tag(name = "MigrationCoFTopupController API", description = "Migration APIs to perform CoF Topup related activities.")
public interface MigrationCoFTopupController {

    @GetMapping(value = "/V1/load-money/payment/option/{customerAccountId}", produces = "application/json")
    FetchPaymentOptionsResponse fetchCoFTopupPaymentInstruments(@PathVariable UUID customerAccountId, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @GetMapping(value = "/V2/load-money/payment/option/{customerAccountId}", produces = "application/json")
    FetchPaymentOptionsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(@PathVariable UUID customerAccountId, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/V2/account/{customerAccountId}/loadMoney", consumes = "application/json", produces = "application/json")
    UnifiedPaymentResponse loadMoney(@PathVariable UUID customerAccountId,
                                     @RequestBody LoadMoneyRequestEWS loadMoneyRequestEWS,
                                     @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/V1/payment/cancel/{customerAccountId}/{transactionId}", consumes = "application/json", produces = "application/json")
    CancelCoFTopupResponseEWS cancelPayment(@PathVariable UUID customerAccountId,
                                            @PathVariable UUID transactionId,
                                            @RequestBody CancelCoFTopupRequestEWS cancelCoFTopupRequestEWS,
                                            @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/account/{customerAccountId}/validate-charge", consumes = "application/json", produces = "application/json")
    UnifiedPaymentResponse validateCharge(@PathVariable UUID customerAccountId,
                                          @RequestBody ValidateChargeRequestEWS validateChargeRequestEWS,
                                          @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;
}
