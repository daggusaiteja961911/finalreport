package com.walmart.international.wallet.payment.app;

import com.walmart.international.digiwallet.service.strati.CashiSpringBootInterceptorConfig;
import com.walmart.international.digiwallet.service.strati.data.AuditConfig;
import com.walmart.international.digiwallet.service.strati.i8n.database.LanguageEntity;
import com.walmart.international.digiwallet.service.strati.telemetry.filter.CashiServletMetricsFilter;
import com.walmart.international.digiwallet.service.strati.telemetry.filter.CashiSpringBootMetricsFilter;
import com.walmart.international.digiwallet.service.web.rest.error.handler.PartnerErrorHandler;
import com.walmart.international.digiwallet.service.web.rest.exception.GlobalExceptionHandler;
import com.walmart.international.digiwallet.service.web.rest.i8n.local.LocaleResolverConfig;
import com.walmart.international.digiwallet.service.web.rest.logging.CashiLoggingFilter;
import com.walmart.international.digiwallet.service.web.rest.logging.CashiSpringBootLoggingDispatcherServlet;
import com.walmart.international.ewallet.services.events.config.EnableEventRecovery;
import com.walmart.international.ewallet.services.events.config.EnableWalletEvents;
import com.walmart.international.services.digitalwallet.eventrecovery.service.SchedulerService;
import com.walmart.international.services.digitalwallet.httpclient.config.EnableEwalletClient;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.security.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import javax.annotation.PostConstruct;
import java.util.TimeZone;

@OpenAPIDefinition(servers = {@Server(url = "/", description = "Default Server URL")})
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class, SecurityAutoConfiguration.class, ManagementWebSecurityAutoConfiguration.class})
@ComponentScan(basePackages = {
        "com.walmart.international.wallet",
        "io.strati.tunr.utils.client",
        "com.walmart.international.digiwallet.service",
        "com.walmart.international.notification",
        "com.walmart.international.services.digitalwallet.httpclient",
        "com.walmart.international.services.digitalwallet.eventrecovery",
        "com.walmart.international.services.payment.core", // payment core
        "com.walmart.international.ewallet.payment", // payment adapter
        "com.walmart.international.ewallet.services.events"
}, excludeFilters = {
        @ComponentScan.Filter(type = FilterType.ASPECTJ,
                pattern = "com.walmart.international.digiwallet.service.strati.i8n.database.* ||" +
                        "(com.walmart.international.digiwallet.service.web.rest.aspects.impl.* &&" +
                        "!com.walmart.international.digiwallet.service.web.rest.aspects.impl.AuthTokenSecuredAspect)"),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CashiSpringBootMetricsFilter.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CashiServletMetricsFilter.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CashiLoggingFilter.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CashiSpringBootLoggingDispatcherServlet.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CashiSpringBootInterceptorConfig.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = GlobalExceptionHandler.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = PartnerErrorHandler.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = LocaleResolverConfig.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = SchedulerService.class)
})
@EntityScan(basePackages = {
        "com.walmart.international.services.payment.core.model",
        "com.walmart.international.wallet.payment.data.dao.entity",
        "com.walmart.international.services.digitalwallet.eventrecovery.model"
}, basePackageClasses = {LanguageEntity.class})
@EnableJpaRepositories({
        "com.walmart.international.services.payment.core.dao", // payment-core repository
        "com.walmart.international.wallet.payment.data.dao.repository",
        "com.walmart.international.services.digitalwallet.eventrecovery.dao"
})
@EnableEwalletClient
@EnableEventRecovery
@EnableWalletEvents
@Import(AuditConfig.class)
public class WalletPaymentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(WalletPaymentServiceApplication.class, args);
    }

    @PostConstruct
    public void init() {
        // Setting Spring Boot SetTimeZone
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    }
}
