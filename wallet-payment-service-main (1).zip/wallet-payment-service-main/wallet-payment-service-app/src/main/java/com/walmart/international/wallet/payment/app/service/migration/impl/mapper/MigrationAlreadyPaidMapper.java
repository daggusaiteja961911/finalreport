package com.walmart.international.wallet.payment.app.service.migration.impl.mapper;

import com.walmart.international.wallet.payment.core.domain.model.request.AlreadyPaidRequest;
import com.walmart.international.wallet.payment.core.domain.model.response.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.dto.request.migration.AlreadyPaidRequestDTOEWS;
import com.walmart.international.wallet.payment.dto.response.migration.AlreadyPaidResponseDTOEWS;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Mapper
public interface MigrationAlreadyPaidMapper {

    MigrationAlreadyPaidMapper INSTANCE = Mappers.getMapper(MigrationAlreadyPaidMapper.class);

    AlreadyPaidRequest mapAlreadyPaidRequestDTOToDomainRequest(AlreadyPaidRequestDTOEWS alreadyPaidRequestDTO);

    @Mapping(target = "id", source = "customerBillAccountId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "billerAccountUpdatedAt", source = "customerBillAccountUpdatedAt", qualifiedByName = "mapCustomerBillAccountUpdatedAtDate")
    AlreadyPaidResponseDTOEWS mapAlreadyPaidResponseFromDomainResponseToDTO(AlreadyPaidResponse alreadyPaidResponse);

    @Named("mapCustomerBillAccountUpdatedAtDate")
    default Date mapCustomerBillAccountUpdatedAtDate(LocalDateTime customerBillAccountUpdatedAt) {
        return Date.from(customerBillAccountUpdatedAt.atZone(ZoneId.systemDefault()).toInstant());
    }

}
