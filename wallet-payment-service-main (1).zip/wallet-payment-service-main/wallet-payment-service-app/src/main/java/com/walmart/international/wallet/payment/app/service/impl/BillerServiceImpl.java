package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.commons.collections.CollectionUtils;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.app.service.impl.mapper.BillerDTOMapper;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerIncorrectSearchKeywordsResponse;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheEvictRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheReloadRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataUpdateInfoRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerCategoriesResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataCacheAlterResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataUpdateInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerInformation;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPlanDetailUpdateInfo;
import com.walmart.international.wallet.payment.dto.response.billpay.GetPopularBillersBillerDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.PopularBillersResponse;
import com.walmart.international.wallet.payment.app.service.BillerService;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.service.BillerCoreService;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Component
@Slf4j
public class BillerServiceImpl implements BillerService {

    private BillerDTOMapper billerDTOMapper = BillerDTOMapper.INSTANCE;

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @Autowired
    private BillerCoreService billerCoreService;

    @PostConstruct
    public void init() {
        billerCoreService.reloadCacheForBillerCategoryData(walletPaymentServiceConfiguration.getBillerCategoryVersions());
    }

    public BillerCategoriesResponse getBillerCategories(int billerCategoryVersion) {
        return getBillerCategoriesMapFromCache(billerCategoryVersion);
    }

    private BillerCategoriesResponse getBillerCategoriesMapFromCache(int billerCategoryVersion) {
        List<BillerCategory> billerCategoriesList;
        Date billerCategoryDataLastUpdatedAt;

        billerCategoriesList = billerCoreService.getBillerCategoriesList(billerCategoryVersion);
        billerCategoryDataLastUpdatedAt = billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp();

        if (CollectionUtils.isNotEmpty(billerCategoriesList)) {
            return BillerCategoriesResponse.builder()
                    .categories(billerDTOMapper.mapBillerCategoriesListToBillerCategoryDTOList(billerCategoriesList))
                    .billerCategoryDataLastUpdatedAt(billerCategoryDataLastUpdatedAt)
                    .build();
        }
        return BillerCategoriesResponse.builder()
                .categories(new ArrayList<>())
                .build();
    }

    public PopularBillersResponse getPopularBillers() throws BusinessValidationException {
        List<Biller> popularBillersList = billerCoreService.getPopularBillers();
        List<GetPopularBillersBillerDTO> popularBillersDTOList = billerDTOMapper.mapBillerEntityListToGetPopularBillersBillerDTOList(popularBillersList);
        return PopularBillersResponse.builder().billers(popularBillersDTOList).build();
    }

    public BillerByIdResponse getBillerById(UUID billerId, String processorBillerId) throws ApplicationException {
        Biller biller = billerCoreService.fetchAndCacheBillerData(billerId, processorBillerId);
        return prepareBillerDataResponse(biller);
    }

    private BillerByIdResponse prepareBillerDataResponse(Biller biller) {
        BillerInformation billerInformation = billerDTOMapper.mapBillerInformation(biller);
        List<BillerByIdDTO> billerByIdDTOS;
        if (CollectionUtils.isNotEmpty(biller.getSubBillers())) {
            billerByIdDTOS = billerDTOMapper.mapBillerEntitiesToDTO(biller.getSubBillers());
        } else {
            billerByIdDTOS = billerDTOMapper.mapBillerEntitiesToDTO(Collections.singletonList(biller));
        }
        return BillerByIdResponse.builder()
                .billerInformation(billerInformation)
                .billers(billerByIdDTOS)
                .lastUpdatedAt(biller.getMaxUpdateTimestamp())
                .build();
    }

    public BillerDataUpdateInfoResponse getBillerDataUpdateInfo(BillerDataUpdateInfoRequest billerDataUpdateInfoRequest) {
        Set<String> processorBillerIds = billerDataUpdateInfoRequest.getProcessorBillerIds();

        Date billerCategoryDataLastUpdatedAt = billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp();
        Date billerIncorrectSearchKeywordsLastUpdatedAt = billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp();
        Map<String, Object> billerDataLastUpdatedAtMap = billerCoreService.fetchBillerDataLastUpdatedAtMap(new ArrayList<>(processorBillerIds));
        List<BillerPlanDetailUpdateInfo> billerPlanDetailUpdates = billerDTOMapper.mapBillerDataLastUpdatedAtMap(billerDataLastUpdatedAtMap);

        return BillerDataUpdateInfoResponse.builder()
                .billerCategoryDataLastUpdatedAt(billerCategoryDataLastUpdatedAt)
                .billerPlanDetailUpdateInfoList(billerPlanDetailUpdates)
                .billerIncorrectSearchKeywordsLastUpdatedAt(billerIncorrectSearchKeywordsLastUpdatedAt)
                .build();
    }

    public BillerDataCacheAlterResponse reloadCacheForBillerData(BillerDataCacheReloadRequest billerDataCacheReloadRequest) {
        if (billerDataCacheReloadRequest.isBillerCategoryDataReloadRequired()) {
            log.info("Cache reloading for biller category data started at {}", new Date());
            billerCoreService.reloadCacheForBillerCategoryData(walletPaymentServiceConfiguration.getBillerCategoryVersions());
            log.info("Cache reloading for biller category data ended at {}", new Date());
        }

        if (billerDataCacheReloadRequest.isBillerIncorrectSearchKeywordsCacheUpdateRequired()) {
            log.info("Cache reloading for biller incorrect search data started at {}", new Date());
            billerCoreService.reloadIncorrectSearchDataInCache();
            log.info("Cache reloading for biller incorrect search data ended at {}", new Date());
        }

        Set<String> retryProcessorBillerIds = new HashSet<>();
        if (CollectionUtils.isNotEmpty(billerDataCacheReloadRequest.getProcessorBillerIds())) {
            retryProcessorBillerIds = billerCoreService.reloadCacheForBillerData(billerDataCacheReloadRequest.getProcessorBillerIds());
        }

        return BillerDataCacheAlterResponse.builder()
                .processorBillerIdsToRetry(retryProcessorBillerIds)
                .build();
    }

    public BillerDataCacheAlterResponse evictCacheForBillerData(BillerDataCacheEvictRequest billerDataCacheEvictRequest) {
        List<String> processorBillerIdsToEvict = new ArrayList<>(billerDataCacheEvictRequest.getProcessorBillerIds());
        if (billerDataCacheEvictRequest.isEvictCacheForAllBillers()) {
            processorBillerIdsToEvict = billerCoreService.getProcessorBillerIdsOfBillersWhoseDataIsCached();
        }
        Set<String> retryProcessorBillerIds = new HashSet<>();
        if (CollectionUtils.isNotEmpty(processorBillerIdsToEvict)) {
            retryProcessorBillerIds = billerCoreService.evictCacheForBillerAndUpdateTimestampData(processorBillerIdsToEvict);
        }
        return BillerDataCacheAlterResponse.builder().
                processorBillerIdsToRetry(retryProcessorBillerIds).
                build();
    }

    @Override
    public BillerIncorrectSearchKeywordsResponse getBillerIncorrectSearchKeywords() throws ApplicationException {
        HashMap<String, List<String>> billerIncorrectSearchKeywordsMap;
        Date billerIncorrectSearchKeywordsLastUpdatedAt;

        billerIncorrectSearchKeywordsMap = billerCoreService.fetchBillerIncorrectSearchKeywordMap();
        billerIncorrectSearchKeywordsLastUpdatedAt = billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp();

        if (!billerIncorrectSearchKeywordsMap.isEmpty()) {
            return BillerIncorrectSearchKeywordsResponse.builder()
                    .billerIncorrectSearchKeywords(billerIncorrectSearchKeywordsMap)
                    .billerIncorrectSearchKeywordsLastUpdatedAt(billerIncorrectSearchKeywordsLastUpdatedAt)
                    .build();
        }
        return BillerIncorrectSearchKeywordsResponse.builder()
                .billerIncorrectSearchKeywords(new HashMap<>())
                .build();
    }
}
