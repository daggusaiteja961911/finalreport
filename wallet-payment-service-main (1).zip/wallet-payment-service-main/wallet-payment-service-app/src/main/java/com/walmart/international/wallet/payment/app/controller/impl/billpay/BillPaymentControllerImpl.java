package com.walmart.international.wallet.payment.app.controller.impl.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.wallet.payment.app.controller.billpay.BillPaymentController;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillResponse;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.app.service.BillPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillPaymentControllerImpl implements BillPaymentController {

    @Autowired
    private BillPaymentService billPaymentService;

    @Override
    @Metered(level1 = "Payment", level2 = "fetchBillPayPaymentInstruments", level3 = "All", metricName = "CASHI_TRANSACTION")
    public FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return billPaymentService.fetchBillPayPaymentInstruments(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    @Metered(level1 = "Payment", level2 = "fetchBillPayPaymentInstrumentsWithPreselection", level3 = "All", metricName = "CASHI_TRANSACTION")
    public FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return billPaymentService.fetchBillPayPaymentInstrumentsWithPreselection(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    @Metered(level1 = "Bill", level2 = "PayBills", level3 = "All", metricName = "CASHI_TRANSACTION")
    public PayBillResponse payBillV1(@RequestBody PayBillRequest request,
                                     @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException {
        return billPaymentService.payBill(request, headers);
    }

    @Override
    @Metered(level1 = "Payment", level2 = "CancelBillPay", level3 = "All", metricName = "CASHI_TRANSACTION")
    public CancelPayBillInitResponse cancelPayBillInit(@RequestBody CancelPayBillInitRequest cancelPayBillInitRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException {
        return billPaymentService.cancelPayBillInit(cancelPayBillInitRequest, headers);
    }
}
