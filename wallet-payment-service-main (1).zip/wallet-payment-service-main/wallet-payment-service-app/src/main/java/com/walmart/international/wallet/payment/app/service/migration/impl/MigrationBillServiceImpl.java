package com.walmart.international.wallet.payment.app.service.migration.impl;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.app.service.migration.MigrationBillService;
import com.walmart.international.wallet.payment.app.service.migration.impl.mapper.MigrationAlreadyPaidMapper;
import com.walmart.international.wallet.payment.app.service.migration.impl.mapper.MigrationBillDTOMapper;
import com.walmart.international.wallet.payment.core.config.ccm.BillReminderConfiguration;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.AlreadyPaidRequest;
import com.walmart.international.wallet.payment.core.domain.model.response.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.core.domain.model.response.CustomerBillAccountsByType;
import com.walmart.international.wallet.payment.core.service.BillCoreService;
import com.walmart.international.wallet.payment.core.service.BillerCoreService;
import com.walmart.international.wallet.payment.data.constant.enums.BillType;
import com.walmart.international.wallet.payment.dto.request.migration.AlreadyPaidRequestDTOEWS;
import com.walmart.international.wallet.payment.dto.request.migration.CreateBillRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.DueAndSavedBillerRequest;
import com.walmart.international.wallet.payment.dto.request.migration.GetSavedBillerAccountsRequest;
import com.walmart.international.wallet.payment.dto.response.migration.AlreadyPaidResponseDTOEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CreateBillV2DTO;
import com.walmart.international.wallet.payment.dto.response.migration.DueAndSavedBillsDTO;
import com.walmart.international.wallet.payment.dto.response.migration.GetBillsSavedBillerAccountDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountResponseDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UpdateSavedBillerAccountRequest;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.joda.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class MigrationBillServiceImpl implements MigrationBillService {

    @Autowired
    private BillCoreService billCoreService;

    @Autowired
    private BillerCoreService billerCoreService;

    @Autowired
    private WalletServiceRouter walletServiceRouter;

    @ManagedConfiguration
    private BillReminderConfiguration billReminderConfiguration;

    private MigrationBillDTOMapper migrationBillDTOMapper = MigrationBillDTOMapper.INSTANCE;

    private MigrationAlreadyPaidMapper migrationAlreadyPaidMapper = MigrationAlreadyPaidMapper.INSTANCE;

    @Override
    public CreateBillV2DTO createBill(UUID customerAccountId, CreateBillRequestEWS createBillRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        createBillRequestEWS.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationCreateBill(createBillRequestEWS, headers);
    }

    @Override
    public SavedBillerAccountResponseDTO deleteSavedBillerAccount(UUID customerAccountId, UUID savedBillerAccountId) throws BusinessValidationException {
        CustomerBillAccount customerBillAccount = billCoreService.deleteCustomerBillAccount(savedBillerAccountId, customerAccountId);
        SavedBillerAccountResponseDTO savedBillerAccountResponseDTO = migrationBillDTOMapper.mapCustomerBillAccountToSavedBIllerAccountResponseDTO(customerBillAccount);
        savedBillerAccountResponseDTO.setBillerAccountDeletedAt(new Date());
        return savedBillerAccountResponseDTO;
    }

    @Override
    public SavedBillerAccountsResponse getAllSavedBillerAccountsForBiller(UUID customerAccountId, GetSavedBillerAccountsRequest getSavedBillerAccountsRequest) throws ApplicationException {
        String processorBillerId = getSavedBillerAccountsRequest.getBillerId().toString();
        String accountNumber = getSavedBillerAccountsRequest.getAccountNumber();
        List<CustomerBillAccount> customerBillAccountList = billCoreService.getAllSavedBillsForBiller(processorBillerId, customerAccountId, accountNumber);
        if (CollectionUtils.isEmpty(customerBillAccountList)) {
            return SavedBillerAccountsResponse.builder()
                    .hasBillerAccountSaved(false)
                    .build();
        }
        List<SavedBillerAccountDTO> savedBillerAccountDTOs = migrationBillDTOMapper.mapToSavedBillerAccountDTOsFromCustomerBillAccounts(customerBillAccountList);
        return SavedBillerAccountsResponse.builder()
                .hasBillerAccountSaved(true)
                .savedBillerAccounts(savedBillerAccountDTOs)
                .build();
    }

    public SavedBillerAccountResponseDTO updateSavedBillerAccount(UUID customerAccountId, UUID savedBillerAccountId, UpdateSavedBillerAccountRequest updateSavedBillerAccountRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        updateSavedBillerAccountRequest.setSavedBillerAccountId(savedBillerAccountId);
        updateSavedBillerAccountRequest.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationUpdateCustomerBillAccount(updateSavedBillerAccountRequest, headers);
    }

    @Override
    public DueAndSavedBillsDTO getBills(DueAndSavedBillerRequest dueAndSavedBillerRequest, UUID customerAccountId, MultiValueMap<String, String> headers) {

        List<BillType> billTypes = new ArrayList<>();
        if (Objects.nonNull(dueAndSavedBillerRequest) && !CollectionUtils.isEmpty(dueAndSavedBillerRequest.getType())) {
            dueAndSavedBillerRequest.getType().forEach(billType -> billTypes.add(BillType.valueOf(billType)));
        } else {
            billTypes.add(BillType.ALL);
        }

        int dueBillsDaysLimit = billReminderConfiguration.getDaysToConsiderBillsAsDueBills();
        int maxDaysForNudge = billReminderConfiguration.getMaxDaysForNudge();
        int minDaysForNudge = billReminderConfiguration.getMinDaysForNudge();
        int count = Objects.nonNull(dueAndSavedBillerRequest) && Objects.nonNull(dueAndSavedBillerRequest.getCount()) ? dueAndSavedBillerRequest.getCount() : Integer.MAX_VALUE;
        count = billTypes.contains(BillType.ALL) ? Integer.MAX_VALUE : count;
        Pageable pageable = PageRequest.of(0, count);

        List<BillerCategory> billerCategoriesList = billerCoreService.getBillerCategoriesList(1);
        HashMap<UUID, UUID> billerIdToBillerCategoryMap = new HashMap<>();
        HashMap<UUID, String> billerIdToBillerCategoryNameMap = new HashMap<>();

        log.info("Fetching bills for customerAccountId : {}", customerAccountId);

        CustomerBillAccountsByType customerBillAccountsByType = billCoreService.getCustomerBillAccountsByType(customerAccountId, billTypes, dueBillsDaysLimit, maxDaysForNudge, minDaysForNudge, pageable);

        return DueAndSavedBillsDTO.builder()
                .dueBills(getCustomerBillAccountDTOList(BillType.DUE, customerBillAccountsByType.getDueBills(), billerCategoriesList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap))
                .paidBills(getCustomerBillAccountDTOList(BillType.PAID, customerBillAccountsByType.getPaidBills(), billerCategoriesList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap))
                .overdueBills(getCustomerBillAccountDTOList(BillType.OVERDUE, customerBillAccountsByType.getOverDueBills(), billerCategoriesList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap)).build();
    }

    private List<GetBillsSavedBillerAccountDTO> getCustomerBillAccountDTOList(BillType billType, List<CustomerBillAccount> customerBillAccountList, List<BillerCategory> billerCategoryList, HashMap<UUID, UUID> billerIdToBillerCategoryMap, HashMap<UUID, String> billerIdToBillerCategoryNameMap) {
        List<GetBillsSavedBillerAccountDTO> getBillsSavedBillerAccountDTOList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(customerBillAccountList)) {
            customerBillAccountList.forEach(customerBillAccount -> getBillsSavedBillerAccountDTOList.add(getSavedBillerAccountDTO(billType, customerBillAccount, billerCategoryList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap)));
        }
        return getBillsSavedBillerAccountDTOList;
    }


    private GetBillsSavedBillerAccountDTO getSavedBillerAccountDTO(BillType billType, CustomerBillAccount customerBillAccount, List<BillerCategory> billerCategoryList, HashMap<UUID, UUID> billerIdToBillerCategoryIdMap, HashMap<UUID, String> billerIdToBillerCategoryNameMap) {
        Biller biller = customerBillAccount.getBiller();
        boolean isGiftCardBiller = biller.isBillTypeGiftCard();
        log.info("Building customer bill account DTO for customerBillAccountId : {}, billType : {}, customerAccountId : {}", customerBillAccount.getCustomerBillAccountId(), billType, customerBillAccount.getCustomerAccountId());
        Integer queryProcessorBillerId = getQueryProcessorBillerId(biller);
        UUID queryBillerId = getQueryBillerId(biller);
        getBillerCategoryIdAndNameForBiller(billerCategoryList, billerIdToBillerCategoryIdMap, billerIdToBillerCategoryNameMap, queryBillerId);
        UUID categoryId = billerIdToBillerCategoryIdMap.get(queryBillerId);
        String categoryName = billerIdToBillerCategoryNameMap.get(queryBillerId);

        return GetBillsSavedBillerAccountDTO.builder()
                .id(customerBillAccount.getCustomerBillAccountId())
                .customerAccountId(customerBillAccount.getCustomerAccountId())
                .billerId(Integer.valueOf(customerBillAccount.getBiller().getProcessorBillerId()))
                .queryBillerId(queryProcessorBillerId)
                .billerName(biller.getDisplayName())
                .productName(biller.getProductDisplayName())
                .accountNumber(isGiftCardBiller ? null : customerBillAccount.getAccountNumber())
                .accountAlias(customerBillAccount.getAlias())
                .imageURL(biller.getImageURL())
                .dueDate(billType.equals(BillType.PAID) ? null : customerBillAccount.getDueDate())
                .dueAmount(customerBillAccount.getDueAmount())
                .dueAmountCurrency(customerBillAccount.getDueAmountCurrencyUnit())
                .lastPaidDate(customerBillAccount.getLastPaidDate())
                .lastPaidAmount(customerBillAccount.getLastPaidAmount())
                .lastPaidAmountCurrency(customerBillAccount.getLastPaidAmountCurrencyUnit())
                .customerBillId(customerBillAccount.getProcessorBillAccountId())
                .categoryId(categoryId)
                .categoryName(categoryName)
                .info(!billType.equals(BillType.PAID) ? getDueBillsInfoDTO(customerBillAccount) : null)
                .build();

    }

    private void getBillerCategoryIdAndNameForBiller(List<BillerCategory> billerCategoryList, HashMap<UUID, UUID> billerIdToBillerCategoryIdMap, HashMap<UUID, String> billerIdToBillerCategoryNameMap, UUID billerId) {
        if (!billerIdToBillerCategoryIdMap.isEmpty() && billerIdToBillerCategoryIdMap.containsKey(billerId)) {
            return;
        }
        if (!billerCategoryList.isEmpty()) {
            for (BillerCategory billerCategory : billerCategoryList) {
                List<Biller> billerList = billerCategory.getBillers();
                boolean isBillerMappedToCategory = billerList.stream().anyMatch(in -> in.getBillerId().equals(billerId) || (!CollectionUtils.isEmpty(in.getSubBillers()) && in.getSubBillers().stream().anyMatch(in1 -> in1.getBillerId().equals(billerId))));
                if (isBillerMappedToCategory) {
                    billerIdToBillerCategoryIdMap.put(billerId, billerCategory.getId());
                    billerIdToBillerCategoryNameMap.put(billerId, billerCategory.getCategoryName());
                    return ;
                }
            }
        }
    }

    private Integer getParentProcessorBillerId(Biller biller) {
        if (Objects.nonNull(biller.getParentBiller())) {
            return Integer.parseInt(biller.getParentBiller().getProcessorBillerId());
        }
        return null;
    }

    private Integer getQueryProcessorBillerId(Biller biller) {
        Integer parentProcessorBillerId = getParentProcessorBillerId(biller);
        if (Objects.nonNull(biller.getProductDisplayName()) || Objects.isNull(parentProcessorBillerId)) {
            return Integer.parseInt(biller.getProcessorBillerId());
        }
        return parentProcessorBillerId;
    }

    private Biller getParentBiller(Biller biller) {
        if (Objects.nonNull(biller.getParentBiller())) {
            return biller.getParentBiller();
        } else {
            return null;
        }
    }

    private UUID getQueryBillerId(Biller biller) {
        Biller parentBiller = getParentBiller(biller);
        if (Objects.isNull(parentBiller) || parentBiller.getSubBillerShownAsProduct()) {
            return biller.getBillerId();
        }
        return parentBiller.getBillerId();
    }

    private GetBillsSavedBillerAccountDTO.DueBillsInfoDTO getDueBillsInfoDTO(CustomerBillAccount customerBillAccount) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate todayDate = LocalDate.now();
        if (customerBillAccount.getDueDate() != null) {
            LocalDate dueDate = getDateInLocalDateFormat(LocalDateTime.fromDateFields(customerBillAccount.getDueDate()).toLocalDate());
            if (dueDate.isAfter(todayDate) || dueDate.isEqual(todayDate)) {
                if (dueDate.isEqual(todayDate)) {
                    return GetBillsSavedBillerAccountDTO.DueBillsInfoDTO.builder()
                            .type(WPSConstants.Bills.DUE_BILL_TYPE_TODAY)
                            .text(WPSConstants.Bills.DUE_TODAY)
                            .build();
                } else if (dueDate.equals(todayDate.plusDays(1))) {
                    return GetBillsSavedBillerAccountDTO.DueBillsInfoDTO.builder()
                            .type(WPSConstants.Bills.DUE_BILL_TYPE_LATER)
                            .text(WPSConstants.Bills.DUE_TOMORROW)
                            .build();
                } else {
                    return GetBillsSavedBillerAccountDTO.DueBillsInfoDTO.builder()
                            .type(WPSConstants.Bills.DUE_BILL_TYPE_LATER)
                            .text(WPSConstants.Bills.DUE_BILL_DESC.concat(dueDate.format(formatter)))
                            .build();
                }
            } else if (todayDate.isAfter(dueDate)) {
                return GetBillsSavedBillerAccountDTO.DueBillsInfoDTO.builder()
                        .type(WPSConstants.Bills.OVERDUE_BILL)
                        .text(WPSConstants.Bills.OVERDUE_BILL_PAY_DESC)
                        .build();
            }
        } else if (customerBillAccount.getNudgeBucket() != null) {
            return GetBillsSavedBillerAccountDTO.DueBillsInfoDTO.builder()
                    .type(WPSConstants.Bills.NUDGE_BILL)
                    .text(WPSConstants.Bills.NUDGE_BILL_DESC)
                    .build();
        }
        return null;
    }

    private LocalDate getDateInLocalDateFormat(io.strati.libs.joda.time.LocalDate dueDate) {
        return LocalDate.of(dueDate.getYear(), dueDate.getMonthOfYear(), dueDate.getDayOfMonth());
    }

    @Override
    public AlreadyPaidResponseDTOEWS markAlreadyPaid(AlreadyPaidRequestDTOEWS alreadyPaidRequestDTO, UUID customerAccountId, UUID customerBillAccountId, MultiValueMap<String, String> headers) throws ApplicationException {
        AlreadyPaidRequest alreadyPaidRequest = migrationAlreadyPaidMapper.mapAlreadyPaidRequestDTOToDomainRequest(alreadyPaidRequestDTO);
        AlreadyPaidResponse alreadyPaidResponse = billCoreService.updateCustomerBillAccountAsAlreadyPaidAndSendReminders(alreadyPaidRequest, customerAccountId, customerBillAccountId);
        return migrationAlreadyPaidMapper.mapAlreadyPaidResponseFromDomainResponseToDTO(alreadyPaidResponse);
    }

}
