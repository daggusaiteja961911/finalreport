package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationBillMapper;
import com.walmart.international.wallet.payment.dto.response.migration.UpdateSavedBillerAccountRequest;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class MigrationUpdateCustomerBillAccountDomainRequestBuilder extends BaseDomainRequestBuilder<UpdateSavedBillerAccountRequest, BillRequestDomainContext> {

    MigrationBillMapper migrationBillMapper = MigrationBillMapper.INSTANCE;

    @Override
    public BillRequestDomainContext buildDomainRequest(UpdateSavedBillerAccountRequest updateSavedBillerAccountRequest, MultiValueMap<String, String> headers, Tenant tenant) {

        return BillRequestDomainContext.builder()
                .customerBillAccount(migrationBillMapper.updateSavedBillerAccountRequestToCustomerBillAccount(updateSavedBillerAccountRequest))
                .headers(headers)
                .build();
    }
}