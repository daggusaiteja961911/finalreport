package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import org.springframework.stereotype.Component;

@Component
public class CreateBillFlowFactory extends FlowFactory<BillRequestDomainContext> {

    private FlowType deriveCreateBillFlowForMexico() {
        return MXFlowType.CREATE_BILL;
    }

    @Override
    public FlowType deriveFlow(BillRequestDomainContext billRequestDomainContext, Tenant tenant) throws ApplicationException {
        switch (tenant) {
            case MX:
                return deriveCreateBillFlowForMexico();
            case CA:
            case UNKNOWN:
            default:
                throw new ProcessingException(ErrorConstants.CreateBill.FLOW_FACTORY_INVALID_TENANT_ID, "Invalid tenantId for CreateBill flow");

        }
    }
}
