package com.walmart.international.wallet.payment.app.builder.migration.mapper;

import com.walmart.international.wallet.payment.dto.response.migration.CreateBillV2DTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountResponseDTO;
import com.walmart.international.wallet.payment.dto.response.migration.UpdateSavedBillerAccountRequest;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Mapper
@Component
public interface MigrationBillMapper {
    MigrationBillMapper INSTANCE = Mappers.getMapper(MigrationBillMapper.class);

    @Mapping(target = "id", source = "customerBillAccountId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "customerBillId", source = "processorBillAccountId")
    @Mapping(target = "balance", source = "dueAmount")
    @Mapping(target = "balanceCurrency", source = "dueAmountCurrencyUnit")
    @Mapping(target = "balanceUpdatedAt", source = "dueInfoUpdatedAt", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "dueDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "billPaidDate", source = "lastPaidDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "type", constant = "bill")
    CreateBillV2DTO mapCustomerBillAccountToCreateBillV2DTO(CustomerBillAccount customerBillAccount);

    default String mapUUIDToString(UUID id) {
        return id.toString();
    }

    @Mapping(target = "id", source = "customerBillAccountId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "accountAlias", source = "alias")
    @Mapping(target = "billerAccountUpdatedAt", source = "updateDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "lastPaidDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(ignore = true, target = "billerAccountDeletedAt")
    SavedBillerAccountResponseDTO customerBillAccountToSavedBillerAccountResponseDTO(CustomerBillAccount customerBillAccount);

    @Mapping(target = "alias", source = "accountAlias")
    @Mapping(target = "customerBillAccountId", source = "savedBillerAccountId")
    CustomerBillAccount updateSavedBillerAccountRequestToCustomerBillAccount(UpdateSavedBillerAccountRequest updateSavedBillerAccountRequest);
}
