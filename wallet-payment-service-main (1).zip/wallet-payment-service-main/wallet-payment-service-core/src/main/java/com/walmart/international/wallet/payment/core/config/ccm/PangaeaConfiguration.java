package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "pangaea-config")
public interface PangaeaConfiguration extends WebClientCCMConfigs {

    @Property(propertyName = "base.url")
    String getBaseUrl();

    @Property(propertyName = "base.url.for.vertical.102")
    String getBaseUrlForVertical102();

    @Property(propertyName = "env")
    String getEnvironment();

    @Property(propertyName = "service.version")
    String getServiceVersion();

    @Property(propertyName = "service.name")
    String getServiceName();

    @Property(propertyName = "service.key.version")
    String getServiceKeyVersion();

    @Property(propertyName = "service.consumer.id")
    String getServiceConsumerId();

    @Property(propertyName = "locale.id")
    String getLocaleId();

    @Property(propertyName = "tenant.id")
    String getTenantId();

    @Property(propertyName = "tenant.id.for.vertical.102")
    String getTenantIdForVertical102();

    @Property(propertyName = "payment.method.id")
    String getPaymentMethodId();

    @Property(propertyName = "pos.vertical.id")
    String getPosVerticalId();

    @Property(propertyName = "online.vertical.id")
    String getOnlineVerticalId();

    @Property(propertyName = "merchant.vertical.id")
    String getMerchantVerticalId();

    @Property(propertyName = "system.vertical.id")
    String getSystemVerticalId();

    @Property(propertyName = "alternate.merchant.id")
    String getAlternateMerchantId();

    @Property(propertyName = "system.store.id")
    String getSystemStoreId();

    @Property(propertyName = "system.terminal.id")
    String getSystemTerminalId();

}
