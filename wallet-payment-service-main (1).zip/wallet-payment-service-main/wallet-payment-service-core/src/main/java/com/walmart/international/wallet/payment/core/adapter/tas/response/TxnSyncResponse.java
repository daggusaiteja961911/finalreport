package com.walmart.international.wallet.payment.core.adapter.tas.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TxnSyncResponse  implements Serializable {
    private String transactionId;
    private String syncStatus;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String errorCode;

    public TxnSyncResponse(String transactionId, String syncStatus) {
        this.transactionId = transactionId;
        this.syncStatus = syncStatus;
    }
}
