package com.walmart.international.wallet.payment.core.adapter.tas;

import com.walmart.international.services.digitalwallet.httpclient.wallet.constants.ApiName;

public enum TASAPIName implements ApiName {
    PUBLISH_TXN_PAYLOAD, BILL_PAY_TXN_SYNC, COF_TXN_SYNC;

    @Override
    public String getApiName() {
        return this.name();
    }
}
