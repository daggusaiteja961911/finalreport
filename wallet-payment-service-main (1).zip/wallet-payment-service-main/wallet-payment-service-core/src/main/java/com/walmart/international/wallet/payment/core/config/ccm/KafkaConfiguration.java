package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "kafka-config")
public interface KafkaConfiguration {
    @Property(propertyName = "pb.kafka.charge.consumer.enabled", defaultValue = "true"
    )
    boolean isPBKafkaChargeConsumerEnabled();

    @Property(propertyName = "pb.kafka.refund.consumer.enabled", defaultValue = "true"
    )
    boolean isPBKafkaRefundConsumerEnabled();
}
