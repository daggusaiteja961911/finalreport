package com.walmart.international.wallet.payment.core.processor.validator.billpay;


import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.services.payment.core.dao.repository.CoreTransactionRepository;
import com.walmart.international.services.payment.core.domain.SubTransactionStatus;
import com.walmart.international.services.payment.core.model.CoreTransactionDO;
import com.walmart.international.services.payment.core.model.SubTransactionDO;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class CancelBillPayValidator implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    CoreTransactionRepository coreTransactionRepository;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws DataValidationException, BusinessValidationException {
        BillPayTxnRequestDomainContext requestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTxnResponseDomainContext responseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        BillPayTransaction billPayTransaction = requestDomainContext.getTransaction();
        if (billPayTransaction.getTransactionId() == null) {
            throw new DataValidationException(ErrorConstants.CancelPayBillInitTransaction.TRANSACTION_ID_MANDATORY);
        }

        if (billPayTransaction.getCustomer().getCustomerAccountId() == null) {
            throw new DataValidationException(ErrorConstants.CancelPayBillInitTransaction.CUSTOMER_ACCOUNT_ID_MANDATORY);
        }

        //Validate billPay transaction
        Optional<BillPayTransactionDO> oBillTransaction = billPayTransactionRepository.findById(billPayTransaction.getTransactionId());
        if (oBillTransaction.isEmpty()) {
            String msg = String.format("billPay transaction record not found for transactionID[%s]", billPayTransaction.getTransactionId());
            throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.BILL_TXN_NOT_FOUND, msg);
        }

        //validate CofTopup transaction
        Optional<CoFTopupTransactionDO> oTopupTransaction = coFTopupTransactionRepository.findByTxnReferenceId(billPayTransaction.getTransactionId().toString());
        if (oTopupTransaction.isEmpty()) {
            String msg = String.format("CoFtopup transaction not found for txnReferenceID[%s]", billPayTransaction.getTransactionId());
            throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.COF_TOPUP_TRANSACTION_NOT_FOUND, msg);
        }

        boolean validationFlag = validateCardSubTransaction(oTopupTransaction.get().getCoFTopupTransactionId());

        responseDomainContext.setBillPayTransactionDO(oBillTransaction.get());
        responseDomainContext.setCoFTopupTransactionDO(oTopupTransaction.get());
        responseDomainContext.setTransaction(requestDomainContext.getTransaction());
        responseDomainContext.setHeaders(requestDomainContext.getHeaders());
        return validationFlag;
    }

    private boolean validateCardSubTransaction(UUID transactionID) throws BusinessValidationException {
        String clientTransactionId = String.join("_", String.valueOf(transactionID), "1");
        CoreTransactionDO coreTransactionDO = coreTransactionRepository.findTopByClientTransactionIdOrderByCreateDateDesc(clientTransactionId);
        if (Objects.nonNull(coreTransactionDO)) {
            Optional<SubTransactionDO> ocardTransactionDO = coreTransactionDO.getCardSubTransaction();
            if (ocardTransactionDO.isPresent()) {
                SubTransactionDO cardTransactionDO = ocardTransactionDO.get();

                if (SubTransactionStatus.PAYMENT_FAILED.equals(cardTransactionDO.getStatus())) {
                    String msg = String.format("card subTransaction[%s] for coFTopupTransactionId :[%s] is already marked as FAILED", cardTransactionDO.getSubTransactionId(), transactionID);
                    throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.TRANSACTION_ALREADY_MARKED_FAILED, msg);
                } else if (SubTransactionStatus.PAYMENT_SUCCEEDED.equals(cardTransactionDO.getStatus())) {
                    String msg = String.format("card subTransaction[%s] for coFTopupTransactionId :[%s] is already marked as SUCCESS", cardTransactionDO.getSubTransactionId(), transactionID);
                    throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.TRANSACTION_ALREADY_MARKED_SUCCESS, msg);
                } else if (SubTransactionStatus.CANCELLED.equals(cardTransactionDO.getStatus())) {
                    log.info("card subTransaction[{}] for coFTopupTransactionId :[{}] is already marked as CANCELLED", cardTransactionDO.getSubTransactionId(), transactionID);
                    return false;
                } else if (!SubTransactionStatus.PAYMENT_3DS_PROCESSING.equals(cardTransactionDO.getStatus())) {
                    String msg = String.format("card subTransaction[%s] for coFTopupTransactionId :[%s] is  marked as [%s]", cardTransactionDO.getSubTransactionId(), transactionID, cardTransactionDO.getStatus());
                    throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE, msg);
                }
                return true;
            }
            String msg = String.format("card subTransaction not found present for coFTopupTransactionId :[%s]", transactionID);
            throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE, msg);
        }
        String msg = String.format("core Transaction not found present for coFTopupTransactionId :[%s]", transactionID);
        throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE, msg);
    }
}
