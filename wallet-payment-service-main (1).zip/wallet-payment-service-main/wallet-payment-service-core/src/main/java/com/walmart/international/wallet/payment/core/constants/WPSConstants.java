package com.walmart.international.wallet.payment.core.constants;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class WPSConstants {

    public static class Common {
        public static final String PAYMENT_DEFAULT_STORE_ID = "9175";
        public static final String ACK_SUCCESS = "SUCCESS";
        public static final String APPLICATION_NAME = "wallet-payment-service";
    }

    public static class Biller {
        public static final int CEA_ARCUS_PROCESSOR_BILLER_ID = 13621;
        public static final int CFE_ARCUS_PROCESSOR_BILLER_ID = 35;
        public static final int MEGACABLE_ARCUS_PROCESSOR_BILLER_ID = 1821;
        public static final int TELMEX_ARCUS_PROCESSOR_BILLER_ID = 37;
        public static final int TELNOR_ARCUS_PROCESSOR_BILLER_ID = 12540;
        public static final String BILLER_CATEGORIES_MAP_CACHE_KEY = "WPS_BILLER_CATEGORIES_MAP_";
        public static final String BILLER_CATEGORY_DATA_UPDATED_AT_CACHE_KEY = "WPS_BILLER_CATEGORY_DATA_UPDATED_AT";
        public static final String BILLER_INCORRECT_SEARCH_KEYWORDS_MAP_CACHE_KEY = "WPS_BILLER_INCORRECT_SEARCH_KEYWORDS_MAP";
        public static final String BILLER_INCORRECT_SEARCH_KEYWORD_MAP_UPDATED_AT_CACHE_KEY = "WPS_BILLER_INCORRECT_SEARCH_KEYWORD_MAP_UPDATED_AT";
        public static final String SUFFIX_BILLER_DATA = "_WPS_BILLER_DATA";
        public static final String SUFFIX_BILLER_DATA_UPDATED_AT = "_WPS_BILLER_DATA_UPDATED_AT";
        public static final String BILL_TYPE_BARCODE = "bar_code";
        public static final String BILL_TYPE_GIFT_CARD = "gift_card";
        public static final String AUTH_TEXT_IDENTIFIER = "Pago realizado exitosamente";
        public static final String TICKET_TEXT_SERIAL_NO = "serialNumber";
        public static final String TICKET_TEXT_PIN = "PIN";
        public static final String CINEPOLIS = "Cinépolis";
    }

    public static class Bills {
        public static final String DUE = "DUE";
        public static final String PAID = "PAID";
        public static final String ALL = "ALL";
        public static final String FAST_APPROACHING_BILL = "FAST_APPROACHING";
        public static final String FAST_APPROACHING_BILL_DESC = "Próximo a vencer";
        public static final String OVERDUE_BILL = "OVERDUE";
        public static final String OVERDUE_BILL_DESC = "Vencido";
        public static final String CUSTOMER_BILL_ACCOUNT_UPDATE_SUCCESSFUL = "Customer Bill Account updated successfully";
        public static final String PAYMENT_USER = "USER";
        public static final int validityThresholdInDays = 30;
        public static final String BILL_TYPE_GIFT_CARD = "gift_card";
        public static final String DUE_BILL_TYPE_TODAY = "DUETODAY";
        public static final String DUE_TODAY = "Vence hoy";
        public static final String DUE_BILL_TYPE_LATER = "DUELATER";
        public static final String DUE_TOMORROW = "Vence mañana";
        public static final String DUE_BILL_DESC = "VENCE EL ";
        public static final String OVERDUE_BILL_PAY_DESC = "PAGO VENCIDO";
        public static final String NUDGE_BILL = "NUDGE";
        public static final String NUDGE_BILL_DESC = "¡REPITE EL PAGO!";
    }

    public static class PaymentInstrument {
        public static final String CREDIT = "CREDIT";
        public static final String DEBIT = "DEBIT";
        public static final String GIFTCARD = "GIFTCARD";
        public static final String CORPGIFTCARD = "CORPGIFTCARD";

        public static final String ASSOCIATE_FOOD_VOUCHER_COMPANY_NAME = "WMT-HR";
        public static final List GIFT_CARD_PAYMENT_INSTRUMENTS = Collections.unmodifiableList(
                Arrays.asList(GIFTCARD, CORPGIFTCARD));
        public static final List CARD_PAYMENT_INSTRUMENTS = Collections.unmodifiableList(
                Arrays.asList(CREDIT, DEBIT));
    }

    public static class FetchBillPayPaymentOptions {
        public static final String ORDER_DISCOUNT = "ORDER_DISCOUNT";
        public static final String ORDER_TOTAL_AMOUNT = "ORDER_TOTAL_AMOUNT";
        public static final String BILL_AMOUNT = "BILL_AMOUNT";
        public static final String SHIPMENT_AMOUNT = "SHIPMENT_AMOUNT";
        public static final String COMMISSION = "COMMISSION";
        public static final String DOLLAR = "$";
        public static final String MINUS = "-";
        public static final String FREE = "FREE";
        public static final String ES = "es-ES";
    }

    public static class CoFTopup {
        public static final String COF_TOPUP_FAILED_GENERIC_DISPLAY_MESSAGE = "Algo salió mal, inténtalo nuevamente.";
        public static final String COF_TOPUP_SUCCESSFUL_DISPLAY_MESSAGE = "Carga de saldo";
        public static final String COF_TOPUP_PENDING_3DS_GENERATED_DISPLAY_MESSAGE = "Please enter OTP to complete payment";
    }

    public static class BillPay {
    }

    public static class CancelTransaction {
        public static final String TOP_UP_ABORTED_SUCCESSFULLY = "WPS-TC-SU-0001";
    }

    public static class Arcus {
        public static final String API_KEY = "ARCUS_API_KEY";
        public static final String SECRET_KEY = "ARCUS_SECRET_KEY";
        public static final int API_SECRET_KEY_VERSION_2 = 2;
    }

    public static class Headers {
        public static final String WM_SVC_ENV = "WM_SVC.ENV";
        public static final String WM_SVC_NAME = "WM_SVC.NAME";
        public static final String WM_SVC_VERSION = "WM_SVC.VERSION";
        public static final String WM_CONSUMER_ID = "WM_CONSUMER.ID";
        public static final String DEVICE_APP_VERSION = "device_app_version";
        public static final String DEVICE_FINGERPRINT = "device_fingerprint";
        public static final String DEVICE_PLATFORM = "device_platform";
        public static final String CORRELATION_ID = "wm_qos.correlation_id";
        public static final String CLIENT_REQ_ID = "client_req_id";
        public static final String CLIENT_IP_HEADER = "wm_client_ip";
        public static final String X_FORWARDED_FOR = "x-forwarded-for";
    }

    public static class Promotions {
        public static final boolean IS_PROMOTIONS_FROM_CACHE = false;
    }

    public static class Notification {
        public static final String ACCOUNT_LOCKED_TITLE = "Cuenta bloqueada";
        public static final String ACCOUNT_LOCKED_MESSAGE = "Por seguridad, bloqueamos tu saldo temporalmente. Contáctate con nuestro servicio de Ayuda para asistencia.";
        public static final String ACTION_CALL_HELP = "CALL_HELP";
        public static final String CARD_PAYMENT_FAILURE_TITLE = "No pudimos procesar tu pago.";
        public static final String CARD_PAYMENT_FAULURE_MESSAGE = "Inténtalo de nuevo.";
        public static final String BILL_PAY_FAILURE_TITLE = "Error durante la transacción";
        public static final String BILL_PAY_FAILURE_TEXT_START = "La transacción por ";
        public static final String FOR = " por ";
        public static final String BILL_PAY_FAILURE_TEXT_END = " no pudo completarse.\n" +
                "Contacta a soporte al cliente para que el monto sea reembolsado.";
        public static final String SHOW_TRANSACTION = "showTransaction";
        public static final String OPEN_CUSTOMER_SUPPORT = "openCustomerSupport";
        public static final String SHOW_BONUS_HOME_SCREEN = "showBonusHomeScreen";
        public static final String SHOW_PAYMENT_DETAILS = "showPaymentDetails";
        public static final String OPEN_HOME = "openHome";
        public static final String SHOW_BILLER_ACTION = "showBiller";
        public static final String CASHI_BALANCE_MESSAGE_START_V2 = "Pago de ";
        public static final String CASHI_BALANCE_MESSAGE_END_V2 = " exitoso";
        public static final String AMOUNT_PAID_SUCCESSFULLY = "Pagaste $";
        public static final String AMOUNT_PAID_SUCCESSFULLY_END = " de tu servicio. Revisa los detalles de tu pago en movimientos";
    }

    public class AML {
        public static final String SRC_APP = "sourceApplication";
        public static final String SRC_APP_NAME = "wallet-payment-service";
        public static final String TRANSACTION = "TRANSACTION";
        public static final String MINIMAL_DATA_SYNC = "MINIMAL_DATA_SYNC";
        public static final String AML_EVALUATION = "AML_EVALUATION";
    }

    public static class Event {
        public static final String PAY_BILL_INIT = "PAY_BILL_INIT";
        public static final String CANCEL_PAY_BILL_INIT = "CANCEL_PAY_BILL_INIT";
        public static final String ACCOUNTING_EVENT = "CARD_TRANSACTION_SUCCESS";
        public static final String REWARD_BILL_PAY = "REWARD_BILL_PAY";
        public static final String REWARD_LOAD_MONEY = "REWARD_LOAD_MONEY";
    }

}
