package com.walmart.international.wallet.payment.core.adapter.billprocessor.response;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class PayBillResponse implements Serializable {

    private static final long serialVersionUID = -2403983795821925139L;

    private String processorTransactionId;

    private String type;

    private BigDecimal amount;

    private String amountCurrency;

    private BigDecimal fxRate;

    private BigDecimal hoursToFulfill;

    private String extCreatedAt;

    private String status;

    private String accountNumber;

    private String authText;

    private String serialNumber;

    private String pin;

}
