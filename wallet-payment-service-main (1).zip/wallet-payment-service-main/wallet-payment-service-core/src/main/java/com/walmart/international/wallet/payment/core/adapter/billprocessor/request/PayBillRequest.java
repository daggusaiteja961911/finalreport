package com.walmart.international.wallet.payment.core.adapter.billprocessor.request;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class PayBillRequest {
    private BigDecimal amount;
    private String currency;
    private String accountNumber;
    private String processorBillerId;
    private String externalId;
    private String processorBillAccountId;
}
