package com.walmart.international.wallet.payment.core.adapter.kafka.request.pb;

import lombok.Data;

@Data
public class CardDetails {
    private String cardId;
    private String bin;
    private String cardBrand;
    private String cardType;
    private String bankName;
    private String nameOnCard;
    private String lastFourDigits;
    private String expiryYear;
    private String expiryMonth;
    private String cardNumber;
}
