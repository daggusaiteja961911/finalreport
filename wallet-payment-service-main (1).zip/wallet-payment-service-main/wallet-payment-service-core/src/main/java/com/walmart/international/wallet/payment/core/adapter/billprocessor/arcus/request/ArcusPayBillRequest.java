package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class ArcusPayBillRequest {

    private BigDecimal amount;

    private String currency;

    @JsonProperty("account_number")
    private String accountNumber;

    @JsonProperty("biller_id")
    private int billerId;

    @JsonProperty("external_id")
    private String externalId;
}
