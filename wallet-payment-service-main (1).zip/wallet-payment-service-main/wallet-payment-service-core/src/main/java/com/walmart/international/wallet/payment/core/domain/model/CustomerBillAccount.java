package com.walmart.international.wallet.payment.core.domain.model;

import io.strati.libs.joda.time.LocalDate;
import io.strati.libs.joda.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Date;
import java.util.UUID;

@Data
@SuperBuilder
@NoArgsConstructor
public class CustomerBillAccount {

    private UUID customerBillAccountId;

    private String processorBillAccountId;

    private UUID customerAccountId;

    private Biller biller;

    private UUID billerId;

    private String processorBillerId;

    private String accountNumber;

    private String revisedAccountNumber;

    private BigDecimal dueAmount;

    private String dueAmountCurrencyUnit;

    private BigDecimal lastPaidAmount;

    private String lastPaidAmountCurrencyUnit;

    private Date dueInfoUpdatedAt;

    private String dueInfoUpdatedBy;

    private String status;

    private Date dueDate;

    private String nameOnAccount;

    private String alias;

    private Date lastPaidDate;

    private Date skipReminderTillDate;

    private String nudgeBucket;

    private Boolean isSaved;

    private Boolean isDeleted;

    private Date updateDate;

    public CustomerBillAccount(Biller biller) {
        this.biller = biller;
    }

    public static class OverDueBillsComparator implements Comparator<CustomerBillAccount> {
        @Override
        public int compare(CustomerBillAccount b1, CustomerBillAccount b2) {

            LocalDate dueDate1 = b1.getDueDate() == null ? null : LocalDateTime.fromDateFields(b1.getDueDate()).toLocalDate();
            LocalDate dueDate2 = b2.getDueDate() == null ? null : LocalDateTime.fromDateFields(b2.getDueDate()).toLocalDate();
            if (dueDate1 == null && dueDate2 == null) {
                return -1;
            } else if (dueDate1 == null) {
                return 1;
            } else if (dueDate2 == null) {
                return -1;
            } else {
                if (dueDate1.equals(dueDate2)) {
                    if (b2.getProcessorBillAccountId() != null)
                        return 1;
                    return -1;
                } else {
                    return dueDate2.compareTo(dueDate1);
                }
            }
        }
    }

    public static class DueBillsComparator implements Comparator<CustomerBillAccount> {
        @Override
        public int compare(CustomerBillAccount b1, CustomerBillAccount b2) {
            LocalDate currentDate = LocalDate.now();
            LocalDate dueDate1 = b1.getDueDate() == null ? null : LocalDateTime.fromDateFields(b1.getDueDate()).toLocalDate();
            LocalDate dueDate2 = b2.getDueDate() == null ? null : LocalDateTime.fromDateFields(b2.getDueDate()).toLocalDate();
            if (dueDate1 == null && dueDate2 == null) {
                return -1;
            } else if (dueDate1 == null) {
                if (dueDate2.equals(currentDate))
                    return 1;
                return currentDate.compareTo(dueDate2);
            } else if (dueDate2 == null) {
                if (dueDate1.equals(currentDate))
                    return -1;
                return dueDate1.compareTo(currentDate);
            } else {
                if (dueDate1.equals(dueDate2)) {
                    if (b2.getProcessorBillAccountId() != null)
                        return 1;
                    return -1;
                } else {
                    return dueDate1.compareTo(dueDate2);
                }
            }
        }
    }

    public static class PaidBillsComparator implements Comparator<CustomerBillAccount> {
        @Override
        public int compare(CustomerBillAccount b1, CustomerBillAccount b2) {
            LocalDate dueDate1 = b1.getDueDate() == null ? null : LocalDateTime.fromDateFields(b1.getDueDate()).toLocalDate();
            LocalDate dueDate2 = b2.getDueDate() == null ? null : LocalDateTime.fromDateFields(b2.getDueDate()).toLocalDate();
            LocalDate lastPaidDate1 = LocalDateTime.fromDateFields(b1.getLastPaidDate()).toLocalDate();
            LocalDate lastPaidDate2 = LocalDateTime.fromDateFields(b2.getLastPaidDate()).toLocalDate();
            if (dueDate1 == null && dueDate2 == null)
                return lastPaidDate2.compareTo(lastPaidDate1);
            if (dueDate1 == null)
                return 1;
            if (dueDate2 == null)
                return -1;
            return dueDate1.compareTo(dueDate2);
        }
    }

}
