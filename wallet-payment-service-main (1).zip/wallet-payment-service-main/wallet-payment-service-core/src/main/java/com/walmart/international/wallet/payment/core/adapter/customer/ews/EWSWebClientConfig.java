package com.walmart.international.wallet.payment.core.adapter.customer.ews;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.services.digitalwallet.httpclient.util.HttpClientException;
import com.walmart.international.services.digitalwallet.httpclient.wallet.util.DownstreamWebClientErrorHandler;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.DownstreamHTTPClientConfigs;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.impl.WebClientV2Impl;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.EwsErrorResponse;
import com.walmart.international.wallet.payment.core.config.ccm.EWSConfig;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

import static com.walmart.international.digiwallet.service.strati.telemetry.service.constants.TelemetryConstants.EMPTY_TAG;

@Slf4j
@Configuration
public class EWSWebClientConfig {

    public static final String EWS = "EWS";
    ObjectMapper objectMapper = new ObjectMapper();
    @ManagedConfiguration
    EWSConfig ewsConfig;

    @Bean("ewsWebClient")
    WebClientV2 getEWSWebClient() {
        DownstreamWebClientErrorHandler errorHandler = DownstreamWebClientErrorHandler.builder()
                .clientResponse4xxErrorHandler(errorResponse -> errorResponse.bodyToMono(Object.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.statusCode()));
                }))
                .clientResponse5xxErrorHandler(errorResponse -> errorResponse.bodyToMono(Object.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.statusCode()));
                }))
                .isError((httpCode, apiName) -> httpCode < 200 || httpCode >= 300)
                .errorCodeExtractor((responseBody, apiName) -> getErrorCode(responseBody, apiName))
                .build();
        DownstreamHTTPClientConfigs ewsHTTPClientConfigs = DownstreamHTTPClientConfigs.builder()
                .downstreamName(EWS)
                .downstreamErrorHandler(errorHandler)
                .connectionTimeoutMillis(ewsConfig.getWebClientConnectionTimeoutInMillis())
                .responseTimeoutMillis(ewsConfig.getWebClientResponseTimeoutInMillis())
                .isSaveLogsToDBEnabled(ewsConfig.isSaveLogsToDBEnabled())
                .build();
        return new WebClientV2Impl(ewsHTTPClientConfigs);
    }

    private String getErrorCode(String responseBody, String apiName) {
        try {
            EwsErrorResponse response = objectMapper.readValue(responseBody, EwsErrorResponse.class);
            String errorCode = response.getCode();
            return errorCode != null ? errorCode : EMPTY_TAG;
        } catch (Exception ex) {
            log.error("getErrorCode::EWSWebClientConfig:: Error while parsing response for api: [{}] to fetch error-code", apiName, ex);
        }
        return EMPTY_TAG;
    }

}
