package com.walmart.international.wallet.payment.core.adapter.kafka.request.refund;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PBReverseKafkaResponse {
    private String eventType;
    private ReverseKafkaResponseEventDetails eventPayload;
}
