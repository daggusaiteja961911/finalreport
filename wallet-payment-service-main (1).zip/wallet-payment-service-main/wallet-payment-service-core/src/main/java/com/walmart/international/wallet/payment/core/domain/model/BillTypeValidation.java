package com.walmart.international.wallet.payment.core.domain.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonSerialize
public class BillTypeValidation implements Serializable {
    private String type;
    private Integer minDigits;
    private Integer maxDigits;
}
