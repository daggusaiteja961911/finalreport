package com.walmart.international.wallet.payment.core.domain.model.request;

import com.walmart.international.wallet.payment.core.constants.enums.AMLValidationType;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Data
@Builder
public class AMLValidationRequest {

    private UUID customerAccountId;

    private AMLValidationType amlValidationType;

    private BigDecimal amount;

    private String requestId;
}
