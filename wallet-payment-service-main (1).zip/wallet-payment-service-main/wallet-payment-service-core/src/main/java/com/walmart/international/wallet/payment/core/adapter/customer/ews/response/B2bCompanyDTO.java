package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class B2bCompanyDTO {

    private UUID id;

    private String companyName;

    private Date createDate;

    private Date updateDate;

    private String companyLogo;

    private String fdPromoCode;

    private String companyImage;

    private String companyColor;

    private String disbursementAllowedTo;

    private Boolean apiDisbursementAllowed;

    private Integer disbursementExpiryInterval;

    private BigDecimal maxBalanceLimit;

    private String applicableBanners;

    private String phone;

    private String description;

    private String termsAndConditions;

    private Boolean isVale;

    private String displayName;

}
