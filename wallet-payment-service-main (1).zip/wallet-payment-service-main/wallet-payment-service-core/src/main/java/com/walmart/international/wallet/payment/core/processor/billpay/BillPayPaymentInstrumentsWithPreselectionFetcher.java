package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentSubType;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.SingleScreenPaymentConfiguration;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayPaymentOptions;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstruments;
import com.walmart.international.wallet.payment.core.domain.model.DeviceAppVersion;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstruments;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class BillPayPaymentInstrumentsWithPreselectionFetcher implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    ICustomerServiceClient customerServiceClient;

    @ManagedConfiguration
    SingleScreenPaymentConfiguration singleScreenPaymentConfiguration;

    CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillPayTxnRequestDomainContext billPayTxnRequestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        UUID customerAccountId = billPayTxnRequestDomainContext.getTransaction().getCustomer().getCustomerAccountId();
        WalletResponse paymentInstrumentResponse = customerServiceClient.getPaymentInstruments(customerAccountId);
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = paymentInstrumentResponse.getPaymentInstruments();

        mapPaymentInstruments(paymentInstrumentList, billPayTxnRequestDomainContext, billPayTxnResponseDomainContext);
        return true;
    }

    private void mapPaymentInstruments(List<WalletResponse.PaymentInstrument> paymentInstrumentList, BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        List<CardPaymentInstrument> cardPaymentInstrumentList = new ArrayList<>();
        List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList = new ArrayList<>();
        for (WalletResponse.PaymentInstrument paymentInstrument : paymentInstrumentList) {
            if (PaymentInstrumentType.CARD.equals(paymentInstrument.getPaymentInstrumentType())) {
                CardPaymentInstrument cardPaymentInstrument = customerMapper.mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument);
                cardPaymentInstrument.setTag(PaymentInstrumentType.CARD.name());
                cardPaymentInstrumentList.add(cardPaymentInstrument);
            } else if (PaymentInstrumentType.GIFTCARD.equals(paymentInstrument.getPaymentInstrumentType()) && PaymentInstrumentSubType.CASHI_WALLET.equals(paymentInstrument.getPaymentInstrumentSubType())) {
                GiftCardPaymentInstrument giftCardPaymentInstrument = customerMapper.mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument);
                giftCardPaymentInstrument.setTag(PaymentInstrumentType.GIFTCARD.name());
                giftCardPaymentInstrumentList.add(giftCardPaymentInstrument);
            }
        }
        boolean isCoFBillPaymentPossibleInDevice = canDeviceDoCoFBillPayment(billPaymentConfiguration.getAllowCoF(), billPaymentConfiguration.getAndroidMinVersionForCoFBillPayment(), billPaymentConfiguration.getIOSMinVersionForCoFBillPayment(), billPayTxnRequestDomainContext);
        if (!isCoFBillPaymentPossibleInDevice) {
            cardPaymentInstrumentList = Collections.emptyList();
        }
        Amount amountRequested = billPayTxnRequestDomainContext.getTransaction().getAmountRequested();
        sortAndPreselectPaymentInstrument(cardPaymentInstrumentList, giftCardPaymentInstrumentList, amountRequested.getValue(), billPayTxnResponseDomainContext, isCoFBillPaymentPossibleInDevice);
    }

    private void sortAndPreselectPaymentInstrument(List<CardPaymentInstrument> cardPaymentInstrumentList, List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList, BigDecimal txnAmount, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext, boolean isCoFBillPaymentPossibleInDevice) {
        List<CardPaymentInstrument> sortedCardPaymentInstruments = Optional.ofNullable(cardPaymentInstrumentList).orElseGet(Collections::emptyList).stream()
                .filter(card -> !card.getIsExpired())
                .sorted(Comparator.comparing((CardPaymentInstrument dto) -> singleScreenPaymentConfiguration.getCuentaCashiDigitalCardBins().contains(String.valueOf(dto.getBinDetails().getBin())) ? -1 : 0) //cuenta cashi digital card
                        .thenComparing((CardPaymentInstrument dto) -> dto.getIsFavourite() ? -1 : 0) //favorite card
                        .thenComparing(CardPaymentInstrument::getLastUsedDate, Comparator.nullsLast(Comparator.reverseOrder())) //last used card date
                        .thenComparing(dto -> dto.getBinDetails().getBankName()))
                .collect(Collectors.toList());

        BigDecimal remainingAmount = preSelectPaymentOptions(giftCardPaymentInstrumentList, txnAmount, sortedCardPaymentInstruments);
        if (BigDecimal.ZERO.compareTo(remainingAmount) < 0) {
            revertPreselection(sortedCardPaymentInstruments, giftCardPaymentInstrumentList);
        }
        billPayTxnResponseDomainContext.setTransaction(BillPayTransaction.builder()
                .billPayPaymentOptions(BillPayPaymentOptions.builder()
                        .cardPaymentInstruments(CardPaymentInstruments.builder()
                                .cardPaymentInstrumentList(sortedCardPaymentInstruments)
                                .build())
                        .build())
                .build());
        if (isCoFBillPaymentPossibleInDevice) {
            billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setAllowCoFForBillPayment(true);
        } else {
            billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setAllowCoFForBillPayment(false);
        }
        billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setGiftCardPaymentInstruments(
                GiftCardPaymentInstruments.builder().giftCardPaymentInstrumentList(giftCardPaymentInstrumentList).build());
    }

    private void revertPreselection(List<CardPaymentInstrument> sortedCardPaymentInstruments, List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList) {
        revertCardPreselection(sortedCardPaymentInstruments);
        revertGiftCardPreselection(giftCardPaymentInstrumentList);
    }

    private void revertGiftCardPreselection(List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList) {
        Optional.ofNullable(giftCardPaymentInstrumentList).orElseGet(Collections::emptyList).stream().forEach(paymentInstrument -> {
            paymentInstrument.setPreSelectedAmount(null);
            paymentInstrument.setIsPreSelected(false);
        });
    }

    private void revertCardPreselection(List<CardPaymentInstrument> sortedCardPaymentInstruments) {
        Optional.ofNullable(sortedCardPaymentInstruments).orElseGet(Collections::emptyList).stream().forEach(paymentInstrument -> {
            paymentInstrument.setPreSelectedAmount(null);
            paymentInstrument.setIsPreSelected(false);
        });
    }

    private BigDecimal preSelectPaymentOptions(List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList, BigDecimal txnAmount, List<CardPaymentInstrument> sortedCardPaymentInstruments) {
        BigDecimal remainingAmount = preSelectWallet(giftCardPaymentInstrumentList, txnAmount);
        if (remainingAmount.compareTo(BigDecimal.ZERO) > 0) {
            return preSelectCOF(sortedCardPaymentInstruments, remainingAmount);
        }
        return remainingAmount;
    }

    private BigDecimal preSelectWallet(List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList, BigDecimal txnAmount) {
        GiftCardPaymentInstrument paymentPreferenceDTO = CollectionUtils.isNotEmpty(giftCardPaymentInstrumentList) ? giftCardPaymentInstrumentList.get(0) : null;
        if (null == paymentPreferenceDTO) {
            return txnAmount;
        }
        BigDecimal balance = paymentPreferenceDTO.getBalance().getCurrencyAmount();
        if (balance.compareTo(txnAmount) >= 0) {
            paymentPreferenceDTO.setIsPreSelected(true);
            paymentPreferenceDTO.setPreSelectedAmount(txnAmount);
            return BigDecimal.ZERO;
        } else if (balance.compareTo(BigDecimal.ZERO) > 0) {
            txnAmount = txnAmount.subtract(balance);
            paymentPreferenceDTO.setIsPreSelected(true);
            paymentPreferenceDTO.setPreSelectedAmount(balance);
            return txnAmount;
        }
        return txnAmount;
    }

    private BigDecimal preSelectCOF(List<CardPaymentInstrument> paymentPreferenceDTOs, BigDecimal remainingAmount) {
        CardPaymentInstrument paymentPreferenceDTO = CollectionUtils.isNotEmpty(paymentPreferenceDTOs) ? paymentPreferenceDTOs.get(0) : null;
        if (null == paymentPreferenceDTO) {
            return remainingAmount;
        }
        paymentPreferenceDTO.setIsPreSelected(true);
        paymentPreferenceDTO.setPreSelectedAmount(remainingAmount);
        return BigDecimal.ZERO;
    }

    public static Boolean canDeviceDoCoFBillPayment(Boolean isCoFAllowedCCM, String androidMinVersionString, String iOSMinVersionString, BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        if (Objects.nonNull(isCoFAllowedCCM) && isCoFAllowedCCM) {
            DeviceAppVersion requiredVersion;
            DeviceAppVersion deviceVersion = new DeviceAppVersion(billPayTxnRequestDomainContext.getHeaders().get("device_app_version").get(0));

            if (billPayTxnRequestDomainContext.getHeaders().get("device_platform").get(0).equalsIgnoreCase("android")) {
                requiredVersion = new DeviceAppVersion(androidMinVersionString);
            } else if (billPayTxnRequestDomainContext.getHeaders().get("device_platform").get(0).equalsIgnoreCase("ios")) {
                requiredVersion = new DeviceAppVersion(iOSMinVersionString);
            } else {
                return false;
            }
            return deviceVersion.compareTo(requiredVersion) >= 0;
        }
        return false;
    }


}