package com.walmart.international.wallet.payment.core.mapper;

import com.walmart.international.notification.utils.EncryptionUtils;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import org.apache.commons.lang.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BillPayMapper {

    BillPayMapper INSTANCE = Mappers.getMapper(BillPayMapper.class);

    @Mapping(target = "pin", source = "pin", qualifiedByName = "encryptAndMapPin")
    @Mapping(target = "amount", ignore = true)
    void mapPayBillResponseToBillPayTransactionDO(PayBillResponse payBillResponse, @MappingTarget BillPayTransactionDO billPayTransactionDO);

    @Mapping(target = "transactionId", source = "billPayTransactionId")
    @Mapping(target = "billDetail", ignore = true)
    void updateBillPayTransactionFromBillPayTransactionDO(BillPayTransactionDO billPayTransactionDO, @MappingTarget BillPayTransaction billPayTransaction);

    @Named("encryptAndMapPin")
    default String encryptAndMapPin(String pin) {
        if (StringUtils.isNotEmpty(pin)) {
            return EncryptionUtils.encrypt(pin);
        } else {
            return null;
        }
    }
}
