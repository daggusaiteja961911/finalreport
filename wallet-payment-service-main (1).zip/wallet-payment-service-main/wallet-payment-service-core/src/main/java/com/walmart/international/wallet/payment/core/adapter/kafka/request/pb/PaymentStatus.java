package com.walmart.international.wallet.payment.core.adapter.kafka.request.pb;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

public enum PaymentStatus {
    @JsonProperty("SUCCESS")
    SUCCESS("success"),

    @JsonProperty("FAILED")
    FAILED("failed"),

    @JsonProperty("PENDING")
    PENDING("pending"),

    @JsonProperty("AUTHORISED")
    AUTHORISED("authorised"),

    @JsonProperty("THREE_DS_GENERATED")
    THREE_DS_GENERATED("3ds_generated");

    private final String status;

    PaymentStatus(String status) {
        this.status = status;
    }

    @JsonValue
    public String status() {
        return status;
    }

    @JsonCreator
    public static PaymentStatus forStatus(String status) {
        for (PaymentStatus paymentStatus : PaymentStatus.values()) {
            if (paymentStatus.status.equals(status) || paymentStatus.name().equals(status)) {
                return paymentStatus;
            }
        }
        return null;
    }

    public static String getStatus(PaymentStatus paymentStatus) {
        return paymentStatus.status;
    }
}
