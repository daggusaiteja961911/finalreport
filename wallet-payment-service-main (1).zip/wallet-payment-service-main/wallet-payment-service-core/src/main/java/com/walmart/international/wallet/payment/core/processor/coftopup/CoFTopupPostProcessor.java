package com.walmart.international.wallet.payment.core.processor.coftopup;

import com.walmart.international.campaign.dto.enums.TransactionType;
import com.walmart.international.campaign.dto.request.RewardRequest;
import com.walmart.international.digiwallet.customer.api.dto.request.paymentInstrument.UpdateCardLastUsedDateRequest;
import com.walmart.international.digiwallet.service.flow.processor.IPostProcessor;
import com.walmart.international.notification.NotificationAdapter;
import com.walmart.international.notification.constants.MessagingType;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.dto.NotificationPayload;
import com.walmart.international.notification.smartcomm.dto.SmartCommV2LoadMoneyDTO;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.config.ccm.SingleScreenPaymentConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.SmartCommConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.TopupConfiguration;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.event.CampaignServiceNotifier;
import com.walmart.international.wallet.payment.core.event.payload.CampaignRewardEventPayload;
import com.walmart.international.wallet.payment.core.executor.LastUsedCardThreadPoolExecutor;
import com.walmart.international.wallet.payment.core.service.TxnAggregatorDataSyncService;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Component
@Slf4j
public class CoFTopupPostProcessor implements IPostProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private NotificationAdapter<NotificationPayload> notificationPayloadNotificationAdapter;

    @ManagedConfiguration
    private SmartCommConfiguration smartCommConfiguration;

    @ManagedConfiguration
    private TopupConfiguration topupConfiguration;

    @Autowired
    private CampaignServiceNotifier campaignServiceNotifier;

    @Autowired
    private TxnAggregatorDataSyncService txnAggregatorDataSyncService;

    @ManagedConfiguration
    SingleScreenPaymentConfiguration singleScreenPaymentConfiguration;

    @Autowired
    LastUsedCardThreadPoolExecutor lastUsedCardThreadPoolExecutor;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    @Override
    public boolean postProcess(WPSRequestDomainContext iwpsRequestDomainContext, WPSResponseDomainContext iwpsResponseDomainContext) {
        CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) iwpsResponseDomainContext;
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();

        log.info("Post processing started for CoFTopupTransaction:[{}]", coFTopUpTransaction.getTransactionId());

        if (Boolean.TRUE.equals(topupConfiguration.getSendCoFTopupConfirmationEmail())) {
            sendLoadMoneyConfirmationToEmail(coFTopupTxnResponseDomainContext);
        }

        txnAggregatorDataSyncService.pushTransactionDataToTAAS(coFTopupTxnResponseDomainContext);

        campaignServiceNotifier.notifyCampaignService(getCampaignRewardEventPayload(coFTopUpTransaction), coFTopUpTransaction.getCustomer().getCustomerAccountId());

        if (singleScreenPaymentConfiguration.isSaveLastUsedCardEnabled()) {
            updateLastUsedCardDate(coFTopUpTransaction.getCardPaymentTransactionList());
        }

        return true;
    }

    private void sendLoadMoneyConfirmationToEmail(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        Customer customer = coFTopupTxnResponseDomainContext.getTransaction().getCustomer();
        SmartCommV2LoadMoneyDTO dto = new SmartCommV2LoadMoneyDTO(customer.getFirstName(), smartCommConfiguration.getEventCoFTopupSuccessful(), customer.getEmailId());
        dto.setLastName(customer.getLastName());
        dto.setCashiConfirmationNumber(coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().getCashiOrderId());
        dto.setTransactionId(coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().getCashiOrderId());
        for (CardPaymentTransaction cardPaymentTransaction : coFTopupTxnResponseDomainContext.getTransaction().getCardPaymentTransactionList()) {
            setPaymentDetails(dto, cardPaymentTransaction);
            NotificationPayload notificationPayload = NotificationPayload.builder()
                    .emailEventType(WalletEventType.LOAD_MONEY_CONFIRM)
                    .smartCommV2EventDTO(dto)
                    .build();
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.EMAIL));
        }
    }

    private void setPaymentDetails(SmartCommV2LoadMoneyDTO dto, CardPaymentTransaction cardPaymentTransaction) {
        dto.setAmount(cardPaymentTransaction.getAmount().getValue());
        dto.setAuthCode(cardPaymentTransaction.getCardSubTransaction().getAuthCode());
        dto.setPbAffiliateID(cardPaymentTransaction.getCardSubTransaction().getPaymentProviderAffiliateId());
        dto.setLast4Digits(cardPaymentTransaction.getCardPaymentInstrument().getMetadata().getLast4Digits());
        dto.setBankName(cardPaymentTransaction.getCardPaymentInstrument().getBinDetails().getBankName());
        dto.setCardImageLink(cardPaymentTransaction.getCardPaymentInstrument().getBinDetails().getBrandLogo());
        dto.setNameOnCard(cardPaymentTransaction.getCardPaymentInstrument().getMetadata().getCardholderName());

    }

    private CampaignRewardEventPayload getCampaignRewardEventPayload(CoFTopUpTransaction coFTopUpTransaction) {
        CardPaymentTransaction cardPaymentTransaction = coFTopUpTransaction.getCardPaymentTransactionList().get(0);
        CardPaymentInstrument.BinDetails binDetails = cardPaymentTransaction.getCardPaymentInstrument().getBinDetails();
        RewardRequest rewardRequest = RewardRequest.builder()
                .transactionId(coFTopUpTransaction.getTransactionId())
                .transactionType(TransactionType.CARD_LOAD)
                .processingAmount(coFTopUpTransaction.getAmountFulfilled().getValue())
                .requestDate(Date.from(coFTopUpTransaction.getCreateDate().toInstant(ZoneOffset.UTC)))
                .storeId(WPSConstants.Common.PAYMENT_DEFAULT_STORE_ID)
                .bankName(binDetails.getBankName())
                .cardBrand(binDetails.getBrandName())
                .build();
        return CampaignRewardEventPayload.builder()
                .customerAccountId(coFTopUpTransaction.getCustomer().getCustomerAccountId())
                .eventType(WPSConstants.Event.REWARD_LOAD_MONEY)
                .rewardRequest(rewardRequest)
                .build();
    }

    private RewardRequest getRewardRequest(CoFTopupTransactionDO coFTopupTransactionDO, CardPaymentInstrument.BinDetails binDetails) {
        return RewardRequest.builder()
                .transactionId(coFTopupTransactionDO.getCoFTopupTransactionId())
                .transactionType(TransactionType.CARD_LOAD)
                .processingAmount(coFTopupTransactionDO.getAmountProcessed())
                .requestDate(Date.from(coFTopupTransactionDO.getCreateDate().toInstant(ZoneOffset.UTC)))
                .storeId(WPSConstants.Common.PAYMENT_DEFAULT_STORE_ID)
                .bankName(binDetails.getBankName())
                .cardBrand(binDetails.getBrandName())
                .build();
    }

    private void updateLastUsedCardDate(List<CardPaymentTransaction> cardPaymentTransactionList) {
        if (null != cardPaymentTransactionList && !cardPaymentTransactionList.isEmpty()) {
            CardPaymentTransaction cardPaymentTransaction = cardPaymentTransactionList.get(0);
            UUID paymentInstrumentId = cardPaymentTransaction.getPaymentInstrumentId();
            UpdateCardLastUsedDateRequest updateLastUsedCardRequest = UpdateCardLastUsedDateRequest.builder()
                    .paymentInstrumentId(paymentInstrumentId)
                    .lastUsedDate(new Date())
                    .build();
            CompletableFuture.runAsync(() -> customerServiceClient.updateCardLastUsedDate(updateLastUsedCardRequest), lastUsedCardThreadPoolExecutor).exceptionally(ex -> {
                log.error("Error in async processing of last used card date for cardPaymentInstrumentId: [{}], Exception: {}", paymentInstrumentId, ex);
                return null;
            });
        }
    }

}
