package com.walmart.international.wallet.payment.core.domain.model.request;

import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@ToString(callSuper = true)
public class BillRequestDomainContext extends WPSRequestDomainContext {
    private CustomerBillAccount customerBillAccount;
}
