package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus;

import com.walmart.commons.utils.StringUtils;
import com.walmart.international.services.digitalwallet.httpclient.util.HttpClientException;
import com.walmart.international.services.digitalwallet.httpclient.wallet.util.APIWebClientErrorHandler;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.APIHTTPClientConfigs;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.BillProcessor;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.request.ArcusCreateBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.request.ArcusPayBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response.ArcusCreateBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response.ArcusPayBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.webclient.ArcusAPIName;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorAuthorizationException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorProcessingException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorRequestRateException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorResourceNotFoundException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorValidationException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.CreateBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.PayBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.CreateBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import com.walmart.international.wallet.payment.core.config.ccm.ArcusConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Component
@Slf4j
public class ArcusBillProcessor implements BillProcessor {

    @Autowired
    @Qualifier("arcusWebClient")
    private WebClientV2 webClientV2;

    @ManagedConfiguration
    private ArcusConfiguration arcusConfiguration;

    private ArcusMapper arcusMapper = ArcusMapper.INSTANCE;

    private static final String BILLS_URL = "/bills";

    private static final String REFRESH_BILL_URL = "/refresh";

    private static final String PAY_BILL_URL = "/pay";

    private static final String SINGLE_PAY_URL = "/single/pay";

    @Override
    public PayBillResponse payBill(PayBillRequest request, int arcusAuthKeyVersion) throws BillProcessorException {
        ArcusPayBillRequest arcusPayBillRequest = createArcusPayBillRequest(request);
        log.info("Calling Arcus PayBill API for billerId[{}], accountNumber[{}] and amount[{}]",
                arcusPayBillRequest.getBillerId(), arcusPayBillRequest.getAccountNumber(), arcusPayBillRequest.getAmount());
        String apiUrl = getPayBillAPIUrl(request.getProcessorBillAccountId());
        HttpHeaders headers = ArcusClientHelper.getHeaders(apiUrl, ArcusClientHelper.VERSION_V3_MX, getBillPayConfig(arcusAuthKeyVersion));
        ResponseEntity<ArcusPayBillResponse> responseEntity;
        try {
            responseEntity = webClientV2.post(arcusConfiguration.getBaseUrl() + apiUrl,
                    null, headers, arcusPayBillRequest, ArcusPayBillResponse.class,
                    APIHTTPClientConfigs.builder().errorHandler(getArcusResponseErrorHandlerForPayBill()).build(), ArcusAPIName.PAY_BILL);
            log.info("Received response [{}] on calling Arcus PayBill API for billerId[{}], accountNumber[{}] and amount[{}]", responseEntity.getBody(),
                    arcusPayBillRequest.getBillerId(), arcusPayBillRequest.getAccountNumber(), arcusPayBillRequest.getAmount());
        } catch (Throwable e) {
            String msg = String.format("Error while calling Arcus PayBill API [%s]", e.getMessage());
            throw new BillProcessorProcessingException(ErrorConstants.ArcusClient.REQUEST_PROCESSING_FAILED, msg);
        }

        if (responseEntity.getBody() == null) {
            String msg = String.format("Error in Arcus PayBill API. Received null or empty responseBody: [%s]", responseEntity.getBody());
            throw new BillProcessorProcessingException(ErrorConstants.ArcusClient.NULL_OR_EMPTY_RESPONSE_BODY, msg);
        } else if (responseEntity.getStatusCode().value() != HttpStatus.SC_CREATED) {
            String msg = String.format("Error in response of Arcus PayBill API with statusCode: [%s] and statusMessage: [%s]",
                    responseEntity.getStatusCodeValue(), responseEntity.getBody().getMessage());
            if (responseEntity.getStatusCodeValue() == 400 || responseEntity.getStatusCodeValue() == 422) {
                String errorCode = getArcusClientValidationErrorCodeForPayBill(responseEntity.getBody().getCode());
                throw new BillProcessorValidationException(errorCode, msg);
            }
            throwBillProcessorExceptionBasedOnStatusCode(responseEntity.getStatusCodeValue(), msg);
        }

        return arcusMapper.getPayBillResponse(responseEntity.getBody());
    }

    private ArcusPayBillRequest createArcusPayBillRequest(PayBillRequest payBillRequest) {
        return ArcusPayBillRequest.builder()
                .accountNumber(payBillRequest.getAccountNumber())
                .amount(payBillRequest.getAmount())
                .billerId(Integer.parseInt(payBillRequest.getProcessorBillerId()))
                .currency(payBillRequest.getCurrency())
                .externalId(payBillRequest.getExternalId())
                .build();
    }

    private String getPayBillAPIUrl(String billId) {
        if (StringUtils.isNotEmpty(billId)) {
            return BILLS_URL + "/" + billId + PAY_BILL_URL;
        } else {
            return SINGLE_PAY_URL;
        }
    }

    @Override
    public CreateBillResponse createBill(CreateBillRequest request, int arcusAuthKeyVersion) throws BillProcessorException {
        ArcusCreateBillRequest arcusCreateBillRequest = createArcusCreateBillRequest(request);
        log.info("Calling Arcus CreateBill API for billerId[{}], accountNumber[{}]", arcusCreateBillRequest.getBillerId(), arcusCreateBillRequest.getAccountNumber());
        HttpHeaders headers = ArcusClientHelper.getHeaders(BILLS_URL, ArcusClientHelper.VERSION_V3_MX, getBillPayConfig(arcusAuthKeyVersion));
        ResponseEntity<ArcusCreateBillResponse> responseEntity;
        try {
            responseEntity = webClientV2.post(arcusConfiguration.getBaseUrl() + BILLS_URL,
                    null, headers, arcusCreateBillRequest, ArcusCreateBillResponse.class,
                    APIHTTPClientConfigs.builder().errorHandler(getArcusResponseErrorHandlerForCreateAndRefreshBill()).build(), ArcusAPIName.CREATE_BILL);
            log.info("Received response[{}] on calling Arcus CreateBill API for billerId[{}], accountNumber[{}]", responseEntity.getBody(),
                    arcusCreateBillRequest.getBillerId(), arcusCreateBillRequest.getAccountNumber());
        } catch (Throwable e) {
            String msg = String.format("Error while calling Arcus CreateBill API [%s]", e.getMessage());
            throw new BillProcessorProcessingException(ErrorConstants.ArcusClient.REQUEST_PROCESSING_FAILED, msg);
        }

        if (responseEntity.getBody() == null) {
            String msg = String.format("Error in Arcus CreateBill API. Received null or empty responseBody: [%s]", responseEntity.getBody());
            throw new BillProcessorProcessingException(ErrorConstants.ArcusClient.NULL_OR_EMPTY_RESPONSE_BODY, msg);
        } else if (responseEntity.getStatusCodeValue() != HttpStatus.SC_OK) {
            String msg = String.format("Error in response of Arcus CreateBill API with statusCode: [%s] and statusMessage: [%s]",
                    responseEntity.getStatusCodeValue(), responseEntity.getBody().getErrorMessage());
            if (responseEntity.getStatusCodeValue() == 400 || responseEntity.getStatusCodeValue() == 422) {
                String errorCode = getArcusClientValidationErrorCodeForCreateAndRefreshBill(responseEntity.getBody().getErrorCode());
                throw new BillProcessorValidationException(errorCode, msg);
            }
            throwBillProcessorExceptionBasedOnStatusCode(responseEntity.getStatusCodeValue(), msg);
        }

        return arcusMapper.getCreateBillResponse(responseEntity.getBody());
    }

    private ArcusCreateBillRequest createArcusCreateBillRequest(CreateBillRequest createBillRequest) {
        return ArcusCreateBillRequest.builder()
                .accountNumber(createBillRequest.getAccountNumber())
                .billerId(Integer.parseInt(createBillRequest.getProcessorBillerId()))
                .build();
    }

    @Override
    public CreateBillResponse refreshBill(String billId, int arcusAuthKeyVersion) throws BillProcessorException {
        log.info("Calling Arcus RefreshBill API for billId[{}]", billId);
        HttpHeaders headers = ArcusClientHelper.getHeaders(BILLS_URL + "/" + billId + REFRESH_BILL_URL, ArcusClientHelper.VERSION_V3_MX, getBillPayConfig(arcusAuthKeyVersion));
        ResponseEntity<ArcusCreateBillResponse> responseEntity = null;
        try {
            responseEntity = webClientV2.post(arcusConfiguration.getBaseUrl() + BILLS_URL + "/" + billId + REFRESH_BILL_URL,
                    null, headers, null, ArcusCreateBillResponse.class,
                    APIHTTPClientConfigs.builder().errorHandler(getArcusResponseErrorHandlerForCreateAndRefreshBill()).build(), ArcusAPIName.REFRESH_BILL);
            log.info("Received response[{}] on calling Arcus RefreshBill API for billId[{}]", responseEntity.getBody(), billId);
        } catch (Throwable e) {
            String msg = String.format("Error while calling Arcus RefreshBill API[%s]", e.getMessage());
            throw new BillProcessorProcessingException(ErrorConstants.ArcusClient.REQUEST_PROCESSING_FAILED, msg);
        }

        if (responseEntity.getBody() == null) {
            String msg = String.format("Error in Arcus RefreshBill API. Received null or empty responseBody: [%s]", responseEntity.getBody());
            throw new BillProcessorProcessingException(ErrorConstants.ArcusClient.NULL_OR_EMPTY_RESPONSE_BODY, msg);
        } else if (responseEntity.getStatusCodeValue() != HttpStatus.SC_OK) {
            String msg = String.format("Error in response of Arcus RefreshBill API with statusCode:[%s] and statusMessage:[%s]",
                    responseEntity.getStatusCodeValue(), responseEntity.getBody().getErrorMessage());
            if (responseEntity.getStatusCodeValue() == 400 || responseEntity.getStatusCodeValue() == 422) {
                String errorCode = getArcusClientValidationErrorCodeForCreateAndRefreshBill(responseEntity.getBody().getErrorCode());
                throw new BillProcessorValidationException(errorCode, msg);
            }
            throwBillProcessorExceptionBasedOnStatusCode(responseEntity.getStatusCodeValue(), msg);
        }

        return arcusMapper.getCreateBillResponse(responseEntity.getBody());
    }

    private Map<String, String> getBillPayConfig(int arcusApiSecretKeyVersion) {
        Map<String, String> billPayConfig = new HashMap<>();
        if (WPSConstants.Arcus.API_SECRET_KEY_VERSION_2 == arcusApiSecretKeyVersion && arcusConfiguration.isArcusAuthV2Enabled()) {
            log.info("Using V2 version of Arcus API and secret key.");
            billPayConfig.put(WPSConstants.Arcus.API_KEY, arcusConfiguration.getArcusApiKeyV2());
            billPayConfig.put(WPSConstants.Arcus.SECRET_KEY, arcusConfiguration.getArcusSecretKeyV2());
        }
        else {
            log.info("Using V1 version of Arcus API and secret key.");
            billPayConfig.put(WPSConstants.Arcus.API_KEY, arcusConfiguration.getArcusApiKeyV1());
            billPayConfig.put(WPSConstants.Arcus.SECRET_KEY, arcusConfiguration.getArcusSecretKeyV1());
        }
        return billPayConfig;
    }

    private APIWebClientErrorHandler getArcusResponseErrorHandlerForCreateAndRefreshBill() {
        Function<ClientResponse, Mono<? extends Throwable>> arcusResponseMonoFunction = arcusResponse -> arcusResponse.bodyToMono(ArcusCreateBillResponse.class)
                .flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, arcusResponse.statusCode()));
                });

        return APIWebClientErrorHandler.builder()
                .clientResponse4xxErrorHandler(arcusResponseMonoFunction)
                .clientResponse5xxErrorHandler(arcusResponseMonoFunction)
                .build();
    }

    private APIWebClientErrorHandler getArcusResponseErrorHandlerForPayBill() {
        Function<ClientResponse, Mono<? extends Throwable>> arcusResponseMonoFunction = arcusResponse -> arcusResponse.bodyToMono(ArcusPayBillResponse.class)
                .flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, arcusResponse.statusCode()));
                });
        return APIWebClientErrorHandler.builder()
                .clientResponse4xxErrorHandler(arcusResponseMonoFunction)
                .clientResponse5xxErrorHandler(arcusResponseMonoFunction)
                .build();
    }

    private void throwBillProcessorExceptionBasedOnStatusCode(int statusCode, String msg) throws BillProcessorException {
        if (statusCode == 401 || statusCode == 403) {
            throw new BillProcessorAuthorizationException(ErrorConstants.ArcusClient.AUTHORIZATION_FAILED, msg);
        } else if (statusCode == 404) {
            throw new BillProcessorResourceNotFoundException(ErrorConstants.ArcusClient.RESOURCE_NOT_FOUND, msg);
        } else if (statusCode == 429) {
            throw new BillProcessorRequestRateException(ErrorConstants.ArcusClient.REQUEST_RATE_EXCEEDED, msg);
        } else {
            throw new BillProcessorProcessingException(ErrorConstants.ArcusClient.REQUEST_PROCESSING_FAILED, msg);
        }
    }

    private String getArcusClientValidationErrorCodeForCreateAndRefreshBill(String arcusErrorCode) {
        switch (arcusErrorCode) {
            case "R2":
            case "R5":
                return ErrorConstants.ArcusClient.CREATE_REFERSH_BILL_INVALID_ACCOUNT_NUMBER;

            case "R8":
            case "R12":
                return ErrorConstants.ArcusClient.CREATE_REFRESH_BILL_PAYMENT_ALREADY_MADE;

            case "R19":
            case "R22":
            case "R24":
            case "R47":
            case "R48":
                return ErrorConstants.ArcusClient.CREATE_REFRESH_BILL_PAYMENT_UNAVAILABLE;

            case "R27":
                return ErrorConstants.ArcusClient.CREATE_REFRESH_BILL_OVERDUE;

            default:
                return ErrorConstants.ArcusClient.CREATE_REFRESH_BILL_GENERIC_FAILURE;
        }
    }

    private String getArcusClientValidationErrorCodeForPayBill(String arcusErrorCode) {
        switch (arcusErrorCode) {
            case "R2":
            case "R5":
                return ErrorConstants.ArcusClient.PAY_BILL_WRONG_NUMBER;

            case "R3":
            case "R11":
                return ErrorConstants.ArcusClient.PAY_BILL_WRONG_AMOUNT;

            case "R8":
            case "R12":
                return ErrorConstants.ArcusClient.PAY_BILL_PAYMENT_ALREADY_MADE;

            case "R27":
                return ErrorConstants.ArcusClient.PAY_BILL_OUTDATED_RECEIPT;

            case "R31":
                return ErrorConstants.ArcusClient.PAY_BILL_PHONE_NUMBER_INACTIVE;

            default:
                return ErrorConstants.ArcusClient.PAY_BILL_GENERIC_FAILURE;
        }
    }

}