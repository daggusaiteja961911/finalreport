package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.notification.NotificationAdapter;
import com.walmart.international.notification.constants.MessagingType;
import com.walmart.international.notification.dto.NotificationDetails;
import com.walmart.international.notification.dto.NotificationPayload;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.domain.CoreTransactionStatus;
import com.walmart.international.services.payment.core.domain.CoreTransactionType;
import com.walmart.international.services.payment.core.domain.Customer;
import com.walmart.international.services.payment.core.domain.GiftCardPayment;
import com.walmart.international.services.payment.core.domain.GiftCardPayments;
import com.walmart.international.services.payment.core.domain.GiftCardSubTransaction;
import com.walmart.international.services.payment.core.domain.InitiatedByType;
import com.walmart.international.services.payment.core.domain.Order;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.request.PayRequest;
import com.walmart.international.services.payment.core.response.PayResponse;
import com.walmart.international.wallet.payment.core.config.ccm.PangaeaConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentNotificationTemplateConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.TransactionMapper;
import com.walmart.international.wallet.payment.core.service.FlowExecutor;
import com.walmart.international.wallet.payment.core.service.TxnAggregatorDataSyncService;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@Component
@Slf4j
public class BillPayPaymentProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private FlowExecutor flowExecutor;

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    private PaymentCoreService paymentCoreService;

    @ManagedConfiguration
    private PangaeaConfiguration pangaeaConfiguration;

    @ManagedConfiguration
    private PaymentNotificationTemplateConfiguration paymentNotificationTemplateConfiguration;

    @Autowired
    private WalletPaymentServiceUtil walletPaymentServiceUtil;

    @Autowired
    private NotificationAdapter<NotificationPayload> notificationPayloadNotificationAdapter;

    @Autowired
    private TxnAggregatorDataSyncService txnAggregatorDataSyncService;

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    private TransactionMapper transactionMapper = TransactionMapper.INSTANCE;

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        if (!isGiftCardOnlyTransaction(billPayTransaction)) {
            if (is3DSFlowAcknowledged(billPayTransaction)) {
                try {
                    processInternalValidateCoFTopup(billPayTxnResponseDomainContext);
                } catch (ApplicationException ae) {
                    log.error("Error in processing internal validateCoFTopup for bill pay txn with transactionId:[{}], errorCode:[{}] and errorMessage:[{}]. StackTrace:[{}]",
                            billPayTxnResponseDomainContext.getTransaction().getTransactionId(), ae.getErrorCode(), ae.getMessage(), ExceptionUtils.getStackTrace(ae));
                    updateBillPayTxnState(billPayTxnResponseDomainContext,
                            TransactionStateEnum.FAILURE,
                            BillPayTxnStateReason.TOPUP_3DS_FAILED);
                    sendBillPaymentFailurePushNotification(billPayTxnResponseDomainContext.getTransaction());
                    transformToGiftCardOnlyPaymentRequest(billPayTxnResponseDomainContext.getTransaction());
                    registerPayRequestWithGivenStatusForGiftCardPayment(billPayTxnResponseDomainContext, CoreTransactionStatus.FAILED);
                    txnAggregatorDataSyncService.pushTransactionDataToTAAS(billPayTxnResponseDomainContext);
                    return false;
                } catch (Exception ex) {
                    String msg = String.format("Failed to complete internalValidateCoFTopup for BillPayTransaction with txnId[%s]", billPayTxnResponseDomainContext.getTransaction().getTransactionId());
                    throw new ProcessingException(ErrorConstants.PayBillInit.INTERNAL_VALIDATE_COF_TOPUP_FAILED, msg, ex);
                }
            } else {
                try {
                    processInternalCoFTopup(billPayTxnResponseDomainContext);
                } catch (ApplicationException ae) {
                    log.error("Error in processing internal coFTopup for bill pay txn with transactionId:[{}], errorCode:[{}] and errorMessage:[{}]. StackTrace:[{}]",
                            billPayTxnResponseDomainContext.getTransaction().getTransactionId(), ae.getErrorCode(), ae.getMessage(), ExceptionUtils.getStackTrace(ae));
                    updateBillPayTxnState(billPayTxnResponseDomainContext,
                            TransactionStateEnum.FAILURE,
                            BillPayTxnStateReason.TOPUP_FAILED);
                    sendBillPaymentFailurePushNotification(billPayTxnResponseDomainContext.getTransaction());
                    transformToGiftCardOnlyPaymentRequest(billPayTxnResponseDomainContext.getTransaction());
                    registerPayRequestWithGivenStatusForGiftCardPayment(billPayTxnResponseDomainContext, CoreTransactionStatus.FAILED);
                    txnAggregatorDataSyncService.pushTransactionDataToTAAS(billPayTxnResponseDomainContext);
                    return false;
                } catch (Exception ex) {
                    String msg = String.format("Failed to complete internalCoFTopup for BillPayTransaction with txnId[%s]", billPayTxnResponseDomainContext.getTransaction().getTransactionId());
                    throw new ProcessingException(ErrorConstants.PayBillInit.INTERNAL_COF_TOPUP_FAILED, msg, ex);
                }
                transformToGiftCardOnlyPaymentRequest(billPayTxnResponseDomainContext.getTransaction());
                if (is3DSFlow(billPayTxnResponseDomainContext.getTransaction().getInternalCoFTopupTransaction())) {
                    updateBillPayTxnState(billPayTxnResponseDomainContext,
                            TransactionStateEnum.PENDING,
                            BillPayTxnStateReason.TOPUP_3DS_GENERATED);
                    registerPayRequestWithGivenStatusForGiftCardPayment(billPayTxnResponseDomainContext, CoreTransactionStatus.ON_HOLD);
                    txnAggregatorDataSyncService.pushTransactionDataToTAAS(billPayTxnResponseDomainContext);
                    return false;
                }
            }
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                TransactionStateEnum.PENDING,
                BillPayTxnStateReason.TOPUP_SUCCESS);
        }

        try {
            processGiftCardPayment(billPayTxnResponseDomainContext);
        } catch (ProcessingException pe) {
            log.error("Error in processing giftCard payment for bill pay txn with transactionId:[{}], errorCode:[{}] and errorMessage:[{}]. StackTrace:[{}]",
                    billPayTransaction.getTransactionId(), pe.getErrorCode(), pe.getMessage(), ExceptionUtils.getStackTrace(pe));
            txnAggregatorDataSyncService.pushTransactionDataToTAAS(billPayTxnResponseDomainContext);
            sendBillPaymentFailurePushNotification(billPayTransaction);
            return false;
        } catch (Exception ex) {
            String msg = String.format("Failed to complete giftCard payment for BillPayTransaction with txnId[%s]", billPayTxnResponseDomainContext.getTransaction().getTransactionId());
            throw new ProcessingException(ErrorConstants.PayBillInit.PAYMENT_CORE_GIFT_CARD_PAYMENT_FAILED, msg, ex);
        }
        return true;
    }

    private boolean is3DSFlowAcknowledged(BillPayTransaction billPayTransaction) {
        return TransactionStateEnum.PENDING.name().equals(billPayTransaction.getState().name()) &&
                BillPayTxnStateReason.TOPUP_3DS_ACKNOWELDGED.name().equals(billPayTransaction.getStateReason().name());
    }

    private boolean isGiftCardOnlyTransaction(BillPayTransaction billPayTransaction) {
        return CollectionUtils.isEmpty(billPayTransaction.getCardPaymentTransactionList())
                && CollectionUtils.isNotEmpty(billPayTransaction.getGiftCardPaymentTransactionList());
    }

    private void registerPayRequestWithGivenStatusForGiftCardPayment(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext, CoreTransactionStatus status) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        String clientTransactionId = billPayTransaction.getTransactionId().toString();
        try {
            log.info("Registering pay request with clientTransactionId:[{}] for BillPayTransaction with txnId:[{}] with coreTransactionStatus:[{}]",
                    clientTransactionId, billPayTransaction.getTransactionId(), status);
            PayRequest payRequest = getPayRequest(clientTransactionId, billPayTxnResponseDomainContext);
            PayResponse payResponse = paymentCoreService.registerPayRequest(payRequest, status);
            mapPayResponseToContext(payResponse, billPayTransaction);
        } catch (Exception ex) {
            String msg = String.format("Failed to register pay request for BillPayTransaction with txnId[%s] and coreTransactionStatus[%s]",
                    billPayTransaction.getTransactionId(), status);
            throw new ProcessingException(ErrorConstants.PayBillInit.PAYMENT_CORE_REGISTER_PAY_REQUEST_FAILED, msg, ex);
        }
    }

    private void processGiftCardPayment(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        String clientTransactionId = billPayTransaction.getTransactionId().toString();
        try {
            log.info("Processing giftCard payment for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
            PayRequest payRequest = getPayRequest(clientTransactionId, billPayTxnResponseDomainContext);
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.PENDING,
                    BillPayTxnStateReason.DEBIT_INITIATED);
            PayResponse payResponse = paymentCoreService.pay(payRequest);
            mapPayResponseToContext(payResponse, billPayTransaction);
            if (CoreTransactionStatus.SUCCEEDED.equals(payResponse.getStatus())) {
                updateBillPayTxnState(billPayTxnResponseDomainContext,
                        TransactionStateEnum.PENDING,
                        BillPayTxnStateReason.DEBIT_SUCCESS);
            } else {
                updateBillPayTxnState(billPayTxnResponseDomainContext,
                        TransactionStateEnum.FAILURE,
                        BillPayTxnStateReason.DEBIT_FAILED);
                checkErrorCodeAndSendGiftCardAccountLockedPushNotification(billPayTxnResponseDomainContext);
                String msg = String.format("Failed to complete giftCard payment for BillPayTransaction with txnId[%s]", billPayTransaction.getTransactionId());
                throw new ProcessingException(ErrorConstants.PayBillInit.PAYMENT_CORE_GIFT_CARD_PAYMENT_FAILED, msg);
            }
        } catch (PaymentCoreServiceException pcse) {
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    BillPayTxnStateReason.DEBIT_FAILED);
            String msg = String.format("Failed to complete giftCard payment for BillPayTransaction with txnId[%s]", billPayTransaction.getTransactionId());
            throw new ProcessingException(ErrorConstants.PayBillInit.PAYMENT_CORE_GIFT_CARD_PAYMENT_FAILED, msg, pcse);
        }

    }

    private PayRequest getPayRequest(String clientTransactionId, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        log.info("Generating pay request for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
        PayRequest.PayRequestBuilder payRequestBuilder = PayRequest.builder()
                .clientTransactionId(clientTransactionId)
                .allowPartial(Boolean.FALSE)
                .storeId(pangaeaConfiguration.getSystemStoreId())
                .terminalId(pangaeaConfiguration.getSystemTerminalId())
                .coreTransactionType(CoreTransactionType.PAY)
                .initiatedBy(InitiatedByType.ONLINE);

        try {
            payRequestBuilder.accountingDate(DATE_FORMAT.parse(DATE_FORMAT.format(new Date())));
        } catch (ParseException pe) {
            log.error("Error while parsing ewalletaccounting date for customerAccountId[{}] for creating payRequest for BillPayTransaction with txnId[{}]",
                    billPayTransaction.getCustomer().getCustomerAccountId(), billPayTransaction.getTransactionId());
        }

        Customer customer = Customer.builder()
                .customerId(billPayTransaction.getCustomer().getCustomerAccountId().toString())
                .email(billPayTransaction.getCustomer().getEmailId())
                .firstName(billPayTransaction.getCustomer().getFirstName())
                .lastName(billPayTransaction.getCustomer().getLastName())
                .accountCreationDate(billPayTransaction.getCustomer().getCreateDate())
                .birthDate(billPayTransaction.getCustomer().getCreateDate())
                .phoneNumber(billPayTransaction.getCustomer().getPhone())
                .build();
        payRequestBuilder.customer(customer);

        GiftCardPayments.GiftCardPaymentsBuilder giftCardPaymentsBuilder = GiftCardPayments.builder();
        for (GiftCardTransaction giftCardPaymentTransaction : billPayTransaction.getGiftCardPaymentTransactionList()) {
            GiftCardPayment giftCardPayment = GiftCardPayment.builder()
                    .paymentProviderInstrumentId(giftCardPaymentTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash())
                    .paymentInstrumentId(giftCardPaymentTransaction.getPaymentInstrumentId())
                    .amount(com.walmart.international.services.payment.core.domain.Amount.builder()
                            .amount(giftCardPaymentTransaction.getAmount().getValue())
                            .currencyUnit(com.walmart.international.services.payment.core.domain.Amount.CurrencyUnit.valueOf(giftCardPaymentTransaction.getAmount().getCurrencyUnit().name()))
                            .build())
                    .build();
            giftCardPaymentsBuilder.giftCardPaymentList(giftCardPayment);
        }
        payRequestBuilder.giftCardPayments(giftCardPaymentsBuilder.build());

        Order order = Order.builder()
                .orderId(billPayTransaction.getCashiOrderId())
                .storeUrl(walletPaymentServiceConfiguration.getStoreURL())
                .orderType(Order.OrderType.BILL_PAY)
                .build();
        payRequestBuilder.order(order);

        return payRequestBuilder.build();
    }

    private void mapPayResponseToContext(PayResponse payResponse, BillPayTransaction billPayTransaction) {
        log.info("Mapping pay response to context for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
        transactionMapper.mapPayResponseToTransaction(payResponse, billPayTransaction);
        for (GiftCardSubTransaction giftCardSubTransaction : payResponse.getGiftCardSubTransactions()) {
            Optional<GiftCardTransaction> oGiftCardPaymentTransaction = billPayTransaction.getGiftCardPaymentTransactionList().stream()
                    .filter(giftCardPaymentTransaction -> giftCardPaymentTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash()
                            .equals(giftCardSubTransaction.getPaymentProviderInstrumentId()))
                    .findFirst();
            oGiftCardPaymentTransaction.ifPresent(giftCardPaymentTransaction ->
                    giftCardPaymentTransaction.setGiftCardSubTransaction(transactionMapper.mapGiftCardSubTxnFromPaymentCoreResponse(giftCardSubTransaction)));
        }
    }

    private void processInternalCoFTopup(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        CardPaymentTransaction cardPaymentTransaction = billPayTransaction.getCardPaymentTransactionList().get(0);
        log.info("Processing internalCoFTopup for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());

        CoFTopUpTransaction.CoFTopUpTransactionBuilder coFTopUpTransactionBuilder = CoFTopUpTransaction.builder()
                .transactionType(TransactionType.COF_TOPUP)
                .parentTransactionType(TransactionType.BILL_PAY)
                .transactionReferenceId(String.valueOf(billPayTransaction.getTransactionId()))
                .parentTransaction(billPayTransaction)
                .amountRequested(Amount.builder()
                        .value(cardPaymentTransaction.getAmount().getValue())
                        .currencyUnit(cardPaymentTransaction.getAmount().getCurrencyUnit())
                        .build())
                .cardPaymentTransactionList(cardPaymentTransaction)
                .customer(billPayTransaction.getCustomer());

        CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext = CoFTopupTxnRequestDomainContext.builder()
                .clientRequestId(billPayTxnResponseDomainContext.getClientRequestId())
                .transaction(coFTopUpTransactionBuilder.build())
                .headers(billPayTxnResponseDomainContext.getHeaders())
                .build();
        CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = CoFTopupTxnResponseDomainContext.builder().build();

        updateBillPayTxnState(billPayTxnResponseDomainContext,
                TransactionStateEnum.PENDING,
                BillPayTxnStateReason.TOPUP_INITIATED);
        billPayTransaction.setInternalCoFTopupTransaction(coFTopupTxnRequestDomainContext.getTransaction());
        flowExecutor.executeFlowType(MXFlowType.COF_TOPUP, coFTopupTxnRequestDomainContext, coFTopupTxnResponseDomainContext);

        if (coFTopupTxnResponseDomainContext.getTransaction().getState().equals(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.FAILURE)) {
            String msg = String.format("Failed to complete internalCoFTopup for BillPayTransaction with txnId[%s]", billPayTxnResponseDomainContext.getTransaction().getTransactionId());
            throw new ProcessingException(ErrorConstants.PayBillInit.INTERNAL_COF_TOPUP_FAILED, msg);
        }
    }

    private boolean is3DSFlow(CoFTopUpTransaction coFTopupTransaction) {
        return coFTopupTransaction.getState().equals(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.PENDING)
                && coFTopupTransaction.getStateReason().equals(CoFTopupTxnStateReason.DEBIT_3DS_GENERATED);
    }

    private void processInternalValidateCoFTopup(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        log.info("Processing internalValidateCoFTopup for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());

        CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext = CoFTopupTxnRequestDomainContext.builder()
                .transaction(billPayTransaction.getInternalCoFTopupTransaction())
                .headers(billPayTxnResponseDomainContext.getHeaders())
                .build();
        CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = CoFTopupTxnResponseDomainContext.builder().build();

        flowExecutor.executeFlowType(MXFlowType.VALIDATE_COF_TOPUP, coFTopupTxnRequestDomainContext, coFTopupTxnResponseDomainContext);
        if (coFTopupTxnResponseDomainContext.getTransaction().getState().equals(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.FAILURE)) {
            String msg = String.format("Failed to complete internalValidateCoFTopup for BillPayTransaction with txnId[%s]", billPayTxnResponseDomainContext.getTransaction().getTransactionId());
            throw new ProcessingException(ErrorConstants.PayBillInit.INTERNAL_VALIDATE_COF_TOPUP_FAILED, msg);
        }
        billPayTransaction.setCardPaymentTransactionList(Collections.emptyList());
    }


    private void updateBillPayTxnState(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext,
                                       TransactionStateEnum state, BillPayTxnStateReason stateReason) {
        BillPayTransactionDO billPayTransactionDO = billPayTxnResponseDomainContext.getBillPayTransactionDO();
        log.info("Updating BillPayTransaction with txnId:[{}] with state:[{}] and stateReason:[{}]",
                billPayTransactionDO.getBillPayTransactionId(), state, stateReason);
        if (!state.equals(billPayTransactionDO.getState()) && state.equals(TransactionStateEnum.FAILURE)) {
            billPayTransactionDO.updateTxnReqCompletedDate();
        }

        billPayTransactionDO = walletPaymentServiceUtil.updateLastEventDateCheck(billPayTransactionDO, state, stateReason);

        billPayTransactionDO.setState(state);
        billPayTransactionDO.setStateReason(stateReason);
        billPayTransactionDO = billPayTransactionRepository.save(billPayTransactionDO);
        billPayTxnResponseDomainContext.setBillPayTransactionDO(billPayTransactionDO);

        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        billPayTransaction.setState(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.valueOf(state.name()));
        billPayTransaction.setStateReason(com.walmart.international.wallet.payment.core.constants.enums.BillPayTxnStateReason.valueOf(stateReason.name()));
    }

    private void checkErrorCodeAndSendGiftCardAccountLockedPushNotification(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        List<String> accountLockedErrorCodes = Arrays.asList("PAY-105", "PAY-110");
        if (accountLockedErrorCodes.contains(billPayTransaction.getFailureCode())) {
            sendGiftCardAccountLockedPushNotification(billPayTransaction.getCustomer().getCustomerAccountId().toString());
        }
    }

    private void sendGiftCardAccountLockedPushNotification(String customerAccountId) {
        try {
            log.info("Sending giftCard account locked push notification for customerAccountId:[{}]", customerAccountId);
            NotificationPayload notificationPayload = BillPayUtil.getNotificationPayloadForGiftCardAccountLockedPushNotification(customerAccountId);
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.PUSH));
        } catch (Exception ex) {
            log.error("Error while sending account locked push notification for customerAccountId[{}}. StackTrace: [{}]", customerAccountId, ExceptionUtils.getStackTrace(ex));
        }
    }

    private void sendBillPaymentFailurePushNotification(BillPayTransaction billPayTransaction) {
        try {
            log.info("Sending bill pay failure push notification for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
            NotificationPayload<NotificationDetails> notificationPayload = BillPayUtil.getNotificationPayloadForPayBillFailurePushNotification(billPayTransaction,
                    paymentNotificationTemplateConfiguration.getPaymentFailedReversalNotificationWarningLogo(),
                    paymentNotificationTemplateConfiguration.getPaymentFailedReversalPushExpiryTime());
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.PUSH));
        } catch (Exception ex) {
            log.error("Error in sendBillPaymentFailurePushNotification for billPayTransaction:[{}]. StackTrace: [{}]",
                    billPayTransaction.getTransactionId(), ExceptionUtils.getStackTrace(ex));
        }
    }

    private void transformToGiftCardOnlyPaymentRequest(BillPayTransaction billPayTransaction) {
        log.info("Transforming to giftCard only payment request for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
        Optional<GiftCardPaymentInstrument> primaryGiftCardPaymentInstrumentOptional = billPayTransaction.getCustomer().getGiftCardPaymentInstrumentList().stream()
                .filter(giftCardPaymentInstrument -> giftCardPaymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.GIFTCARD) && giftCardPaymentInstrument.getPaymentInstrumentSubType().equals(PaymentInstrumentSubType.CASHI_WALLET)).findFirst();
        if (primaryGiftCardPaymentInstrumentOptional.isPresent()) {
            GiftCardPaymentInstrument primaryGiftCardPaymentInstrument = primaryGiftCardPaymentInstrumentOptional.get();
            Optional<GiftCardTransaction> primaryGiftCardPaymentTransactionOptional;
            if (CollectionUtils.isNotEmpty(billPayTransaction.getGiftCardPaymentTransactionList())) {
                primaryGiftCardPaymentTransactionOptional = billPayTransaction.getGiftCardPaymentTransactionList().stream()
                        .filter(giftCardTransaction -> primaryGiftCardPaymentInstrument.getPaymentInstrumentId().equals(giftCardTransaction.getPaymentInstrumentId().toString()))
                        .findFirst();
                if (primaryGiftCardPaymentTransactionOptional.isPresent()) {
                    BigDecimal totalPrimaryGiftCardAmountValue = primaryGiftCardPaymentTransactionOptional.get().getAmount().getValue().add(billPayTransaction.getInternalCoFTopupTransaction().getAmountRequested().getValue());
                    primaryGiftCardPaymentTransactionOptional.get().getAmount().setValue(totalPrimaryGiftCardAmountValue);
                } else {
                    billPayTransaction.getGiftCardPaymentTransactionList().add(GiftCardTransaction.builder()
                            .paymentInstrumentId(UUID.fromString(primaryGiftCardPaymentInstrument.getPaymentInstrumentId()))
                            .amount(billPayTransaction.getInternalCoFTopupTransaction().getAmountRequested())
                            .giftCardTransactionType(GiftCardTransactionType.PAY)
                            .giftCardPaymentInstrument(primaryGiftCardPaymentInstrument)
                            .build());
                }
            } else {
                billPayTransaction.setGiftCardPaymentTransactionList(Collections.singletonList(GiftCardTransaction.builder()
                        .paymentInstrumentId(UUID.fromString(primaryGiftCardPaymentInstrument.getPaymentInstrumentId()))
                        .amount(billPayTransaction.getInternalCoFTopupTransaction().getAmountRequested())
                        .giftCardTransactionType(GiftCardTransactionType.PAY)
                        .giftCardPaymentInstrument(primaryGiftCardPaymentInstrument)
                        .build()));
            }
            billPayTransaction.setCardPaymentTransactionList(Collections.emptyList());
        }
    }

}
