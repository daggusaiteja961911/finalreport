package com.walmart.international.wallet.payment.core.adapter.kafka.consumer;

import com.walmart.international.services.payment.core.kafka.response.AsyncChargeKafkaPayload;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.InvalidKafkaPayloadException;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.InvalidKafkaResponseException;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.KafkaResponseMappingException;
import com.walmart.international.wallet.payment.core.adapter.kafka.handler.ChargeReconHandler;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.PBChargeKafkaResponse;
import com.walmart.international.wallet.payment.core.config.ccm.KafkaConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.mapper.PBChargeKafkaResponseMapper;
import com.walmart.kafka.consumer.BaseConsumer;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("pbChargeConsumerV2")
@Slf4j
public class PBChargeKafkaListener extends BaseConsumer<PBChargeKafkaResponse> {

    @Autowired
    private PBChargeKafkaResponseMapper pbChargeKafkaResponseMapper;

    @Autowired
    private ChargeReconHandler chargeReconHandler;

    @ManagedConfiguration
    private KafkaConfiguration kafkaConfiguration;

    @Override
    protected void process(PBChargeKafkaResponse message) {
        log.info("PBChargeKafkaListener :: processing charge recon message : {}", message);
        if (kafkaConfiguration.isPBKafkaChargeConsumerEnabled()) {
            //validate kafka message
            if (message == null || message.getEventPayload() == null || message.getEventType() == null) {
                throw new InvalidKafkaResponseException(ErrorConstants.KafkaChargeRecon.INVALID_KAFKA_CHARGE_PAYLOAD);
            }

            AsyncChargeKafkaPayload payload = null;
            try {
                AsyncChargeKafkaPayload.AsyncChargeKafkaResponse asyncRequest = pbChargeKafkaResponseMapper.mapPBKafkaResponseToPaymentCoreRequest(message);
                payload = new AsyncChargeKafkaPayload(List.of(asyncRequest));
            } catch (Exception ex) {
                throw new KafkaResponseMappingException(ErrorConstants.KafkaChargeRecon.MAPPING_ERROR_FROM_KAFKA_TO_PAYMENT_CORE,
                        "Error while mapping kafka response to payment core", ex);
            }

            try {
                chargeReconHandler.handle(payload);
            } catch (InvalidKafkaPayloadException e) {
                log.error("Invalid charge kafka payload error: {}", e.getErrorCode());
            } catch (Exception ex) {
                log.error("Error while handling charge recon : {} for payload : {}", ex.getCause(), payload, ex);
            }
        } else {
            log.info("Ignoring incoming PB charge kafka message as config is disabled");
        }

    }

    public void listen(PBChargeKafkaResponse message) {
        process(message);
    }

    @Override
    protected Class<PBChargeKafkaResponse> getMessageClass() {
        return PBChargeKafkaResponse.class;
    }
}
