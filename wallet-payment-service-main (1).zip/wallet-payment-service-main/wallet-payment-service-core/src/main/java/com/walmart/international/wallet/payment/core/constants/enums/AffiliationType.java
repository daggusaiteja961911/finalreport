package com.walmart.international.wallet.payment.core.constants.enums;

public enum AffiliationType {
    CVV,
    CVV_LESS,
    NON_CVV_CUST_NP
}
