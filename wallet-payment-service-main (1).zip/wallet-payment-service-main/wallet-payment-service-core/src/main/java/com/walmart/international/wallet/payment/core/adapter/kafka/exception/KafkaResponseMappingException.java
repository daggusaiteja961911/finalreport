package com.walmart.international.wallet.payment.core.adapter.kafka.exception;

import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;

public class KafkaResponseMappingException extends ProcessingException {
    public KafkaResponseMappingException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, cause);
    }
}
