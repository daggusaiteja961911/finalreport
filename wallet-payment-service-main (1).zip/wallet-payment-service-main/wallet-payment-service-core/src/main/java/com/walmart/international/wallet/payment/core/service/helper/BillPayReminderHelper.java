package com.walmart.international.wallet.payment.core.service.helper;

import com.walmart.international.notification.config.NotificationConfig;
import com.walmart.international.notification.constants.MessagingEvent;
import com.walmart.international.notification.constants.MessagingType;
import com.walmart.international.notification.constants.TypeMessage;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.dto.NotificationPayload;
import com.walmart.international.notification.dto.PushNotificationEventDTO;
import com.walmart.international.notification.dto.ReminderPayloadDTO;
import com.walmart.international.notification.exceptions.ReminderServiceException;
import com.walmart.international.notification.smartcomm.dto.SmartCommV2BillPayReminderDTO;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataActionStatus;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataCategory;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataDetails;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataStatus;
import com.walmart.international.services.notificationservice.naas.NaasGenericPayloadType;
import com.walmart.international.services.notificationservice.naas.ReminderCategoryType;
import com.walmart.international.services.notificationservice.naas.ReminderSubCategoryType;
import com.walmart.international.wallet.payment.core.config.ccm.BillReminderConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.SmartCommConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.NotificationPlaceholderConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.dto.NotificationContentDTO;
import com.walmart.international.wallet.payment.core.dto.ReminderCategoryDTO;
import com.walmart.international.wallet.payment.core.utils.WPSDateUtils;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentIdentifierType;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentSubcategory;
import com.walmart.international.wallet.payment.data.dao.entity.NotificationContentDO;
import com.walmart.pangaea.payment.util.StringUtil;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.joda.time.DateTimeComparator;
import io.strati.libs.joda.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Used by BillPayReminderService
 * @author v0c03uq
 * @author h0s08t6
 * @author h0h06fb
 */
@Component
@Slf4j
public class BillPayReminderHelper {

    @ManagedConfiguration
    private NotificationConfig notificationConfig;

    @ManagedConfiguration
    private BillReminderConfiguration billReminderConfiguration;

    @ManagedConfiguration
    private SmartCommConfiguration smartCommConfiguration;

    public ReminderPayloadDTO generateNewBillPayPushReminderPayload(CustomerBillAccount customerBillAccount, NotificationContentDTO notificationContentDTO, ReminderCategoryDTO reminderCategoryDTO, Date reminderDate) {
        if (Objects.isNull(customerBillAccount)) return null;

        NOCMetaDataDetails nocMetaDataDetails = NOCMetaDataDetails.builder()
            .category(NOCMetaDataCategory.SERVICES)
            .status(NOCMetaDataStatus.INFORMATIONAL)
            .actionStatus(NOCMetaDataActionStatus.NON_ACTIONABLE)
            .isActionable(true)
            .build();

        PushNotificationEventDTO pushNotificationEventDTO = PushNotificationEventDTO.builder()
            .event(reminderCategoryDTO.getMessagingEvent())
            .message(notificationContentDTO.getMessage())
            .customerId(customerBillAccount.getCustomerAccountId().toString())
            .title(notificationContentDTO.getTitle())
            .typeMessage(TypeMessage.TEXT)
            .action(WPSConstants.Notification.SHOW_BILLER_ACTION)
            .deeplinkUrl(getBillPayReminderDeeplink(customerBillAccount))
            .nocMetadata(nocMetaDataDetails)
            .build();

        NotificationPayload notificationPayload = NotificationPayload.builder()
            .typeForNotificationService(List.of(MessagingType.PUSH))
            .correlationId(customerBillAccount.getCustomerBillAccountId())
            .pushEventType(WalletEventType.REMINDER)
            .pushNotiEventDTO(pushNotificationEventDTO)
            .build();

        return ReminderPayloadDTO.builder()
            .reminderPayloadType(NaasGenericPayloadType.REMINDER_ADD)
            .clientRequestId(customerBillAccount.getCustomerBillAccountId())
            .category(ReminderCategoryType.BILL_PAY_REMINDER)
            .subCategory(reminderCategoryDTO.getReminderSubCategoryType().name())
            .reminderDate(reminderDate)
            .notificationPayload(notificationPayload)
            .build();
    }

    public ReminderPayloadDTO generateNewBillPayEmailReminderPayload(CustomerBillAccount customerBillerAccount, Customer customer, ReminderSubCategoryType reminderSubCategory, Date reminderDate, MessagingEvent messagingEvent) throws ReminderServiceException {
        if (customerBillerAccount == null)
            return null;

        String smartcommEventName = getSmartCommEventName(messagingEvent, customerBillerAccount.getAlias() != null && !Objects.equals(customerBillerAccount.getAlias(), ""));
        String emailAction = getBillPayReminderEmailActionButton(customerBillerAccount);

        SmartCommV2BillPayReminderDTO reminderEmailDTO = new SmartCommV2BillPayReminderDTO(customerBillerAccount.getNameOnAccount(), smartcommEventName, customer.getEmailId());
        reminderEmailDTO.setBiller(customerBillerAccount.getBiller().getDisplayName());
        reminderEmailDTO.setBillerLogoUrl(customerBillerAccount.getBiller().getImageURL());
        reminderEmailDTO.setAlias(customerBillerAccount.getAlias());
        reminderEmailDTO.setLastPaidDate(WPSDateUtils.dateToSpanishText(customerBillerAccount.getLastPaidDate()));
        reminderEmailDTO.setAmount(null == customerBillerAccount.getDueAmount() ? customerBillerAccount.getLastPaidAmount() : customerBillerAccount.getDueAmount());
        reminderEmailDTO.setExpiryDate(WPSDateUtils.dateToSpanishText(reminderDate));
        reminderEmailDTO.setUser(customerBillerAccount.getNameOnAccount());
        reminderEmailDTO.setAction(emailAction);

        NotificationPayload notificationPayload = NotificationPayload.builder()
            .typeForNotificationService(List.of(MessagingType.EMAIL))
            .correlationId(customerBillerAccount.getCustomerBillAccountId())
            .emailEventType(WalletEventType.BILL_PAY_EMAIL_REMINDER)
            .smartCommV2EventDTO(reminderEmailDTO)
            .build();

        return ReminderPayloadDTO.builder()
            .reminderPayloadType(NaasGenericPayloadType.REMINDER_ADD)
            .clientRequestId(customerBillerAccount.getCustomerBillAccountId())
            .category(ReminderCategoryType.BILL_PAY_REMINDER)
            .subCategory(reminderSubCategory.toString())
            .reminderDate(reminderDate)
            .notificationPayload(notificationPayload)
            .build();
    }

    public String getSmartCommEventName(MessagingEvent messagingEvent, Boolean hasAlias) throws ReminderServiceException {
        if (messagingEvent == MessagingEvent.BILL_PAY_FIRST_REMINDER || messagingEvent == MessagingEvent.BILL_PAY_SECOND_REMINDER) {
            return Boolean.TRUE.equals(hasAlias) ? smartCommConfiguration.getBillPayReminderSoonWithAliasEvent() : smartCommConfiguration.getBillPayReminderSoonEvent();
        }
        else if (messagingEvent == MessagingEvent.BILL_PAY_REMINDER_ON_DUE_DATE) {
            return Boolean.TRUE.equals(hasAlias) ? smartCommConfiguration.getBillPayReminderOnDueDateWithAliasEvent() : smartCommConfiguration.getBillPayReminderOnDueDateEvent();
        }
        else if (messagingEvent == MessagingEvent.BILL_PAY_NUDGE) {
            return smartCommConfiguration.getBillPayNudgeEvent();
        }
        throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_SMARTCOMM_EVENT_NOT_EXISTS, String.format("No event name exists for the provided MessagingEvent[%s]", messagingEvent.toString()));
    }

    public boolean isConsumptionBasedBiller(Biller biller) {
        if (Objects.isNull(biller)) {
            return false;
        }
        return biller.getDisplayName().contains(WPSConstants.Biller.CINEPOLIS);
    }

    @Nullable
    private Date getDate(Date currentDate, Date plannedReminderDate, Date reminderDateLastDay) {
        DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

        Date reminderDate = null;
        if (dateTimeComparator.compare(currentDate, plannedReminderDate) < 0) {
            reminderDate = plannedReminderDate;
        }
        else if (dateTimeComparator.compare(currentDate, reminderDateLastDay) < 0) {
            reminderDate = LocalDateTime.fromDateFields(currentDate).plusDays(1).toDate();
        }

        return reminderDate;
    }

    public Date getFirstBillPayReminderDate(CustomerBillAccount customerBillAccount, Date currentDate) {
        if (Objects.isNull(customerBillAccount.getDueDate())) {
            return null;
        }

        Date plannedFirstReminderDate = LocalDateTime.fromDateFields(customerBillAccount.getDueDate()).minusDays(Objects.nonNull(billReminderConfiguration.getDaysForFirstBillPayReminder()) ? billReminderConfiguration.getDaysForFirstBillPayReminder() : 0).toDate();
        Date firstReminderDateLastDay = LocalDateTime.fromDateFields(customerBillAccount.getDueDate()).minusDays(Objects.nonNull(billReminderConfiguration.getDaysForSecondBillPayReminder()) ? billReminderConfiguration.getDaysForSecondBillPayReminder() + 1 : 0).toDate();

        return getDate(currentDate, plannedFirstReminderDate, firstReminderDateLastDay);

    }

    public Date getSecondBillPayReminderDate(CustomerBillAccount customerBillAccount, Date currentDate) {
        if (Objects.isNull(customerBillAccount.getDueDate())) {
            return null;
        }

        Date plannedSecondReminderDate = LocalDateTime.fromDateFields((customerBillAccount.getDueDate())).minusDays(Objects.nonNull(billReminderConfiguration.getDaysForSecondBillPayReminder()) ? billReminderConfiguration.getDaysForSecondBillPayReminder() : 0).toDate();
        Date secondReminderDateLastDay = LocalDateTime.fromDateFields(customerBillAccount.getDueDate()).toDate();

        return getDate(currentDate, plannedSecondReminderDate, secondReminderDateLastDay);

    }

    public Boolean isEmailCommunicationEnabled(MessagingEvent messagingEvent) {
        switch (messagingEvent) {
            case BILL_PAY_FIRST_REMINDER:
                return billReminderConfiguration.isBillPayEmailFirstReminderEnabled();
            case BILL_PAY_SECOND_REMINDER:
                return billReminderConfiguration.isBillPayEmailSecondReminderEnabled();
            case BILL_PAY_REMINDER_ON_DUE_DATE:
                return billReminderConfiguration.isBillPayEmailReminderOnDueDateEnabled();
            case BILL_PAY_NUDGE:
                return billReminderConfiguration.isBillPayEmailNudgeEnabled();
            default:
                return false;
        }
    }

    public String getBillPayReminderEmailActionButton(CustomerBillAccount customerBillAccount) {
        if (Objects.isNull(customerBillAccount) || Objects.isNull(customerBillAccount.getBiller())) {
            return null;
        }
        Biller biller = customerBillAccount.getBiller();
        String queryProcessorBillerId = getQueryProcessorBillerId(biller);
        if (StringUtils.isEmpty(queryProcessorBillerId)) {
            queryProcessorBillerId = biller.getProcessorBillerId();
        }

        String deeplink = billReminderConfiguration.getEmailReminderOnelinkBaseUrl() + WPSConstants.Notification.SHOW_BILLER_ACTION
                + "&code=" + queryProcessorBillerId
                + "&billerId=" + biller.getBillerId()
                + "&accountNumber=" + customerBillAccount.getAccountNumber();

        if (StringUtils.isNotEmpty(customerBillAccount.getAlias())) {
            deeplink = deeplink + "&accountAlias=" + customerBillAccount.getAlias();
        }

        return deeplink;
    }

    public boolean isNotificationContentSubcategoryForDueToday(NotificationContentSubcategory notificationContentSubcategory) {
        return notificationContentSubcategory == NotificationContentSubcategory.DUE_TODAY_WITHOUT_ALIAS
            || notificationContentSubcategory == NotificationContentSubcategory.DUE_TODAY_WITH_ALIAS;
    }

    public boolean isNotificationContentSubcategoryForDueSoon(NotificationContentSubcategory notificationContentSubcategory) {
        return notificationContentSubcategory == NotificationContentSubcategory.DUE_SOON_WITHOUT_ALIAS
            || notificationContentSubcategory == NotificationContentSubcategory.DUE_SOON_WITH_ALIAS;
    }

    public boolean isNotificationContentSubcategoryForArcusDate(NotificationContentSubcategory notificationContentSubcategory) {
        return notificationContentSubcategory == NotificationContentSubcategory.ARCUS_DATE_WITHOUT_ALIAS
            || notificationContentSubcategory == NotificationContentSubcategory.ARCUS_DATE_WITH_ALIAS;
    }

    private boolean isBillerWithMultipleValidity(NotificationContentDO notificationContentDO) {
        return notificationContentDO.getIdentifierType() == NotificationContentIdentifierType.BILLER_ID && notificationContentDO.getIdentifier().equals(NotificationContentIdentifierType.TELCEL.getBillerId());
    }

    public void setNotificationContentDetails(NotificationContentDO notificationContentDO, NotificationContentDTO notificationContentDTO) throws ReminderServiceException {
        String title = notificationContentDO.getTitle();
        String message = notificationContentDO.getMessage();

        //Set placeholder values for title
        if (title.contains(NotificationPlaceholderConstants.BILLER)){
            title = title.replace(NotificationPlaceholderConstants.BILLER, notificationContentDTO.getBillerName());
        }

        if (title.contains(NotificationPlaceholderConstants.PRODUCT)){
            title = title.replace(NotificationPlaceholderConstants.PRODUCT, notificationContentDTO.getProduct());
        }

        if (title.contains(NotificationPlaceholderConstants.LAST_PAID_AMOUNT) && notificationContentDTO.getLastPaidAmount() != null){
            title = title.replace(NotificationPlaceholderConstants.LAST_PAID_AMOUNT, String.format("%.2f", notificationContentDTO.getLastPaidAmount()));
        }

        //Set placeholder values for message
        if (message.contains(NotificationPlaceholderConstants.AMOUNT) && notificationContentDTO.getAmount() != null){
            message = message.replace(NotificationPlaceholderConstants.AMOUNT, String.format("%.2f", notificationContentDTO.getAmount()));
        }

        if (message.contains(NotificationPlaceholderConstants.BILLER)){
            message = message.replace(NotificationPlaceholderConstants.BILLER, notificationContentDTO.getBillerName());
        }

        if (message.contains(NotificationPlaceholderConstants.ALIAS)){
            message = message.replace(NotificationPlaceholderConstants.ALIAS, notificationContentDTO.getAlias());
        }

        if (message.contains(NotificationPlaceholderConstants.EXPIRY_DATE)){
            message = message.replace(NotificationPlaceholderConstants.EXPIRY_DATE, notificationContentDTO.getFormattedDueDate());
        }

        if (message.contains(NotificationPlaceholderConstants.VALIDITY)){
            message = message.replace(NotificationPlaceholderConstants.VALIDITY, notificationContentDTO.getValidity());
        }

        if (isBillerWithMultipleValidity(notificationContentDO)) {
            if (message.contains(NotificationPlaceholderConstants.ITEM_DESCRIPTION)) {
                if (WPSDateUtils.getDaysBetween(notificationContentDTO.getDueDate(), new Date()) != 0 && WPSDateUtils.getDaysBetween(notificationContentDTO.getDueDate(), new Date()) <= WPSConstants.Bills.validityThresholdInDays) {
                    message = message.replace(NotificationPlaceholderConstants.ITEM_DESCRIPTION, notificationContentDTO.getValidity());
                } else {
                    message = message.replace(NotificationPlaceholderConstants.ITEM_DESCRIPTION, notificationContentDTO.getItemDescription());
                }
            }
        }
        else {
            if (message.contains(NotificationPlaceholderConstants.ITEM_DESCRIPTION)){
                message = message.replace(NotificationPlaceholderConstants.ITEM_DESCRIPTION, notificationContentDTO.getItemDescription());
            }
        }

        if (message.contains(NotificationPlaceholderConstants.LAST_PAID_DATE)){
            message = message.replace(NotificationPlaceholderConstants.LAST_PAID_DATE, notificationContentDTO.getLastPaidDate());
        }

        if (message.contains(NotificationPlaceholderConstants.LAST_PAID_AMOUNT) && notificationContentDTO.getLastPaidAmount() != null){
            message = message.replace(NotificationPlaceholderConstants.LAST_PAID_AMOUNT, String.format("%.2f", notificationContentDTO.getLastPaidAmount()));
        }

        boolean doesFinalMessageContainsPlaceholder = message.contains("{") || message.contains("}");

        boolean doesFinalTitleContainsPlaceholder = title.contains("{") || title.contains("}");

        if (doesFinalMessageContainsPlaceholder) {
            log.error("Final message should not contain a placeholder. message: {}", message);
            throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_SET_CONTENT_DETAILS_FAILED, String.format("Message contains a placeholder: {%s}", message));
        }

        if (doesFinalTitleContainsPlaceholder) {
            log.error("Final title should not contain a placeholder. title: {}", title);
            throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_SET_CONTENT_DETAILS_FAILED, String.format("Title contains a placeholder: {%s}", title));
        }

        notificationContentDTO.setMessage(message);
        notificationContentDTO.setTitle(title);
    }

    public List<NotificationContentDO> filterAndSortNotificationContentDOList(List<NotificationContentDO> notificationContentDOS) {
        if (notificationContentDOS.stream().anyMatch(nc -> isNotificationContentTypeBillerId(nc.getIdentifierType()))) {
            notificationContentDOS = notificationContentDOS.stream().filter(nc -> isNotificationContentTypeBillerId(nc.getIdentifierType())).collect(Collectors.toList());
        }
        notificationContentDOS.sort(Comparator.comparing(NotificationContentDO::getNotificationDaysCount,
            Comparator.nullsFirst(Comparator.reverseOrder())));
        return notificationContentDOS;
    }

    public List<NotificationContentDO> getFilteredNotificationContentDOS(List<NotificationContentDO> notificationContentDOS, NotificationContentDTO notificationContentDTO) {
        List<NotificationContentDO> filteredNotificationContentDOs;
        if (StringUtil.isNullOrEmpty(notificationContentDTO.getAlias())) {
            // Filter reminders with no alias
            filteredNotificationContentDOs = notificationContentDOS.stream()
                .filter(nc -> NotificationContentSubcategory.getNotificationContentSubcategoryWithoutAlias().contains(nc.getSubcategory()))
                .collect(Collectors.toList());
        } else {
            filteredNotificationContentDOs = notificationContentDOS.stream()
                .filter(nc -> NotificationContentSubcategory.getNotificationContentSubcategoryWithAlias().contains(nc.getSubcategory()))
                .collect(Collectors.toList());
        }
        return filteredNotificationContentDOs;
    }

    private Optional<String> getParentProcessorBillerId(Biller biller) {
        if (Objects.nonNull(biller.getParentBiller())) {
            return Optional.of(biller.getParentBiller().getProcessorBillerId());
        }
        return Optional.empty();
    }

    public String getQueryProcessorBillerId(Biller biller) {
        Optional<String> parentProcessorBillerId = getParentProcessorBillerId(biller);
        if (Objects.nonNull(biller.getProductDisplayName()) || parentProcessorBillerId.isEmpty()) {
            return biller.getProcessorBillerId();
        }
        return parentProcessorBillerId.get();
    }

    public String getBillPayReminderDeeplink(CustomerBillAccount customerBillAccount) {
        if (Objects.isNull(customerBillAccount) || Objects.isNull(customerBillAccount.getBiller())) {
            return null;
        }
        Biller biller = customerBillAccount.getBiller();
        String queryProcessorBillerId = getQueryProcessorBillerId(biller);
        if (StringUtils.isEmpty(queryProcessorBillerId)) {
            queryProcessorBillerId = biller.getProcessorBillerId();
        }

        String deeplink = "cashi://deeplink?action=" + WPSConstants.Notification.SHOW_BILLER_ACTION
                + "&code=" + queryProcessorBillerId
                + "&billerId=" + biller.getProcessorBillerId()
                + "&accountNumber=" + customerBillAccount.getAccountNumber();

        if (StringUtils.isNotEmpty(customerBillAccount.getAlias())) {
            deeplink = deeplink + "accountAlias=" + customerBillAccount.getAlias();
        }

        return deeplink;
    }

    public Date getBillPayReminderDateForDueSoon(Date dueDate, Date currentDate, int daysThreshold) {
        LocalDate dueLocalDate = dueDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate currentLocalDate = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        if (ChronoUnit.DAYS.between(currentLocalDate, dueLocalDate) > daysThreshold) {
            return Date.from(dueLocalDate.minusDays(daysThreshold).atStartOfDay(ZoneId.systemDefault()).toInstant());
        } else {
            return Date.from(currentLocalDate.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant());
        }
    }

    public boolean isNotificationContentTypeBillerId(NotificationContentIdentifierType notificationContentIdentifierType) {
        return notificationContentIdentifierType == NotificationContentIdentifierType.BILLER_ID;
    }

    public static SimpleDateFormat getNotificationContentNewDateFormat() {
        return new SimpleDateFormat("dd/MM/yyyy");
    }

    public Date getReminderDateBasedOnSubcategory(NotificationContentDO notificationContentDO, Date dueDate, Date currentDate) throws ReminderServiceException {
        Date reminderDate;
        if (isNotificationContentSubcategoryForArcusDate(notificationContentDO.getSubcategory())) {
            reminderDate = new Date();
        }
        else if (isNotificationContentSubcategoryForDueSoon(notificationContentDO.getSubcategory())) {
            reminderDate = getBillPayReminderDateForDueSoon(dueDate, currentDate, notificationContentDO.getNotificationDaysCount());
        }
        else if (isNotificationContentSubcategoryForDueToday(notificationContentDO.getSubcategory())) {
            reminderDate = dueDate;
        }
        else {
            log.info(String.format("Notification Content subcategory : {%s} is invalid.", notificationContentDO.getSubcategory()));
            throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_SUBCATEGORY_INVALID, String.format("Notification Content subcategory : {%s} is invalid.", notificationContentDO.getSubcategory()));
        }
        return reminderDate;
    }

    public int getLastDayOfMonth(LocalDate date) {
        return date.with(TemporalAdjusters.lastDayOfMonth()).getDayOfMonth();
    }

    public Date getTopUpExpiryDate(BillDetail billDetail, Date currentDate) {
        Date expiryDate = null;
        if (Objects.isNull(billDetail)) {
            return expiryDate;
        }
        if (billDetail.getDuration() != 0 && billDetail.getDurationUnit() != null) {
            String durationUnit = billDetail.getDurationUnit().name();
            Integer duration = billDetail.getDuration();
            if (durationUnit.equalsIgnoreCase("DAY")) {
                expiryDate = DateUtils.addDays(currentDate, duration);
            } else if (durationUnit.equalsIgnoreCase("MONTH")) {
                expiryDate = DateUtils.addMonths(currentDate, duration);
            } else if (durationUnit.equalsIgnoreCase("YEAR")) {
                expiryDate = DateUtils.addYears(currentDate, duration);
            }
        }
        return expiryDate;
    }

    public LocalDate getNextDateOfNudge(LocalDate nudgeDate, List<Integer> daysForBillPaymentNudgeList) {
        LocalDate nextMonthDate = nudgeDate.plusMonths(1);
        int nudgeDayOfMonth = nudgeDate.getDayOfMonth();
        if (!org.springframework.util.CollectionUtils.isEmpty(daysForBillPaymentNudgeList)) {
            if (!daysForBillPaymentNudgeList.contains(nudgeDayOfMonth)){
                Optional<Integer> nudgeDayFromConfig = daysForBillPaymentNudgeList.stream().filter(days -> days > nudgeDate.getDayOfMonth()).findFirst();
                if (nudgeDayFromConfig.isPresent())
                    nudgeDayOfMonth = nudgeDayFromConfig.get();
            }
            int lastDayOfMonth = getLastDayOfMonth(nextMonthDate);
            if (nextMonthDate.getMonth() == Month.FEBRUARY && nudgeDayOfMonth > lastDayOfMonth) {
                nudgeDayOfMonth = lastDayOfMonth;
            }
        }

        return nextMonthDate.withDayOfMonth(nudgeDayOfMonth);
    }

    public ReminderPayloadDTO getDeleteReminderPayload(CustomerBillAccount customerBillAccount) {
        if (Objects.isNull(customerBillAccount)) {
            return null;
        }

        return ReminderPayloadDTO.builder()
            .clientRequestId(customerBillAccount.getCustomerBillAccountId())
            .category(ReminderCategoryType.BILL_PAY_REMINDER)
            .reminderPayloadType(NaasGenericPayloadType.REMINDER_REMOVE)
            .build();
    }


    public LocalDate getFirstDateOfNudge(LocalDate currentDate, List<Integer> daysForBillPaymentNudgeList, CustomerBillAccount customerBillAccount) {
        int nudgeDayOfMonth = 0;

        LocalDate firstDateOfNudge = null;
        if (!org.springframework.util.CollectionUtils.isEmpty(daysForBillPaymentNudgeList)) {
            int currentDay = currentDate.getDayOfMonth();
            for (int i = 0; i < daysForBillPaymentNudgeList.size(); i++) {
                //Mid of month
                if (i != daysForBillPaymentNudgeList.size() - 1) {
                    if (currentDay >= daysForBillPaymentNudgeList.get(i) && currentDay <= daysForBillPaymentNudgeList.get(i + 1) - 1) {
                        nudgeDayOfMonth = daysForBillPaymentNudgeList.get(i);
                        firstDateOfNudge = currentDate.plusMonths(1).withDayOfMonth(nudgeDayOfMonth); // 15 - 29
                        customerBillAccount.setNudgeBucket("B".concat(Integer.toString(i + 1)));
                        break;
                    }
                } else { //Last Day of Month
                    int lastDayOfMonth = getLastDayOfMonth(currentDate);
                    nudgeDayOfMonth = daysForBillPaymentNudgeList.get(i);
                    if (currentDay >= nudgeDayOfMonth || currentDate.equals(LocalDate.now().with(TemporalAdjusters.lastDayOfMonth()))) {
                        LocalDate nextMonthDate = currentDate.plusMonths(1);
                        lastDayOfMonth = getLastDayOfMonth(nextMonthDate);
                        if (nextMonthDate.getMonth() == Month.FEBRUARY && nudgeDayOfMonth > lastDayOfMonth) {
                            nudgeDayOfMonth = lastDayOfMonth;
                        }
                        firstDateOfNudge = currentDate.plusMonths(1).withDayOfMonth(nudgeDayOfMonth);
                        customerBillAccount.setNudgeBucket("B".concat(Integer.toString(i + 1)));
                    } else {
                        if (currentDate.getMonth() == Month.FEBRUARY && nudgeDayOfMonth > lastDayOfMonth) {
                            nudgeDayOfMonth = lastDayOfMonth;
                        }
                        firstDateOfNudge = currentDate.withDayOfMonth(nudgeDayOfMonth);
                        customerBillAccount.setNudgeBucket("B".concat(Integer.toString(i + 1)));
                    }
                }
            }
        }
        return firstDateOfNudge;
    }

    private UUID getCorrelationId() {
        return UUID.fromString(MDC.get(WPSConstants.Headers.CORRELATION_ID));
    }
}
