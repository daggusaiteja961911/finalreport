package com.walmart.international.wallet.payment.core.event.listener;

import com.walmart.international.ewallet.services.events.config.Listener;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.event.payload.PayBillInitEventPayload;
import com.walmart.international.wallet.payment.core.service.BillPaymentCoreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

@Component
@Slf4j
public class CancelBillPaymentInitiatedListener {

    @Autowired
    BillPaymentCoreService billPaymentCoreService;

    @Transactional
    @Listener(types = {WPSConstants.Event.CANCEL_PAY_BILL_INIT})
    public void handleEvent(PayBillInitEventPayload payBillInitEventPayload) {
        if (Objects.isNull(payBillInitEventPayload)) {
            log.error("Failed to process PAY_BILL_INIT event as payload is null");
            return;
        }
        billPaymentCoreService.processCancelBillPaymentInitEvent(payBillInitEventPayload);
    }

}


