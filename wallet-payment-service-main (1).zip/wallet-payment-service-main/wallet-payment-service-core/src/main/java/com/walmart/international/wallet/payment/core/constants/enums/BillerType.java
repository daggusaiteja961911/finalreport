package com.walmart.international.wallet.payment.core.constants.enums;

public enum BillerType {
    POSTPAID, PREPAID, OTHER
}
