package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

/**
 *  Previously named as RegaliiConfiguration
 */
@Configuration(configName = "arcus-config", externalFileName = "arcus_props.properties")
public interface ArcusConfiguration extends WebClientCCMConfigs {

    @Property(propertyName = "arcus.service.baseUrl")
    String getBaseUrl();

    @Property(propertyName = "arcus.auth.key.v2.enabled")
    boolean isArcusAuthV2Enabled();

    @Property(propertyName = "arcus.auth.api.key.v1")
    String getArcusApiKeyV1();

    @Property(propertyName = "arcus.auth.secret.key.v1")
    String getArcusSecretKeyV1();

    @Property(propertyName = "arcus.auth.api.key.v2")
    String getArcusApiKeyV2();

    @Property(propertyName = "arcus.auth.secret.key.v2")
    String getArcusSecretKeyV2();
}
