package com.walmart.international.wallet.payment.core.adapter.customer;

import com.walmart.international.digiwallet.customer.api.dto.request.paymentInstrument.UpdateCardLastUsedDateRequest;
import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;

import java.util.UUID;

public interface ICustomerServiceClient {

    CustomerResponse getCustomerDetailsById(UUID customerAccountId) throws ApplicationException;

    WalletResponse getPaymentInstruments(UUID customerAccountId) throws ApplicationException;

    void updateCardLastUsedDate(UpdateCardLastUsedDateRequest updateCardLastUsedDateRequest) throws ApplicationException;
}
