package com.walmart.international.wallet.payment.core.adapter.kafka.request.refund;

import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.CardDetails;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.ErrorDetails;
import lombok.Data;

import java.util.List;

@Data
public class ReverseKafkaResponseEventDetails {
    private String requestId;
    private String orderId;
    private String banner;
    private String paymentGateway;
    private String profileId;
    private String orderChannel;
    private String paymentBrokerParentId;
    private List<CardDetails> cards;
    private List<RefundKafkaResponseDetails> refunds;
    private List<ErrorDetails> validationErrors;
}
