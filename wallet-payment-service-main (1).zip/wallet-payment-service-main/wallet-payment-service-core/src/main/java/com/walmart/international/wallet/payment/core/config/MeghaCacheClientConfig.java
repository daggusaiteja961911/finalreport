package com.walmart.international.wallet.payment.core.config;

import com.walmart.international.services.digitalwallet.cache.config.MeghaCacheConfig;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.tunr.utils.client.ServiceConfigClientFactory;
import net.spy.memcached.WmClient;
import net.spy.memcached.WmConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.util.Map;

@Configuration
public class MeghaCacheClientConfig {

    private static final Logger log = LoggerFactory.getLogger(MeghaCacheClientConfig.class);

    @ManagedConfiguration
    private MeghaCacheConfig meghaCacheConfig;

    @Bean(destroyMethod = "shutdown")
    public WmClient wmClient() throws IOException {
        if (this.meghaCacheConfig == null) {
            log.warn("Setting meghacache-config via service config client factory!");
            this.meghaCacheConfig = (MeghaCacheConfig) ServiceConfigClientFactory.getInstance().getServiceConfigVersionCache().getResolvedConfiguration("meghacache-config", MeghaCacheConfig.class, (Map) null);
        }

        WmConnectionFactory wmConnectionFactory = new WmConnectionFactory(this.meghaCacheConfig.getTimeout(),
            this.meghaCacheConfig.getTimeoutExceptionThreshold(), this.meghaCacheConfig.getMaxValueBytes(), false) {
            public long getOpQueueMaxBlockTime() {
                return 1000L;
            }
        };
        return new WmClient(wmConnectionFactory, this.meghaCacheConfig.getMcRouterPort(), this.meghaCacheConfig.getHostNames());
    }

}
