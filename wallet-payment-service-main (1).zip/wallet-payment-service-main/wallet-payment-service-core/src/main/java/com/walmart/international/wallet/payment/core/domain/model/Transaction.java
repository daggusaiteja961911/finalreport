package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {
    private Customer customer;
    private UUID transactionId;
    private TransactionType transactionType;
    private TransactionType parentTransactionType;
    private String transactionReferenceId;
    private TransactionStateEnum state;
    private String cashiOrderId;
    private String clientReqId;
    private String deviceId;
    private Amount amountRequested;
    private Amount amountFulfilled;
    private Amount reversalAmount;
    private String failureCode;
    private String failureDescription;
    private List<AmountBreakup> amountBreakup;
    private String pollingInterval;
    private String abortReason;
    private LocalDateTime createDate;
    private LocalDateTime updateDate;
    private LocalDateTime lastEventDate;
    private Transaction parentTransaction;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AmountBreakup {
        String name;
        String value;
        String label;
    }
}
