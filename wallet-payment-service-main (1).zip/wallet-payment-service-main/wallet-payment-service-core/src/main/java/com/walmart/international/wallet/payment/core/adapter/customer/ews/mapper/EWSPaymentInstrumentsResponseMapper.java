package com.walmart.international.wallet.payment.core.adapter.customer.ews.mapper;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentSubType;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.EWSPaymentInstrumentDTO;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.EWSPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Mapper(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = {LocalDateTime.class, ChronoUnit.class})
@Component
public interface EWSPaymentInstrumentsResponseMapper {

    EWSPaymentInstrumentsResponseMapper INSTANCE = Mappers.getMapper(EWSPaymentInstrumentsResponseMapper.class);

    default WalletResponse mapToWalletResponse(EWSPaymentInstrumentsResponse paymentInstrumentsResponse) {
        return WalletResponse.builder().paymentInstruments(mapPaymentPreferenceDTOsToPaymentInstrumentList(paymentInstrumentsResponse.getPaymentInstrumentDTOList())).build();
    }

    default List<WalletResponse.PaymentInstrument> mapPaymentPreferenceDTOsToPaymentInstrumentList(List<EWSPaymentInstrumentDTO> paymentPreferenceDTOS) {
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = null;
        if (Objects.nonNull(paymentPreferenceDTOS)) {
            paymentInstrumentList = new ArrayList<>();
            for (EWSPaymentInstrumentDTO paymentInstrumentDTO : paymentPreferenceDTOS) {
                WalletResponse.PaymentInstrument paymentInstrument = mapPaymentInstrument(paymentInstrumentDTO);
                paymentInstrument.setExpirationDate(mapExpirationDate(paymentInstrumentDTO));
                paymentInstrument.setIsExpired(mapIsExpired(paymentInstrument.getExpirationDate()));
                paymentInstrumentList.add(paymentInstrument);
            }
        }
        return paymentInstrumentList;
    }

    static Date mapExpirationDate(EWSPaymentInstrumentDTO paymentPreferenceDTOS) {
        if (StringUtils.isNotEmpty(paymentPreferenceDTOS.getExpirationYear()) && StringUtils.isNotEmpty(paymentPreferenceDTOS.getExpirationMonth())) {
            DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                    .appendPattern("MM/yy")
                    .parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
                    .toFormatter();

            String expirationMonth = paymentPreferenceDTOS.getExpirationMonth();
            String expirationYear = paymentPreferenceDTOS.getExpirationYear();

            if (StringUtils.length(expirationMonth) < 2) {
                expirationMonth = "0" + expirationMonth;
            }

            try {
                LocalDate expiryDate = LocalDate.parse(expirationMonth + "/" + expirationYear, formatter);
                expiryDate = expiryDate.withDayOfMonth(expiryDate.getMonth().length(expiryDate.isLeapYear()));
                return Date.from(expiryDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
            } catch (DateTimeParseException dtpe) {
                String msg = String.format("Unable to parse expiration month/year: " + expirationMonth + "/" + expirationYear);
                throw new BusinessValidationException(ErrorConstants.CustomerClientForEWS.EXPIRY_DETAILS_PARSE_EXCEPTION, msg);
            }
        }
        return null;
    }

    default Boolean mapIsExpired(Date expirationDate) {
        return Objects.isNull(expirationDate) ? null : ZonedDateTime.ofInstant(expirationDate.toInstant(), ZoneId.systemDefault()).isBefore(ZonedDateTime.now());
    }

    @Mapping(target = "paymentInstrumentId", source = "id", qualifiedByName = "uuidToString")
    @Mapping(target = "paymentInstrumentType", source = "cardType", qualifiedByName = "mapPaymentType")
    @Mapping(target = "paymentInstrumentSubType", source = "ewsPaymentInstrumentDTO", qualifiedByName = "mapPaymentSubType")
    @Mapping(target = "adapterMetadata.piHash", source = "pihash")
    @Mapping(target = "adapterMetadata.accountNumber", source = "giftCardAccount")
    @Mapping(target = "adapterMetadata.tokenId", source = "paymentBrokerTokenId")
    @Mapping(target = "adapterMetadata.walletId", source = "walletId")
    @Mapping(target = "billingAddress.streetExtNum", source = "billingAddress.exteriorNum")
    @Mapping(target = "billingAddress.streetIntNum", source = "billingAddress.interiorNum")
    @Mapping(target = "billingAddress.country", source = "billingAddress.countryCode")
    @Mapping(target = "isFavourite", source = "favoriteCard")
    @Mapping(target = "metadata.cardholderName", source = "cardHolderName")
    @Mapping(target = "metadata.cardNumber", source = "maskedCardNumber")
    @Mapping(target = "metadata.last4Digits", source = "last4Digits")
    @Mapping(target = "metadata.brand", source = "brand")
    @Mapping(target = "metadata.cvvVerified", source = "cvvVerified")
    @Mapping(target = "metadata.cvvRequired", source = "cvvRequired")
    @Mapping(target = "metadata.favoriteCard", source = "favoriteCard")
    @Mapping(target = "metadata.aliasName", source = "nickName")
    WalletResponse.PaymentInstrument mapPaymentInstrument(EWSPaymentInstrumentDTO ewsPaymentInstrumentDTO) throws BusinessValidationException;

    @Named("uuidToString")
    static String uuidToString(UUID uuid) {
        return uuid.toString();
    }

    @Named("mapPaymentType")
    default PaymentInstrumentType mapPaymentType(String paymentType) {
        if (paymentType != null) {
            switch (paymentType.toUpperCase()) {
                case "DEBIT":
                case "CREDIT":
                case "CARD":
                    return PaymentInstrumentType.CARD;
                case "GIFTCARD":
                case "CORPGIFTCARD":
                    return PaymentInstrumentType.GIFTCARD;
                default:
                    return null;
            }
        }
        return null;
    }

    @Named("mapPaymentSubType")
    default PaymentInstrumentSubType mapPaymentSubType(EWSPaymentInstrumentDTO ewsPaymentInstrumentDTO) {
        if (StringUtils.isNotEmpty(ewsPaymentInstrumentDTO.getCardType())) {
            String paymentType = ewsPaymentInstrumentDTO.getCardType().toUpperCase();
            switch (paymentType) {
                case "DEBIT":
                    return PaymentInstrumentSubType.DEBIT_CARD;
                case "CREDIT":
                    return PaymentInstrumentSubType.CREDIT_CARD;
                case "GIFTCARD":
                    return PaymentInstrumentSubType.CASHI_WALLET;
                case "CORPGIFTCARD": {
                    if (Objects.nonNull(ewsPaymentInstrumentDTO.getCompany())) {
                        if (ewsPaymentInstrumentDTO.getCompany().getCompanyName().equals(WPSConstants.PaymentInstrument.ASSOCIATE_FOOD_VOUCHER_COMPANY_NAME)) {
                            return PaymentInstrumentSubType.ASSOCIATE_FOOD_VOUCHER;
                        }
                    }
                    return PaymentInstrumentSubType.CORP_CARD;
                }
                default:
                    return null;
            }
        }
        return null;
    }

}
