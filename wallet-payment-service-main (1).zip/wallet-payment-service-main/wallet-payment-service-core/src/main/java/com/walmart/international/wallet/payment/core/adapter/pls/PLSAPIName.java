package com.walmart.international.wallet.payment.core.adapter.pls;

import com.walmart.international.services.digitalwallet.httpclient.wallet.constants.ApiName;

public enum PLSAPIName implements ApiName {
    VALIDATE_AML;

    @Override
    public String getApiName() {
        return this.name();
    }
}
