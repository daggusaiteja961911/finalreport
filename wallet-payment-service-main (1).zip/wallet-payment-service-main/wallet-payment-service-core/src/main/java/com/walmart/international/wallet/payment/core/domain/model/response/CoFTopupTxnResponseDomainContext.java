package com.walmart.international.wallet.payment.core.domain.model.response;

import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class CoFTopupTxnResponseDomainContext extends TransactionResponseDomainContext {

    private CoFTopupTransactionDO coFTopupTransactionDO;

    public CoFTopUpTransaction getTransaction() {
        return (CoFTopUpTransaction) super.transaction;
    }

    public void setTransaction(CoFTopUpTransaction cofTopUpTransaction) {
        super.transaction = cofTopUpTransaction;
    }
}
