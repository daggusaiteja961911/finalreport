package com.walmart.international.wallet.payment.core.adapter.cohort;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.commons.logging.slf4j.LoggerWrapperFactory;
import com.walmart.international.digiwallet.service.strati.telemetry.service.CashiTelemetryMetrics;
import com.walmart.international.digiwallet.service.strati.telemetry.service.constants.CashiTelemetry;
import com.walmart.international.digiwallet.service.strati.telemetry.service.constants.CashiTelemetryMetricName;
import com.walmart.international.digiwallet.service.strati.telemetry.util.MetricData;
import com.walmart.international.digiwallet.service.strati.telemetry.util.NGCashiServiceResponse;
import com.walmart.international.wallet.payment.core.adapter.cohort.response.CustomerCohort;
import net.spy.memcached.WmClient;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CustomerCohortAdapter {

    private static final Logger logger = LoggerWrapperFactory.getLogger(CustomerCohortAdapter.class);

    @Autowired
    private WmClient wmClient;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    private CashiTelemetryMetrics cshTelMetrics;

    public CustomerCohort getCustomerCohort(UUID customerAccountId) {
        CustomerCohort customerCohort = new CustomerCohort();
        try {
            Object wmClientObject = NGCashiServiceResponse.executeAndGetResponse(() -> wmClient.get(customerAccountId.toString()),
                    cshTelMetrics,
                    MetricData.builder().levelOne(CashiTelemetry.Level6.MEGHACACHE).levelTwo(CashiTelemetry.Level2.GET_CUSTOMER_COHORT)
                            .levelThree(CashiTelemetry.Level3.ALL).metricName(CashiTelemetryMetricName.CASHI_TRANSACTION).build());
            logger.info("CustomerCohort value read from MeghaCache for the account number : CustomerAccountId[{}], CustomerCohort[{}]", customerAccountId, wmClientObject);
            if (wmClientObject == null) {
                return null;
            }
            customerCohort = objectMapper.readValue(wmClientObject.toString(), CustomerCohort.class);
        } catch (Exception ex) {
            logger.error("Failed to read value from MeghaCache for the account number : CustomerAccountId[{}].", customerAccountId, ex);
        }
        return customerCohort;
    }
}
