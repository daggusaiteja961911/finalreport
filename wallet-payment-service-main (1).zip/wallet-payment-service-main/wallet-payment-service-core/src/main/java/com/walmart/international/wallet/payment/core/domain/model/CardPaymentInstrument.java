package com.walmart.international.wallet.payment.core.domain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Date;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CardPaymentInstrument extends PaymentInstrument {

    Metadata metadata;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
    )
    Date expirationDate;

    BillingAddress billingAddress;

    Boolean isExpired;

    String adapter;

    AdapterMetadata adapterMetadata;

    Boolean isFavourite;

    BinDetails binDetails;

    Date lastUsedDate;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BinDetails {
        String bin;
        String brandName;
        String bankName;
        String brandLogo;
        String bankLogo;
        String bankColor;
        String textColor;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BillingAddress {
        String street;
        String streetExtNum;
        String streetIntNum;
        String city;
        String colony;
        String postalCode;
        String stateCode;
        String country;
        String delegation;
        String type;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Metadata {
        String cardholderName;
        String cardNumber;
        String last4Digits;
        String brand;
        Boolean cvvVerified;
        Boolean cvvRequired;
        Boolean favoriteCard;
        String aliasName;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdapterMetadata {
        String tokenId;
        String walletId;
        String piHash;
        String accountNumber;

    }
}
