package com.walmart.international.wallet.payment.core.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentOrderDTO {
    private String tag;
    private String subTag;
    private List<String> excludedTags;
    private Integer priority;
}
