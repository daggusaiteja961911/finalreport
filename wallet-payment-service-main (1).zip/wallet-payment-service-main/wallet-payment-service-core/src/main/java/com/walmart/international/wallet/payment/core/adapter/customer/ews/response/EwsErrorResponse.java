package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EwsErrorResponse {
    private String code;
    private String description;
}