package com.walmart.international.wallet.payment.core.processor.coftopup;

import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentSubType;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.services.payment.core.dao.repository.CardTransactionRepository;
import com.walmart.international.services.payment.core.dao.repository.CoreTransactionRepository;
import com.walmart.international.services.payment.core.domain.SubTransactionStatus;
import com.walmart.international.services.payment.core.model.CardTransactionDO;
import com.walmart.international.services.payment.core.model.CoreTransactionDO;
import com.walmart.international.services.payment.core.model.SubTransactionDO;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class CoFTopupPreProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    private CardTransactionRepository cardTransactionRepository;

    @Autowired
    private CoreTransactionRepository coreTransactionRepository;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    @Autowired
    private WalletPaymentServiceUtil walletPaymentServiceUtil;

    private CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    private CoFTopupMapper coFTopupMapper = CoFTopupMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) {
        CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext = (CoFTopupTxnRequestDomainContext) wpsRequestDomainContext;
        CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;

        UUID transactionId = coFTopupTxnRequestDomainContext.getTransaction().getTransactionId();
        Optional<UUID> oCardSubTransactionId = coFTopupTxnRequestDomainContext.getTransaction().getCardSubTransactionId();
        CoFTopupTransactionDO coFTopupTransactionDO = null;
        if (Objects.nonNull(transactionId)) {   // transactionId should be non-null for ValidateCharge standard API
            Optional<CoFTopupTransactionDO> oCoFTopupTxnDO = coFTopupTransactionRepository.findById(transactionId);
            if (oCoFTopupTxnDO.isPresent()) {
                coFTopupTransactionDO = oCoFTopupTxnDO.get();
                mapTransactionDetailsToContext(coFTopupTransactionDO, coFTopupTxnRequestDomainContext.getTransaction());
                updateCoFTopupTxnStateFor3DSAck(coFTopupTransactionDO);
            }
        } else if (oCardSubTransactionId.isPresent()) {     // cardSubTransactionId should be non-null for ValidateCharge migration API
            coFTopupTransactionDO = mapTransactionDetailsToContext(oCardSubTransactionId.get(), coFTopupTxnRequestDomainContext.getTransaction());
            updateCoFTopupTxnStateFor3DSAck(coFTopupTransactionDO);
        }

        if (Objects.isNull(coFTopupTransactionDO)) {
            coFTopupTransactionDO = createCoFTopupTransactionInInitiatedState(coFTopupTxnRequestDomainContext);
        }

        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnRequestDomainContext.getTransaction();
        coFTopupMapper.updateCoFTopupTransactionFromCoFTopupTransactionDO(coFTopupTransactionDO, coFTopUpTransaction);
        coFTopupTxnResponseDomainContext.setCoFTopupTransactionDO(coFTopupTransactionDO);
        coFTopupTxnResponseDomainContext.setTransaction(coFTopUpTransaction);
        coFTopupTxnResponseDomainContext.setClientRequestId(coFTopupTxnRequestDomainContext.getClientRequestId());
        coFTopupTxnResponseDomainContext.setHeaders(coFTopupTxnRequestDomainContext.getHeaders());
        return true;
    }

    private CoFTopupTransactionDO mapTransactionDetailsToContext(UUID cardSubTransactionId, CoFTopUpTransaction coFTopUpTransaction) {
        Customer customer = coFTopUpTransaction.getCustomer();

        Optional<CardTransactionDO> optionalCardTransactionDO = cardTransactionRepository.findById(cardSubTransactionId);
        // TODO - to be updated to check for PAYMENT_3DS_PENDING after payment-core changes
        if (optionalCardTransactionDO.isEmpty() || !optionalCardTransactionDO.get().getStatus().equals(SubTransactionStatus.PAYMENT_3DS_PROCESSING)) {
            throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.INVALID_CARD_TXN_ID);
        }
        CoreTransactionDO coreTransactionDO = optionalCardTransactionDO.get().getCoreTransaction();
        UUID coFTopupTxnId = UUID.fromString(coreTransactionDO.getClientTransactionId().split("_")[0]);
        Optional<CoFTopupTransactionDO> optionalCoFTopupTransactionDO = coFTopupTransactionRepository.findById(coFTopupTxnId);
        if (optionalCoFTopupTransactionDO.isEmpty()) {
            throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.INVALID_COF_TOPUP_TXN_ID);
        }
        if (!optionalCoFTopupTransactionDO.get().getCustomerAccountId().equals(customer.getCustomerAccountId())) {
            throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.INVALID_CUSTOMER_TRANSACTION);
        }
        CoFTopupTransactionDO coFTopupTransactionDO = optionalCoFTopupTransactionDO.get();
        checkIfImplicitTopupTransaction(coFTopupTransactionDO);

        coFTopUpTransaction.setAmountRequested(Amount.builder()
                .value(coFTopupTransactionDO.getAmountRequested())
                .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(coFTopupTransactionDO.getCurrencyUnit().name()))
                .build());

        GiftCardTransaction giftCardLoadTransaction = GiftCardTransaction.builder()
                .amount(Amount.builder()
                        .value(coFTopupTransactionDO.getAmountRequested())
                        .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(coFTopupTransactionDO.getCurrencyUnit().name()))
                        .build())
                .giftCardTransactionType(GiftCardTransactionType.LOAD)
                .build();
        coFTopUpTransaction.setGiftCardLoadTransactionList(Collections.singletonList(giftCardLoadTransaction));

        CardPaymentTransaction cardPaymentTransaction = coFTopUpTransaction.getCardPaymentTransactionList().get(0);
        cardPaymentTransaction.setAmount(Amount.builder()
                        .value(optionalCardTransactionDO.get().getAmount())
                        .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(optionalCardTransactionDO.get().getCurrency().name()))
                        .build());
        cardPaymentTransaction.setCardPaymentInstrument(CardPaymentInstrument.builder()
                .adapterMetadata(CardPaymentInstrument.AdapterMetadata.builder()
                        .tokenId(optionalCardTransactionDO.get().getPaymentProviderInstrumentId())
                        .build())
                .build());

        CustomerResponse customerResponse = customerServiceClient.getCustomerDetailsById(customer.getCustomerAccountId());
        if (customerResponse == null) {
            throw new BusinessValidationException(ErrorConstants.CoFTopup.CUSTOMER_ACCOUNT_NOT_FOUND);
        }
        customerMapper.updateCustomerDataInContext(customerResponse, customer);
        setCardAndGiftCardPaymentInstrumentInContextFromCustomerResponse(cardPaymentTransaction, giftCardLoadTransaction, customerResponse);

        return coFTopupTransactionDO;
    }

    private void checkIfImplicitTopupTransaction(CoFTopupTransactionDO coFTopupTransactionDO) {
        if (Objects.nonNull(coFTopupTransactionDO.getParentTransactionType())) {
            log.error("Cannot process implicit CoF Topup transaction with transactionId:[{}}", coFTopupTransactionDO.getCoFTopupTransactionId());
            throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CANNOT_PROCESS_IMPLICIT_TOPUP);
        }
    }

    private void mapTransactionDetailsToContext(CoFTopupTransactionDO coFTopupTransactionDO, CoFTopUpTransaction coFTopUpTransaction) {
        if (!(coFTopupTransactionDO.getState().equals(TransactionStateEnum.PENDING)
                && coFTopupTransactionDO.getStateReason().equals(CoFTopupTxnStateReason.DEBIT_3DS_GENERATED))) {
            log.error("CoFTopup transaction with transactionId:[{}] not in valid state for 3DS processing", coFTopupTransactionDO.getCoFTopupTransactionId());
            throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.INVALID_COF_TOPUP_TXN_ID);
        }
        String clientTransactionId = String.join("_", String.valueOf(coFTopupTransactionDO.getCoFTopupTransactionId()), "1");
        CoreTransactionDO coreTransactionDO = coreTransactionRepository.findTopByClientTransactionIdOrderByCreateDateDesc(clientTransactionId);
        Optional<SubTransactionDO> optionalCardTransactionDO = coreTransactionDO.getCardSubTransaction();
        // TODO - to be updated to check for PAYMENT_3DS_PENDING after payment-core changes
        if (optionalCardTransactionDO.isEmpty() || !optionalCardTransactionDO.get().getStatus().equals(SubTransactionStatus.PAYMENT_3DS_PROCESSING)) {
            log.error("CardTransaction for CoFTopup transaction with transactionId:[{}] not in valid state for 3DS processing", coFTopupTransactionDO.getCoFTopupTransactionId());
            throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.INVALID_CARD_TXN_ID);
        }

        coFTopUpTransaction.setAmountRequested(Amount.builder()
                .value(coFTopupTransactionDO.getAmountRequested())
                .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(coFTopupTransactionDO.getCurrencyUnit().name()))
                .build());

        GiftCardTransaction giftCardLoadTransaction = GiftCardTransaction.builder()
                .amount(Amount.builder()
                        .value(coFTopupTransactionDO.getAmountRequested())
                        .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(coFTopupTransactionDO.getCurrencyUnit().name()))
                        .build())
                .giftCardTransactionType(GiftCardTransactionType.LOAD)
                .build();
        coFTopUpTransaction.setGiftCardLoadTransactionList(Collections.singletonList(giftCardLoadTransaction));

        CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                .cardSubTransaction(CardPaymentTransaction.CardSubTransaction.builder()
                        .id(optionalCardTransactionDO.get().getSubTransactionId())
                        .build())
                .amount(Amount.builder()
                        .value(optionalCardTransactionDO.get().getAmount())
                        .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(optionalCardTransactionDO.get().getCurrency().name()))
                        .build())
                .cardPaymentInstrument(CardPaymentInstrument.builder()
                        .adapterMetadata(CardPaymentInstrument.AdapterMetadata.builder()
                                .tokenId(optionalCardTransactionDO.get().getPaymentProviderInstrumentId())
                                .build())
                        .build())
                .build();
        coFTopUpTransaction.setCardPaymentTransactionList(Collections.singletonList(cardPaymentTransaction));

        Customer customer = coFTopUpTransaction.getCustomer();
        CustomerResponse customerResponse = customerServiceClient.getCustomerDetailsById(customer.getCustomerAccountId());
        if (customerResponse == null) {
            throw new BusinessValidationException(ErrorConstants.CoFTopup.CUSTOMER_ACCOUNT_NOT_FOUND);
        }
        customerMapper.updateCustomerDataInContext(customerResponse, customer);
        setCardAndGiftCardPaymentInstrumentInContextFromCustomerResponse(cardPaymentTransaction, giftCardLoadTransaction, customerResponse);
    }

    private void setCardAndGiftCardPaymentInstrumentInContextFromCustomerResponse(CardPaymentTransaction cardPaymentTransaction,
                                                                                  GiftCardTransaction giftCardLoadTransaction,
                                                                                  CustomerResponse customerResponse) {
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = customerResponse.getWalletAccountDTO().getWalletResponse().getPaymentInstruments();
        paymentInstrumentList.forEach(paymentInstrument -> {
            if (paymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.CARD)
                    && paymentInstrument.getAdapterMetadata().getTokenId().equals(cardPaymentTransaction.getCardPaymentInstrument().getAdapterMetadata().getTokenId())) {
                cardPaymentTransaction.setPaymentInstrumentId(UUID.fromString(paymentInstrument.getPaymentInstrumentId()));
                cardPaymentTransaction.setCardPaymentInstrument(customerMapper.mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument));
                cardPaymentTransaction.setProviderWalletId(paymentInstrument.getAdapterMetadata().getWalletId());
            }
            if (paymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.GIFTCARD)
                    && paymentInstrument.getPaymentInstrumentSubType().equals(PaymentInstrumentSubType.CASHI_WALLET)) {
                giftCardLoadTransaction.setPaymentInstrumentId(UUID.fromString(paymentInstrument.getPaymentInstrumentId()));
                giftCardLoadTransaction.setGiftCardPaymentInstrument(customerMapper.mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument));
            }
        });
    }

    private CoFTopupTransactionDO createCoFTopupTransactionInInitiatedState(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnRequestDomainContext.getTransaction();
        DeviceInformation deviceInformation = coFTopupTxnRequestDomainContext.getDeviceInfo();

        CoFTopupTransactionDO cofTopupTransactionDO = new CoFTopupTransactionDO();
        cofTopupTransactionDO.setAmountRequested(coFTopUpTransaction.getAmountRequested().getValue());
        cofTopupTransactionDO.setCurrencyUnit(CurrencyUnit.valueOf(coFTopUpTransaction.getAmountRequested().getCurrencyUnit().name()));
        cofTopupTransactionDO.setCustomerAccountId(coFTopUpTransaction.getCustomer().getCustomerAccountId());
        cofTopupTransactionDO.setState(TransactionStateEnum.INITIATED);
        cofTopupTransactionDO.setStateReason(CoFTopupTxnStateReason.VALIDATION_SUCCESS);
        cofTopupTransactionDO.setTxnReferenceId(coFTopUpTransaction.getTransactionReferenceId());
        cofTopupTransactionDO.setClientReqId(coFTopupTxnRequestDomainContext.getClientRequestId());
        cofTopupTransactionDO.setDeviceIpAddress(deviceInformation.getIp());
        cofTopupTransactionDO.setDeviceId(deviceInformation.getFingerPrint());
        if (Objects.nonNull(coFTopUpTransaction.getParentTransactionType())) {
            cofTopupTransactionDO.setParentTransactionType(com.walmart.international.wallet.payment.data.constant.enums.TransactionType.valueOf(coFTopUpTransaction.getParentTransactionType().name()));
        }
        cofTopupTransactionDO = coFTopupTransactionRepository.save(cofTopupTransactionDO);
        return cofTopupTransactionDO;
    }

    private void updateCoFTopupTxnStateFor3DSAck(CoFTopupTransactionDO coFTopupTransactionDO) {
        coFTopupTransactionDO.setState(TransactionStateEnum.PENDING);
        coFTopupTransactionDO.setStateReason(CoFTopupTxnStateReason.DEBIT_3DS_ACKNOWLEDGED);
        coFTopupTransactionRepository.save(coFTopupTransactionDO);
    }

}
