package com.walmart.international.wallet.payment.core.adapter.kafka.request.pb;

import lombok.Data;

@Data
public class PBChargeKafkaResponse {
    private String eventType;
    private ChargeEventDetails eventPayload;
}
