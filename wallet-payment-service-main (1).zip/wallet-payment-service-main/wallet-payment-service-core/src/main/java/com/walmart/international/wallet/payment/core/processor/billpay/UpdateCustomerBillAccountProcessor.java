package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@Component
@Slf4j
public class UpdateCustomerBillAccountProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    CustomerBillAccountRepository customerBillAccountRepository;

    CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws BusinessValidationException {

        BillRequestDomainContext billRequestDomainContext = (BillRequestDomainContext) wpsRequestDomainContext;
        BillResponseDomainContext billResponseDomainContext = (BillResponseDomainContext) wpsResponseDomainContext;

        CustomerBillAccount customerBillAccount = billRequestDomainContext.getCustomerBillAccount();

        CustomerBillAccountDO customerBillAccountDO = customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getCustomerBillAccountId());
        if (Objects.isNull(customerBillAccountDO)) {
                String msg = String.format(
                        " Record not found for customerBillAccountId[%s], customerAccountId[%s]",
                        customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getCustomerAccountId());
                throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_NOT_FOUND, msg);
            }

        customerBillAccountUpdateBusinessValidation(customerBillAccountDO, customerBillAccount);
        updateCustomerBillAccountDetails(customerBillAccountDO, customerBillAccount);

        billResponseDomainContext.setCustomerBillAccount(customerBillAccountMapper.customerBillAccountDOToCustomerBillAccount(customerBillAccountDO));
        return true;
    }

    private void customerBillAccountUpdateBusinessValidation(CustomerBillAccountDO customerBillAccountDO, CustomerBillAccount customerBillAccount) throws BusinessValidationException {
        log.info("Business Validation Process started for Customer Bill Account with customerBillAccountId: [{}] processorBillAccountId: [{}] processorBillerId: [{}] accountNumber: [{}]",
                customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getProcessorBillerId(), customerBillAccount.getAccountNumber());

        if (Objects.nonNull(customerBillAccount.getCustomerAccountId()) && !customerBillAccountDO.getCustomerAccountId().equals(customerBillAccount.getCustomerAccountId())) {
            String msg = String.format(
                    "Customer Account Id associated with customerBillAccountId[%s] doesn't match the Customer Account Id in request.",
                    customerBillAccount.getCustomerBillAccountId());
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_CUSTOMER_ACCOUNT_ID_MISMATCH, msg);
        }

        if (Objects.nonNull(customerBillAccount.getDueDate())) {
            Date updatedDueDate = customerBillAccount.getDueDate();
            Date currentDate = new Date();

            if (Objects.nonNull(customerBillAccountDO.getDueDate()) && DateUtils.isSameDay(customerBillAccountDO.getDueDate(), updatedDueDate)) {
                String msg = String.format("Due date to be updated [%s] is same as existing due date[%s]", updatedDueDate, customerBillAccountDO.getDueDate());
                throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.WPS_INVALID_DUE_DATE_ERROR_DUPLICATE, msg);
            }

            if (updatedDueDate.before(currentDate)) {
                String msg = String.format("Due date to be updated [%s] is past the current date[%s]", updatedDueDate, currentDate);
                throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.WPS_INVALID_DUE_DATE_ERROR_PAST_DATE, msg);
            }
        }

        if (Objects.nonNull(customerBillAccount.getAlias()) && customerBillAccountRepository.getCountByCustomerAccountIdAndBillerDO_BillerIdAndAlias(customerBillAccount.getCustomerAccountId(), customerBillAccount.getAlias(),
                customerBillAccountDO.getBillerDO().getBillerId()) > 0) {
            String msg = String.format("Account alias uniqueness constraint violated :customerBillAccountId[%s], customerId[%s].",
                    customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getCustomerAccountId());
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.ACCOUNT_ALIAS_UNIQUENESS_CONSTRAINT_VIOLATED, msg);
        }
    }

    private void updateCustomerBillAccountDetails(CustomerBillAccountDO customerBillAccountDO, CustomerBillAccount customerBillAccount) {
        log.info("Customer-Bill-Account record Updation Process started for customerBillAccountId: [{}] processorBillAccountId: [{}] processorBillerId: [{}] accountNumber: [{}]",
                customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getProcessorBillerId(), customerBillAccount.getAccountNumber());

        if (Objects.nonNull(customerBillAccount.getDueDate())) {
            Date updatedDueDate = customerBillAccount.getDueDate();
            customerBillAccountDO.setDueDate(updatedDueDate);
            customerBillAccountDO.setDueInfoUpdatedAt(new Date());
        }
        if (Objects.nonNull(customerBillAccount.getDueAmount())) {
            customerBillAccountDO.setDueAmount(customerBillAccount.getDueAmount());
            customerBillAccountDO.setDueAmountCurrencyUnit(CurrencyUnit.valueOf(customerBillAccount.getDueAmountCurrencyUnit()));
        }
        if (Objects.nonNull(customerBillAccount.getAlias())) {
            customerBillAccountDO.setAlias(customerBillAccount.getAlias());
        }

        if (Objects.nonNull(customerBillAccount.getProcessorBillAccountId()) && (Objects.isNull(customerBillAccount.getDueAmount()) || customerBillAccount.getDueAmount().equals(BigDecimal.ZERO))) {
            customerBillAccountDO.setDueDate(null);
        }

        customerBillAccountRepository.save(customerBillAccountDO);
        log.info("Customer-Bill-Account record Updation Process Success");
    }

}

