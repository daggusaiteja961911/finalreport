
package com.walmart.international.wallet.payment.core.mapper;


import com.walmart.international.ewallet.transaction.aggregator.payload.consts.*;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.PaymentInstrument;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TransactionEventDTO;
import com.walmart.international.services.payment.core.domain.SubTransactionStatus;
import com.walmart.international.wallet.payment.core.domain.model.*;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import org.springframework.stereotype.Component;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Date;

@Component
@Mapper(componentModel = "spring")
public interface TransactionSyncMapper {

    TransactionSyncMapper INSTANCE = Mappers.getMapper(TransactionSyncMapper.class);


    @Mapping(target = "transactionId", source = "coFTopupTransactionDO.coFTopupTransactionId")
    @Mapping(target = "customerAccountId", source = "coFTopupTransactionDO.customerAccountId")
    @Mapping(target = "amount", source = "coFTopupTransactionDO.amountRequested")
    @Mapping(target = "amountSettled", source = "coFTopupTransactionDO.amountProcessed")
    @Mapping(target = "currencyUnit", source = "coFTopupTransactionDO.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "state", source = "coFTopupTransactionDO.state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "coFTopupTransactionDO.stateReason")
    @Mapping(target = "createdDate", source = "coFTopupTransactionDO.createDate")
    @Mapping(target = "updatedDate", source = "coFTopupTransactionDO.updateDate")
    @Mapping(target = "transactionSource", source = "coFTopUpTransactionDTO", qualifiedByName = "mapLoadTransactionSource")
    @Mapping(target = "transactionType", source = "coFTopUpTransactionDTO.transactionType", qualifiedByName = "mapTransactionType")
    @Mapping(target = "paymentInstruments", source = "coFTopUpTransactionDTO", qualifiedByName = "mapLoadPaymentInstrument")
    @Mapping(target = "cashiOrderId", source = "coFTopUpTransactionDTO.cashiOrderId")
    @Mapping(target = "deviceId", source = "coFTopUpTransactionDTO.deviceId")
    @Mapping(target = "lastEventDate", source = "coFTopUpTransactionDTO.lastEventDate")
    TransactionEventDTO mapLoadMoneyTxnToTxnEvent(CoFTopupTransactionDO coFTopupTransactionDO, CoFTopUpTransaction coFTopUpTransactionDTO); // add logo as well

    @Named("mapStringToUuid")
    default UUID mapStringToUuid(String string) {
        return UUID.fromString(string);
    }

    @Named("mapLoadTransactionSource")
    default TransactionSource mapLoadTransactionSource(CoFTopUpTransaction coFTopUpTransaction) {
        return TransactionSource.CASHI;
    }

    @Named("mapTransactionType")
    default com.walmart.international.ewallet.transaction.aggregator.payload.consts.TransactionType mapTransactionType(com.walmart.international.wallet.payment.core.constants.enums.TransactionType txnType) {
        switch (txnType) {
            case BILL_PAY:
                return com.walmart.international.ewallet.transaction.aggregator.payload.consts.TransactionType.PAY;

            case COF_TOPUP:
                return com.walmart.international.ewallet.transaction.aggregator.payload.consts.TransactionType.LOAD;

            default:
                return null;
        }
    }

    @Named("mapTransactionState")
    default State mapTransactionState(TransactionStateEnum transactionState) {
        switch (transactionState) {
            case SUCCESS:
                return State.SUCCESS;
            case PENDING:
                return State.PENDING;
            case FAILURE:
            case CANCELLED:
                return State.FAILURE;
            default:
                return null;
        }
    }

    @Named("mapCurrencyUnit")
    default CurrencyUnit mapCurrencyUnit(com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit currencyUnit) {

        switch (currencyUnit) {
            case MXN:
                return CurrencyUnit.MXN;
            default:
                return null;
        }
    }

    @Named("mapLoadPaymentInstrument")
    default List<PaymentInstrument> mapLoadPaymentInstrument(CoFTopUpTransaction coFTopUpTransactionDTO) {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<GiftCardTransaction> giftCardLoadTransactionList = coFTopUpTransactionDTO.getGiftCardLoadTransactionList();
        List<CardPaymentTransaction> cardPaymentTransactionList = coFTopUpTransactionDTO.getCardPaymentTransactionList();

        giftCardLoadTransactionList.stream().forEach(giftCardLoadTransaction -> {
            PaymentInstrument paymentInstrument = new PaymentInstrument();
            paymentInstrument.setId(giftCardLoadTransaction.getGiftCardSubTransaction().getId());
            paymentInstrument.setType(PaymentMode.GIFTCARD);
            paymentInstrument.setTransactionState(mapGCPaymentInstrumentState(giftCardLoadTransaction.getGiftCardSubTransaction().getStatus()));
            paymentInstrument.setTransactionType(mapGCTransactionType(com.walmart.international.wallet.payment.core.constants.enums.TransactionType.COF_TOPUP));
            paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(giftCardLoadTransaction.getGiftCardSubTransaction().getCreateDate()));
            paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(giftCardLoadTransaction.getGiftCardSubTransaction().getUpdateDate()));
            paymentInstrument.setIsVale(mapIsVale(giftCardLoadTransaction));
            paymentInstruments.add(paymentInstrument);
        });

        cardPaymentTransactionList.stream().forEach(cardTransactionDetailsDO -> {
            PaymentInstrument paymentInstrument = new PaymentInstrument();
            paymentInstrument.setId(cardTransactionDetailsDO.getCardSubTransaction().getId());
            paymentInstrument.setType(PaymentMode.CARD);
            paymentInstrument.setTransactionState(mapCardPaymentInstrumentState(cardTransactionDetailsDO.getCardSubTransaction().getStatus()));
            // As on today, vale card is not allowed in the cards
            paymentInstrument.setIsVale(false);
            paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(cardTransactionDetailsDO.getCardSubTransaction().getCreateDate()));
            paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(cardTransactionDetailsDO.getCardSubTransaction().getUpdateDate() == null ? cardTransactionDetailsDO.getCardSubTransaction().getCreateDate() : cardTransactionDetailsDO.getCardSubTransaction().getUpdateDate() ));
            paymentInstruments.add(paymentInstrument);
        });
        return paymentInstruments;
    }

    default PaymentInstrumentState mapGCPaymentInstrumentState(SubTransactionStatus transactionState) {
        switch (transactionState) {
            case LOAD_REQUESTED:
            case PAYMENT_PENDING:
                return PaymentInstrumentState.PENDING;
            case LOAD_SUCCEEDED:
            case PAYMENT_SUCCEEDED:
                return PaymentInstrumentState.SUCCESS;
            case LOAD_FAILED:
            case PAYMENT_FAILED:
                return PaymentInstrumentState.FAILURE;
            case REVERSAL_INITIATED:
                return PaymentInstrumentState.REVERSAL_INITIATED;
            case REVERSAL_FAILED:
                return PaymentInstrumentState.REVERSAL_FAILED;
            case REVERSED:
                return PaymentInstrumentState.REVERSED;
            default:
                return null;
        }
    }

    default PaymentInstrumentState mapCardPaymentInstrumentState(SubTransactionStatus subTransactionStatus) {
        switch (subTransactionStatus) {
            case PAYMENT_SUCCEEDED:
                return PaymentInstrumentState.SUCCESS;
            case PAYMENT_PROCESSING:
            case PAYMENT_PENDING:
            case PAYMENT_3DS_PROCESSING:
                return PaymentInstrumentState.PENDING;
            case PAYMENT_FAILED:
            case PAYMENT_REJECTED:
                return PaymentInstrumentState.FAILURE;
            case REVERSAL_INITIATED:
                return PaymentInstrumentState.REVERSAL_INITIATED;
            case REVERSAL_FAILED:
                return PaymentInstrumentState.REVERSAL_FAILED;
            case REVERSED:
                return PaymentInstrumentState.REVERSED;
            default:
                return null;
        }
    }

    private GCTransactionType mapGCTransactionType(com.walmart.international.wallet.payment.core.constants.enums.TransactionType giftCardTxnType) {
        switch (giftCardTxnType) {
            case COF_TOPUP:
                return GCTransactionType.ADD_BALANCE;
            case BILL_PAY:
                return GCTransactionType.AUTHORIZE;
            default:
                return null;
        }
    }

    private Boolean mapIsVale(GiftCardTransaction giftCardTransactionDetailsDO) {
        if (Objects.isNull(giftCardTransactionDetailsDO) || Objects.isNull(giftCardTransactionDetailsDO.getGiftCardPaymentInstrument()) ||
                Objects.isNull(giftCardTransactionDetailsDO.getGiftCardPaymentInstrument().getCompany()))
            return false;
        else
            return giftCardTransactionDetailsDO.getGiftCardPaymentInstrument().getCompany().getIsVale();
    }

    default LocalDateTime toLocalDateTime(Date dateToConvert) {
        if (null == dateToConvert)
            return null;
        return Instant.ofEpochMilli(dateToConvert.getTime())
                .atZone(ZoneId.of("UTC"))
                .toLocalDateTime();
    }

    @Mapping(target = "transactionId", source = "billPayTransactionDO.billPayTransactionId")
    @Mapping(target = "customerAccountId", source = "billPayTransactionDO.customerAccountId")
    @Mapping(target = "amount", source = "billPayTransactionDO.amount")
    @Mapping(target = "amountSettled", source = "billPayTransactionDO.amount")
    @Mapping(target = "currencyUnit", source = "billPayTransactionDO.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "state", source = "billPayTransactionDO.state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "billPayTransactionDO.stateReason")
    @Mapping(target = "createdDate", source = "billPayTransactionDO.createDate")
    @Mapping(target = "updatedDate", source = "billPayTransactionDO.updateDate")
    @Mapping(target = "transactionSource", source = "billPayTransactionDTO", qualifiedByName = "mapBillTransactionSource")
    @Mapping(target = "transactionType", source = "billPayTransactionDTO.transactionType", qualifiedByName = "mapTransactionType")
    @Mapping(target = "paymentInstruments", source = "billPayTransactionDTO", qualifiedByName = "mapBillPaymentInstrument")
    @Mapping(target = "cashiOrderId", source = "billPayTransactionDTO.cashiOrderId")
    @Mapping(target = "deviceId", source = "billPayTransactionDTO.deviceId")
    @Mapping(target = "lastEventDate", source = "billPayTransactionDTO.lastEventDate")
    @Mapping(target = "txnReqCompletedDate", source = "billPayTransactionDTO.txnReqCompletedDate")
    TransactionEventDTO mapBillPayToTxnEvent(BillPayTransactionDO billPayTransactionDO, BillPayTransaction billPayTransactionDTO); // add logo as well

    @Named("mapBillTransactionSource")
    default TransactionSource mapBillTransactionSource(BillPayTransaction billPayTransaction) {
        return TransactionSource.BILLER;
    }


    @Named("mapBillPaymentInstrument")
    default List<PaymentInstrument> mapBillPaymentInstrument(BillPayTransaction billPayTransactionDTO) {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<GiftCardTransaction> giftCardPaymentTransactionList = billPayTransactionDTO.getGiftCardPaymentTransactionList();
        List<CardPaymentTransaction> cardPaymentTransactionList = billPayTransactionDTO.getCardPaymentTransactionList();

        giftCardPaymentTransactionList.stream().forEach(giftCardPaymentTransaction -> {
            PaymentInstrument paymentInstrument = new PaymentInstrument();
            paymentInstrument.setId(giftCardPaymentTransaction.getGiftCardSubTransaction().getId());
            paymentInstrument.setType(PaymentMode.GIFTCARD);
            paymentInstrument.setTransactionState(mapGCPaymentInstrumentState(giftCardPaymentTransaction.getGiftCardSubTransaction().getStatus()));
            paymentInstrument.setTransactionType(mapGCTransactionType(com.walmart.international.wallet.payment.core.constants.enums.TransactionType.BILL_PAY));
            paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(giftCardPaymentTransaction.getGiftCardSubTransaction().getCreateDate()));
            paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(giftCardPaymentTransaction.getGiftCardSubTransaction().getUpdateDate()));
            paymentInstrument.setIsVale(mapIsVale(giftCardPaymentTransaction));
            paymentInstruments.add(paymentInstrument);
        });

        cardPaymentTransactionList.stream().forEach(cardTransactionDetailsDO -> {
            PaymentInstrument paymentInstrument = new PaymentInstrument();
            paymentInstrument.setId(cardTransactionDetailsDO.getCardSubTransaction().getId());
            paymentInstrument.setType(PaymentMode.CARD);
            paymentInstrument.setTransactionState(mapCardPaymentInstrumentState(cardTransactionDetailsDO.getCardSubTransaction().getStatus()));
            // As on today, vale card is not allowed in the cards
            paymentInstrument.setIsVale(false);
            paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(cardTransactionDetailsDO.getCardSubTransaction().getCreateDate()));
            paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(cardTransactionDetailsDO.getCardSubTransaction().getUpdateDate()));
            paymentInstruments.add(paymentInstrument);
        });
        return paymentInstruments;
    }


}
