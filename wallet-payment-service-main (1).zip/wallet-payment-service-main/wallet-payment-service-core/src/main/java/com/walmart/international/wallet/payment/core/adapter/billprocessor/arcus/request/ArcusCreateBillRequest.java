package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ArcusCreateBillRequest {

    @JsonProperty("account_number")
    private String accountNumber;

    @JsonProperty("biller_id")
    private int billerId;

}