package com.walmart.international.wallet.payment.core.mapper;

import com.google.common.base.Strings;
import com.walmart.international.campaign.dto.response.PromotionsMappingResponse;
import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Mapper
@Component
public interface BillerPromotionMapper {

    BillerPromotionMapper INSTANCE = Mappers.getMapper(BillerPromotionMapper.class);

    BillerPromotion mapCaasPromotionResponseToBillerPromotion(PromotionsMappingResponse promotionsMappingResponse);

    default List<BillerPromotion> mapCaasPromotionResponsesToBillerPromotions(List<PromotionsMappingResponse> promotionsList) {
        List<BillerPromotion> response = new ArrayList<>();
        if (promotionsList != null) {
            promotionsList.forEach(promotion -> {
                if (isPromotionActive(promotion, LocalDateTime.now())) {
                    response.add(mapCaasPromotionResponseToBillerPromotion(promotion));
                }
            });
        }
        return response;
    }

    private static boolean isPromotionActive(PromotionsMappingResponse promotion, LocalDateTime currentDate) {
        StringBuilder currentDateTime = getDatePartUtil(currentDate.toString().replace("T", " "));
        return !Strings.isNullOrEmpty(promotion.getStartDate()) && !Strings.isNullOrEmpty(promotion.getEndDate())
                && getDatePartUtil(promotion.getStartDate()).compareTo(currentDateTime) <= 0
                && getDatePartUtil(promotion.getEndDate()).compareTo(currentDateTime) >= 0;
    }

    private static StringBuilder getDatePartUtil(String param) {
        return new StringBuilder(param.split("\\.")[0]);
    }

}
