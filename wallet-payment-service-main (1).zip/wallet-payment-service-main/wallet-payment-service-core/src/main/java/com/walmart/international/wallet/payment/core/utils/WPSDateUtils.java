package com.walmart.international.wallet.payment.core.utils;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Locale;

public class WPSDateUtils {
    /***
     * Convert date to spanish text
     * Ex: 29/07/2023 -> 29 de julio de 2023
     * @param date Date
     * @return String
     */
    public static String dateToSpanishText(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale.forLanguageTag("es"));
        return dateFormat.format(date);
    }

    public static long getDaysBetween(Date dueDate, Date currentDate) {
        return ChronoUnit.DAYS.between(currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), dueDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
    }

    public static LocalDate dateToLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
