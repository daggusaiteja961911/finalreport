package com.walmart.international.wallet.payment.core.mapper;

public interface AccountingMapper {
}
