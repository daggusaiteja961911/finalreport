package com.walmart.international.wallet.payment.core.adapter.kafka.handler;

import com.walmart.international.ewallet.payment.exception.CardPaymentException;
import com.walmart.international.notification.dto.accounting.AccountingEventType;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.dto.CardTransactionDTO;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.kafka.response.AsyncRefundKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.ReconHandlingException;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.TransactionType;
import com.walmart.international.wallet.payment.core.adapter.kafka.service.DataCommunicationService;
import com.walmart.international.wallet.payment.core.adapter.kafka.service.ReconService;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Component
public class RefundReconHandler {

    @Autowired
    private PaymentCoreService paymentCoreService;


    @Autowired
    private ReconService reconService;

    @Autowired
    private DataCommunicationService dataCommunicationService;

    @Transactional
    public void handle(AsyncRefundKafkaResponse asyncRefundKafkaPayload) throws PaymentCoreServiceException, CardPaymentException {

        reconService.validateIfTransactionExistsInSystem(asyncRefundKafkaPayload);

        try {
            CardTransactionDTO cardTransactionDTO = null;
            try {
                cardTransactionDTO = paymentCoreService.handleAsyncRefund(asyncRefundKafkaPayload);
            } catch (PaymentCoreServiceException | CardPaymentException ex) {
                throw ex;
            } catch (Exception ex) {
                throw new ReconHandlingException(ErrorConstants.KafkaRefundRecon.ERROR_PROCESSING_REFUND_RECON, "Error occurred while handling charge recon by payment core", ex);
            }

            TransactionType transactionType = dataCommunicationService.getAccountingTransactionType(cardTransactionDTO.getCoreTransaction());

            //update transaction status in tables
            reconService.updateTransactionStatusForRefund(transactionType, cardTransactionDTO);

            //raise txn agg event here
            dataCommunicationService.raiseTxnAggregatorEvent(cardTransactionDTO, transactionType);

            Optional<AccountingEventType> accountingEventType = getAccountingEventType(asyncRefundKafkaPayload);

            if (accountingEventType.isPresent())
                //send to Accounting
                dataCommunicationService.sendAccountingMessage(accountingEventType.get(),
                        asyncRefundKafkaPayload.getEventPayload().getOrderId(), cardTransactionDTO, transactionType);

        } catch (Exception ex) {
            log.error("Error occurred while handling refund recon for : {}", asyncRefundKafkaPayload, ex);
        }
    }

    private Optional<AccountingEventType> getAccountingEventType(AsyncRefundKafkaResponse response) {
        try {
            return Optional.of(AccountingEventType.getEnum(response.getEventType()));
        } catch (Exception ex) {
            log.error("Invalid event type for accounting, skipping sending accounting message for refund card txn");
            return Optional.empty();
        }

    }


}
