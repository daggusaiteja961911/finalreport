package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class WalletCardBinsResponse {

    private List<CardBinDTO> bins;

    @Data
    @ToString
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CardBinDTO {

        private String bin;
        private String brandName;
        private String bankName;
        private String bankLogo;
        private String brandLogo;
        private String bankColor;
        private String textColor;

    }
}