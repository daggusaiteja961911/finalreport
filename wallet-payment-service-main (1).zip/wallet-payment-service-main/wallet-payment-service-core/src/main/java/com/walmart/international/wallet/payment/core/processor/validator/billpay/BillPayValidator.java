package com.walmart.international.wallet.payment.core.processor.validator.billpay;

import com.walmart.international.digiwallet.customer.adapter.CustomerServiceAdapter;
import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.validator.Validator;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.exception.DataConstraintViolationException;
import com.walmart.international.wallet.payment.core.mapper.BillerMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.data.dao.entity.BillDetailDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillDetailRepository;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.BillerRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.commons.collections.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@Slf4j
public class BillPayValidator implements Validator<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private CustomerServiceAdapter customerServiceAdapter;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private BillerRepository billerRepository;

    @Autowired
    private BillDetailRepository billDetailRepository;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    private CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    private BillerMapper billerMapper = BillerMapper.INSTANCE;

    @Override
    public boolean validate(WPSRequestDomainContext wpsRequestDomainContext) throws ApplicationException {
        BillPayTxnRequestDomainContext billPayTxnRequestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        try {
            log.info("Starting validation for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                    billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                    billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                    billPayTransaction.getCustomer().getCustomerAccountId());
            mapBillerDataToContext(billPayTxnRequestDomainContext);
            validateInputData(billPayTransaction);
            validateClientReqId(billPayTxnRequestDomainContext);
            validateAllowCoFBillPayment(billPayTransaction);
            mapCustomerDataToContext(billPayTransaction.getCustomer());
            validatePaymentInstrumentsInContext(billPayTransaction);
            validateB2BSplitPayment(billPayTransaction);
            validateMultipleB2BSplitPayment(billPayTransaction);
            // validateB2BUsageRestriction() - I believe this is not required for bill payment
            if (Objects.nonNull(billPayTransaction.getBillDetail()) && Objects.nonNull(billPayTransaction.getBillDetail().getBillDetailId())) {
                validateBillDetail(billPayTxnRequestDomainContext);
            }
            validatePaymentAmountAgainstBillerData(billPayTxnRequestDomainContext);
        } catch (DataConstraintViolationException e) {
            throw e;
        } catch (ApplicationException ae) {
            if (Objects.nonNull(billPayTxnRequestDomainContext.getBillerDO())) {
                createBillPayTransactionInValidationFailureState(billPayTxnRequestDomainContext);
            }
            throw ae;
        }
        return true;
    }

    private void validateInputData(BillPayTransaction billPayTransaction) {
        log.info("Validating input for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        Customer customer = billPayTransaction.getCustomer();
        if (Objects.isNull(customer.getCustomerAccountId())) {
            throw new DataValidationException(ErrorConstants.PayBillInit.CUSTOMER_ACCOUNT_ID_NULL);
        }

        if (CollectionUtils.isEmpty(billPayTransaction.getCardPaymentTransactionList())
                && CollectionUtils.isEmpty(billPayTransaction.getGiftCardPaymentTransactionList())) {
            throw new DataValidationException(ErrorConstants.PayBillInit.PAYMENT_OPTIONS_INFO_MISSING);
        }

        if (CollectionUtils.isNotEmpty(billPayTransaction.getCardPaymentTransactionList())
                && billPayTransaction.getCardPaymentTransactionList().size() > 1) {
            throw new DataValidationException(ErrorConstants.PayBillInit.MULTIPLE_CARD_PAYMENT_INSTRUMENT_NOT_ALLOWED);
        }

        validateTotalPaymentAmount(billPayTransaction);
    }

    private void validateTotalPaymentAmount(BillPayTransaction billPayTransaction) {
        log.info("Validating total payment amount for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        Amount totalPaymentInstrumentAmount = Amount.builder()
                .value(BigDecimal.ZERO)
                .currencyUnit(CurrencyUnit.MXN)
                .build();
        if (CollectionUtils.isNotEmpty(billPayTransaction.getGiftCardPaymentTransactionList())) {
            for (GiftCardTransaction giftCardPaymentTransaction : billPayTransaction.getGiftCardPaymentTransactionList()) {
                totalPaymentInstrumentAmount = Amount.sum(totalPaymentInstrumentAmount, giftCardPaymentTransaction.getAmount());
            }
        }
        if (CollectionUtils.isNotEmpty(billPayTransaction.getCardPaymentTransactionList())) {
            for (CardPaymentTransaction cardPaymentTransaction : billPayTransaction.getCardPaymentTransactionList()) {
                totalPaymentInstrumentAmount = Amount.sum(totalPaymentInstrumentAmount, cardPaymentTransaction.getAmount());
            }
        }
        if (totalPaymentInstrumentAmount.getValue().compareTo(billPayTransaction.getAmountRequested().getValue()) != 0
                || !totalPaymentInstrumentAmount.getCurrencyUnit().equals(billPayTransaction.getAmountRequested().getCurrencyUnit())) {
            throw new DataValidationException(com.walmart.international.wallet.payment.core.constants.ErrorConstants.PayBillInit.MISMATCH_IN_PAYMENT_AMOUNT);
        }
    }

    private void validateClientReqId(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        String clientReqId = billPayTxnRequestDomainContext.getClientRequestId();
        log.info("Validating clientRequestId for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        if (StringUtils.isEmpty(clientReqId)) {
            throw new DataConstraintViolationException(ErrorConstants.PayBillInit.MISSING_CLIENT_REQ_ID);
        }
        Optional<BillPayTransactionDO> billPayTransactionDO = billPayTransactionRepository.findByClientReqId(clientReqId);
        if (billPayTransactionDO.isPresent()) {
            throw new DataConstraintViolationException(ErrorConstants.PayBillInit.DUPILCATE_CLIENT_REQ_ID);
        }
    }

    private void validateAllowCoFBillPayment(BillPayTransaction billPayTransaction) {
        log.info("Validating allowCoFBillPayment for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        if (Boolean.FALSE.equals(billPaymentConfiguration.getAllowCoF()) && CollectionUtils.isNotEmpty(billPayTransaction.getCardPaymentTransactionList())) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.BILL_PAY_COF_DISABLED);
        }
    }

    private void mapCustomerDataToContext(Customer customer) {
        log.info("Mapping customer data to context for customerAccountId:[{}]", customer.getCustomerAccountId());
        CustomerResponse customerResponse = customerServiceClient.getCustomerDetailsById(customer.getCustomerAccountId());
        if (customerResponse == null) {
            throw new DataValidationException(ErrorConstants.PayBillInit.CUSTOMER_ACCOUNT_NOT_FOUND);
        }
        customerMapper.updateCustomerDataInContext(customerResponse, customer);
        mapPaymentInstrumentsToCustomerContext(customer, customerResponse);
    }

    private void mapPaymentInstrumentsToCustomerContext(Customer customer, CustomerResponse customerResponse) {
        log.info("Mapping payment instruments to customer context for customerAccountId:[{}]", customer.getCustomerAccountId());
        customerMapper.mapPaymentInstrumentsToCustomerContext(customer, customerResponse);
    }

    private void validatePaymentInstrumentsInContext(BillPayTransaction billPayTransaction) {
        Customer customer = billPayTransaction.getCustomer();
        UUID customerAccountId = customer.getCustomerAccountId();
        log.info("Validating payment instruments in context for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());

        List<CardPaymentInstrument> cardPaymentInstrumentList = customer.getCardPaymentInstrumentList();
        List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList = customer.getGiftCardPaymentInstrumentList();

        if (CollectionUtils.isEmpty(cardPaymentInstrumentList) && CollectionUtils.isEmpty(giftCardPaymentInstrumentList)) {
            String msg = String.format("No payment instrument exists for customerAccountId[%s]",  customerAccountId);
            throw new BusinessValidationException(ErrorConstants.PayBillInit.PAYMENT_INSTRUMENTS_NOT_FOUND_FOR_CUSTOMER, msg);
        }

        List<CardPaymentTransaction> cardPaymentTransactionList = billPayTransaction.getCardPaymentTransactionList();
        for (CardPaymentTransaction cardPaymentTransaction : cardPaymentTransactionList) {
            Optional<CardPaymentInstrument> optionalCardPaymentInstrument = cardPaymentInstrumentList.stream()
                    .filter(cardPaymentInstrument ->
                            cardPaymentInstrument.getPaymentInstrumentId().equals(cardPaymentTransaction.getPaymentInstrumentId().toString()))
                    .findFirst();
            if (optionalCardPaymentInstrument.isPresent()) {
                cardPaymentTransaction.setCardPaymentInstrument(optionalCardPaymentInstrument.get());
                cardPaymentTransaction.setProviderWalletId(optionalCardPaymentInstrument.get().getAdapterMetadata().getWalletId());
            } else {
                String msg = String.format("Card payment instrument with paymentInstrumentId[%s] not found for given customerAccountId[%s]",
                        cardPaymentTransaction.getPaymentInstrumentId(), customerAccountId);
                throw new BusinessValidationException(ErrorConstants.PayBillInit.CARD_PAYMENT_INSTRUMENT_NOT_FOUND, msg);
            }
        }

        List<GiftCardTransaction> giftCardPaymentTransactionList = billPayTransaction.getGiftCardPaymentTransactionList();
        for (GiftCardTransaction giftCardPaymentTransaction : giftCardPaymentTransactionList) {
            Optional<GiftCardPaymentInstrument> optionalGiftCardPaymentInstrument = giftCardPaymentInstrumentList.stream()
                    .filter(giftCardPaymentInstrument ->
                            giftCardPaymentInstrument.getPaymentInstrumentId().equals(giftCardPaymentTransaction.getPaymentInstrumentId().toString()))
                    .findFirst();
            if (optionalGiftCardPaymentInstrument.isEmpty()) {
                String msg = String.format("Gift card payment instrument with paymentInstrumentId[%s] not found for customerAccountId[%s]",
                        giftCardPaymentTransaction.getPaymentInstrumentId(), customerAccountId);
                throw new BusinessValidationException(ErrorConstants.PayBillInit.GIFT_CARD_PAYMENT_INSTRUMENT_NOT_FOUND, msg);
            } else {
                giftCardPaymentTransaction.setGiftCardPaymentInstrument(optionalGiftCardPaymentInstrument.get());
            }
        }
    }

    private void validateB2BSplitPayment(BillPayTransaction billPayTransaction) {
        log.info("Validating b2b split payment for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        if (Boolean.FALSE.equals(billPaymentConfiguration.getAllowB2BForSplitPayment())
                && CollectionUtils.isNotEmpty(billPayTransaction.getGiftCardPaymentTransactionList())) {
            List<GiftCardPaymentInstrument> giftCardsUsedForPayment = billPayTransaction.getGiftCardPaymentTransactionList()
                    .stream()
                    .map(GiftCardTransaction::getGiftCardPaymentInstrument)
                    .collect(Collectors.toUnmodifiableList());
            boolean isB2BCardUsedForPayment = hasPaymentInstrumentSubType(PaymentInstrumentSubType.CORP_CARD, giftCardsUsedForPayment);
            if (isB2BCardUsedForPayment
                    && (hasPaymentInstrumentSubType(PaymentInstrumentSubType.CASHI_WALLET, giftCardsUsedForPayment)
                        || CollectionUtils.isNotEmpty(billPayTransaction.getCardPaymentTransactionList()))) {
                    throw new BusinessValidationException(ErrorConstants.PayBillInit.PAYMENT_OPTIONS_COMBINATION_NOT_ALLOWED);

            }
        }
    }

    private boolean hasPaymentInstrumentSubType(PaymentInstrumentSubType paymentInstrumentSubType,
                                                List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList) {
        return CollectionUtils.isNotEmpty(giftCardPaymentInstrumentList
                .stream()
                .filter(giftCardPaymentInstrument -> giftCardPaymentInstrument.getPaymentInstrumentSubType().equals(paymentInstrumentSubType))
                .collect(Collectors.toList()));
    }

    private void validateMultipleB2BSplitPayment(BillPayTransaction billPayTransaction) {
        log.info("Validating multiple b2b split payment for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        if (Boolean.FALSE.equals(billPaymentConfiguration.getAllowMultipleB2BForSplitPayment())
                && CollectionUtils.isNotEmpty(billPayTransaction.getGiftCardPaymentTransactionList())) {
            List<GiftCardPaymentInstrument> giftCardsUsedForPayment = billPayTransaction.getGiftCardPaymentTransactionList()
                    .stream().map(GiftCardTransaction::getGiftCardPaymentInstrument).collect(Collectors.toUnmodifiableList());
            long totalB2BCardsUsedForPayment = giftCardsUsedForPayment
                    .stream()
                    .filter(giftCardPaymentInstrument -> giftCardPaymentInstrument.getPaymentInstrumentSubType().equals(PaymentInstrumentSubType.CORP_CARD))
                    .count();
            if (totalB2BCardsUsedForPayment > 1) {
                throw new BusinessValidationException(ErrorConstants.PayBillInit.PAYMENT_OPTIONS_COMBINATION_NOT_ALLOWED);
            }
        }
    }

    private void validateBillDetail(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        log.info("Validating billDetail with billDetailId:[{}] for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getBillDetail().getBillDetailId(),
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        Optional<BillDetailDO> billDetailDOOptional = billDetailRepository.findById(billPayTransaction.getBillDetail().getBillDetailId());
        boolean isStaleData = false;
        String msg = "";
        if (billDetailDOOptional.isEmpty()) {
            msg = String.format("Bill detail with id[%s] does not exist for processorBillerId[%s]",
                    billPayTransaction.getBillDetail().getBillDetailId(), billPayTransaction.getCustomerBillAccount().getProcessorBillerId());
            isStaleData = true;
        } else {
            BillDetailDO billDetailDO = billDetailDOOptional.get();
            if (billDetailDO.getBillAmount().compareTo(billPayTransaction.getAmountRequested().getValue()) != 0) {
                msg = String.format("Mismatch in bill detail amount for processorBillerId[%s], billDetailId[%s]",
                        billPayTransaction.getCustomerBillAccount().getProcessorBillerId(), billPayTransaction.getBillDetail().getBillDetailId());
                isStaleData = true;
            }
            if (!billDetailDO.isEnabled()) {
                msg = String.format("Bill detail with id[%s] is disabled for processorBillerId[%s]",
                        billPayTransaction.getBillDetail().getBillDetailId(), billPayTransaction.getCustomerBillAccount().getProcessorBillerId());
                isStaleData = true;
            }
        }

        if (isStaleData) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.BILL_DETAIL_DATA_STALED, msg);
        } else {
            billPayTxnRequestDomainContext.setBillDetailDO(billDetailDOOptional.get());
            billPayTransaction.setBillDetail(billerMapper.mapBillDetail(billDetailDOOptional.get()));
        }
    }

    private void mapBillerDataToContext(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        CustomerBillAccount customerBillAccount = billPayTransaction.getCustomerBillAccount();
        log.info("Mapping biller data to context for processorBillerId:[{}]", customerBillAccount.getProcessorBillerId());
        BillerDO billerDO = getBillerDO(customerBillAccount.getBillerId(), customerBillAccount.getProcessorBillerId());
        billPayTxnRequestDomainContext.setBillerDO(billerDO);
        billPayTxnRequestDomainContext.getTransaction().setBiller(billerMapper.mapBillerDOToBillerWithoutSubBillersAndBillPlans(billerDO));
    }

    private BillerDO getBillerDO(UUID billerId, String processorBillerId) {
        Optional<BillerDO> billerDO;
        if (Objects.nonNull(billerId)) {
            billerDO = billerRepository.getByBillerIdAndEnabled(billerId, Boolean.TRUE);
            if (billerDO.isPresent()) {
                return billerDO.get();
            } else {
                String msg = String.format("Biller with billerId[%s] not found in DB", billerId);
                throw new ProcessingException(ErrorConstants.PayBillInit.BILLER_NOT_FOUND_OR_NOT_ENABLED, msg);
            }
        } else if (Objects.nonNull(processorBillerId)) {
            billerDO = billerRepository.getByProcessorBillerIdAndEnabled(processorBillerId, Boolean.TRUE);
            if (billerDO.isPresent()) {
                return billerDO.get();
            } else {
                String msg = String.format("Biller with processorBillerId[%s] not found in DB", processorBillerId);
                throw new ProcessingException(ErrorConstants.PayBillInit.BILLER_NOT_FOUND_OR_NOT_ENABLED, msg);
            }
        }
        throw new DataValidationException(ErrorConstants.PayBillInit.BILLER_ID_AND_PROCESSOR_BILLER_ID_IS_NULL);
    }

    private void validatePaymentAmountAgainstBillerData(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        log.info("Validating payment amount for BillPayTransaction with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        Biller biller = billPayTransaction.getCustomerBillAccount().getBiller();
        if (biller.isBillTypeGiftCard()) {
            if (Objects.nonNull(biller.getMinAmount())
                    && billPayTransaction.getAmountRequested().getValue().compareTo(biller.getMinAmount()) < 0) {
                String msg = String.format("Transaction amount:[%s] is less than minAmount:[%s] possible",
                        billPayTransaction.getAmountRequested().getValue(), biller.getMinAmount());
                throw new BusinessValidationException(ErrorConstants.PayBillInit.BILLER_MIN_AMOUNT_VALIDATION_ERROR,
                        msg, new Object[]{biller.getMinAmount().toString()});
            }
            if (Objects.nonNull(biller.getMaxAmount())
                    && billPayTransaction.getAmountRequested().getValue().compareTo(biller.getMaxAmount()) > 0) {
                String msg = String.format("Transaction amount:[%s] is greater than maxAmount:[%s] possible",
                        billPayTransaction.getAmountRequested().getValue(), biller.getMaxAmount());
                throw new BusinessValidationException(ErrorConstants.PayBillInit.BILLER_MAX_AMOUNT_VALIDATION_ERROR,
                        msg, new Object[]{biller.getMaxAmount().toString()});
            }
        }

        if (Objects.nonNull(biller.getSupportsPartialPayments())
                && Boolean.TRUE.equals(biller.getSupportsPartialPayments())
                && Objects.nonNull(biller.getPartialMinAmount())
                && billPayTransaction.getAmountRequested().getValue().compareTo(biller.getPartialMinAmount()) < 0) {
            String msg = String.format("Transaction amount:[%s] is less than partial min amount:[%s] possible",
                    billPayTransaction.getAmountRequested().getValue(), biller.getPartialMinAmount());
            throw new BusinessValidationException(ErrorConstants.PayBillInit.BILLER_PARTIAL_PAYMENT_MIN_AMOUNT_VALIDATION_ERROR,
                    msg, new Object[]{biller.getPartialMinAmount().toString()});
        }

        if (Objects.nonNull(biller.getPartialAcceptOnlyPesos())
                && Boolean.TRUE.equals(biller.getPartialAcceptOnlyPesos())
                && billPayTransaction.getAmountRequested().getValue().movePointRight(2).intValue() % 100 > 0) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.BILLER_PARTIAL_ACCEPT_ONLY_PESOS_VALIDATION_ERROR);
        }
    }

    private void createBillPayTransactionInValidationFailureState(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransactionDO billPayTransactionDO = BillPayUtil.createBillPayTransactionDOInValidationFailureState(billPayTxnRequestDomainContext);
        billPayTransactionRepository.save(billPayTransactionDO);
    }

}
