package com.walmart.international.wallet.payment.core.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NotificationContentDTO {

    private BigDecimal amount;

    private BigDecimal lastPaidAmount;

    private String formattedDueDate;

    private String billerName;

    private String lastPaidDate;

    private String alias;

    private String title;

    private String message;

    private String identifier;

    private String validity;

    private String itemDescription;

    private String product;

    private Date dueDate;
}