package com.walmart.international.wallet.payment.core.adapter.kafka.handler;

import com.walmart.commons.collections.CollectionUtils;
import com.walmart.international.ewallet.payment.exception.CardPaymentException;
import com.walmart.international.notification.dto.accounting.AccountingEventType;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.kafka.response.AsyncChargeKafkaPayload;
import com.walmart.international.services.payment.core.response.ReconResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.ReconHandlingException;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.TransactionType;
import com.walmart.international.wallet.payment.core.adapter.kafka.service.DataCommunicationService;
import com.walmart.international.wallet.payment.core.adapter.kafka.service.ReconService;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ChargeReconHandler {

    @Autowired
    private PaymentCoreService paymentCoreService;

    @Autowired
    private ReconService reconService;

    @Autowired
    private DataCommunicationService dataCommunicationService;

    @Transactional
    public void handle(AsyncChargeKafkaPayload asyncChargeKafkaPayload) throws PaymentCoreServiceException, CardPaymentException {
        reconService.validateIfTransactionExistsInSystem(asyncChargeKafkaPayload);

        for (AsyncChargeKafkaPayload.AsyncChargeKafkaResponse asyncChargeKafkaResponse : asyncChargeKafkaPayload.getAsyncChargeResponse()) {
            List<ReconResponse> reconResponses;
            try {
                reconResponses = paymentCoreService.handleAsyncCharge(asyncChargeKafkaResponse);
            } catch (PaymentCoreServiceException | CardPaymentException ex) {
                throw ex;
            } catch (Exception ex) {
                throw new ReconHandlingException(ErrorConstants.KafkaChargeRecon.ERROR_PROCESSING_CHARGE_RECON, "Error occurred while handling charge recon by payment core", ex);
            }

            if (CollectionUtils.isEmpty(reconResponses) || Objects.isNull(reconResponses.get(0).getCardTransactionDTO())) {
                log.info("Invalid recon response received from payment core, exiting ChargeReconHandler for :{}", asyncChargeKafkaPayload.getAsyncChargeResponse());
                return;
            }

            final TransactionType transactionType = dataCommunicationService.getAccountingTransactionType(reconResponses.get(0).getCardTransactionDTO().getCoreTransaction());

            Set<UUID> successfulReconIds = Optional.of(reconResponses).orElse(Collections.emptyList()).stream()
                    .filter(Objects::nonNull).filter(r -> r.getCardTransactionDTO() != null)
                    .map(r -> sendAccountingMessageAndGetReconId(asyncChargeKafkaResponse, r, transactionType))
                    .filter(Optional::isPresent).map(Optional::get).collect(Collectors.toSet());

            if (!successfulReconIds.isEmpty())
                paymentCoreService.updateAccountingStatusForChargeCardRecon(successfulReconIds);

        }
    }

    private Optional<UUID> sendAccountingMessageAndGetReconId(AsyncChargeKafkaPayload.AsyncChargeKafkaResponse asyncChargeKafkaResponse, ReconResponse response, TransactionType transactionType) {
        try {
            log.info("Starting accounting for cardTransaction : {}", response.getCardTransactionDTO().getSubTransactionId());
            AccountingEventType accountingEventType;
            try {
                accountingEventType = AccountingEventType.getEnum(asyncChargeKafkaResponse.getEventType());
            } catch (Exception ex) {
                log.error("Invalid event type for accounting, skipping sending accounting message for cardtxn : {}", response.getCardTransactionDTO().getSubTransactionId());
                return Optional.empty();
            }
            dataCommunicationService.sendAccountingMessage(accountingEventType
                    , asyncChargeKafkaResponse.getEventPayload().getOrderId(),
                    response.getCardTransactionDTO(), transactionType);
            return Optional.of(response.getCardTransactionDTO().getSubTransactionId());
        } catch (Exception ex) {
            log.error("Exception occurred while processing accounting for cardTransaction : {}", response.getCardTransactionDTO().getSubTransactionId(), ex);
        }
        return Optional.empty();
    }

}
