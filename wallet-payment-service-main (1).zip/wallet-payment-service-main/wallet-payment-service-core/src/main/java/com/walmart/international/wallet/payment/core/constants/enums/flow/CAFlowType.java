package com.walmart.international.wallet.payment.core.constants.enums.flow;

import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.LinkedList;

@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum CAFlowType implements FlowType<WPSRequestDomainContext, WPSResponseDomainContext> {

//    COF_TOPUP("COF_TOPUP",payment
//            new LinkedList<>(Arrays.asList(CustomerValidator.class, PaymentInstrumentValidator.class,
//                    AMLValidator.class, CofTopupPreProcessor.class, CofTopupProcessor.class, CofTopupPostProcessor.class))),

//    COF_TOPUP_VALIDATE("COF_TOPUP_VALIDATE", new LinkedList<>(Arrays.asList(CofTopupPreProcessor.class,
//            CoFTopupProcessor.class, CofTopupPostProcessor.class)))
            ;

    private String flowName;

    private LinkedList<Class<? extends IProcessor<WPSRequestDomainContext, WPSResponseDomainContext>>> flow;
}
