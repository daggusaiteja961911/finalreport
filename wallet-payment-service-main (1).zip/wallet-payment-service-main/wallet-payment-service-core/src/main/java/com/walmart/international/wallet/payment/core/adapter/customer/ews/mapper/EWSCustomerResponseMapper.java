package com.walmart.international.wallet.payment.core.adapter.customer.ews.mapper;

import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentSubType;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.EWSCustomerAccountDTO;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.EWSPaymentPreferenceDTO;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Mapper(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = {LocalDateTime.class, ChronoUnit.class})
@Component
public interface EWSCustomerResponseMapper {

    EWSCustomerResponseMapper INSTANCE = Mappers.getMapper(EWSCustomerResponseMapper.class);

    @Mapping(target = "emailVerified", source = "ewsCustomerAccountDTO.emailVerified2")
    @Mapping(target = "dateOfBirth", source = "ewsCustomerAccountDTO.dob", qualifiedByName = "mapDOB")
    @Mapping(target = "statusReason", source = "ewsCustomerAccountDTO.state")
    @Mapping(target = "address", source = "ewsCustomerAccountDTO.addressDTO")
    @Mapping(target = "walletAccountDTO.walletAccountId", source = "ewsCustomerAccountDTO.walletAccountDTO.walletAccountId", qualifiedByName = "uuidToString")
    @Mapping(target = "walletAccountDTO.walletResponse", source = "ewsCustomerAccountDTO.walletAccountDTO.payments", qualifiedByName = "mapPayments")
    CustomerResponse mapToCustomerResponse(EWSCustomerAccountDTO ewsCustomerAccountDTO, String message);


    @Named("mapDOB")
    static Date mapDOB(String dateOfBirth) {
        if (dateOfBirth != null) {
            try {
                return (new SimpleDateFormat("yyyy-MM-dd")).parse(dateOfBirth);
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }
    @Named("uuidToString")
    static String uuidToString(UUID uuid) {
        return uuid.toString();
    }

    @Named("mapPayments")
    default WalletResponse mapPayments(List<EWSPaymentPreferenceDTO> ewsPaymentPreferenceDTOS) {
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = null;
        if (Objects.nonNull(ewsPaymentPreferenceDTOS)) {
            paymentInstrumentList = new ArrayList<>();
            for (EWSPaymentPreferenceDTO ewsPaymentPreferenceDTO : ewsPaymentPreferenceDTOS) {
                WalletResponse.PaymentInstrument paymentInstrument = mapPaymentInstrument(ewsPaymentPreferenceDTO);
                paymentInstrument.setExpirationDate(mapExpirationDate(ewsPaymentPreferenceDTO));
                paymentInstrument.setIsExpired(mapIsExpired(paymentInstrument.getExpirationDate()));
                paymentInstrumentList.add(paymentInstrument);
            }
        }
        return WalletResponse.builder().paymentInstruments(paymentInstrumentList).build();
    }

    @Mapping(target = "paymentInstrumentId", source = "paymentId")
    @Mapping(target = "paymentInstrumentType", source = "paymentType", qualifiedByName = "mapPaymentType")
    @Mapping(target = "paymentInstrumentSubType", source = "ewsPaymentPreferenceDTO", qualifiedByName = "mapPaymentSubType")
    @Mapping(target = "adapterMetadata.piHash", source = "piHash")
    @Mapping(target = "adapterMetadata.accountNumber", source = "accountNumber")
    @Mapping(target = "adapterMetadata.tokenId", source = "tokenId")
    @Mapping(target = "adapterMetadata.walletId", source = "paymentBrokerWalletId")
    @Mapping(target = "billingAddress.streetExtNum", source = "billingAddress.exteriorNum")
    @Mapping(target = "billingAddress.streetIntNum", source = "billingAddress.interiorNum")
    @Mapping(target = "billingAddress.country", source = "billingAddress.countryCode")
    @Mapping(target = "isFavourite", source = "favoriteCard")
    @Mapping(target = "metadata.cardholderName", source = "cardholderName")
    @Mapping(target = "metadata.cardNumber", source = "cardNumber")
    @Mapping(target = "metadata.last4Digits", source = "last4Digits")
    @Mapping(target = "metadata.brand", source = "brand")
    @Mapping(target = "metadata.cvvVerified", source = "cvvVerified")
    @Mapping(target = "metadata.cvvRequired", source = "cvvRequired")
    @Mapping(target = "metadata.favoriteCard", source = "favoriteCard")
    @Mapping(target = "metadata.aliasName", source = "aliasName")
    WalletResponse.PaymentInstrument mapPaymentInstrument(EWSPaymentPreferenceDTO ewsPaymentPreferenceDTO);

    static Date mapExpirationDate(EWSPaymentPreferenceDTO paymentPreferenceDTO) {
        if (StringUtils.isNotEmpty(paymentPreferenceDTO.getExpirationYear()) && StringUtils.isNotEmpty(paymentPreferenceDTO.getExpirationMonth())) {
            DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                    .appendPattern("MM/yy")
                    .parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
                    .toFormatter();

            String expirationMonth = paymentPreferenceDTO.getExpirationMonth();
            String expirationYear = paymentPreferenceDTO.getExpirationYear();

            if (StringUtils.length(expirationMonth) < 2) {
                expirationMonth = "0" + expirationMonth;
            }

            try {
                LocalDate expiryDate = LocalDate.parse(expirationMonth + "/" + expirationYear, formatter);
                expiryDate = expiryDate.withDayOfMonth(expiryDate.getMonth().length(expiryDate.isLeapYear()));
                return Date.from(expiryDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
            } catch (DateTimeParseException dtpe) {
                String msg = String.format("Unable to parse expiration month/year: " + expirationMonth + "/" + expirationYear);
                throw new BusinessValidationException(ErrorConstants.CustomerClientForEWS.EXPIRY_DETAILS_PARSE_EXCEPTION, msg);
            }
        }
        return null;
    }

    default Boolean mapIsExpired(Date expirationDate) {
        return Objects.isNull(expirationDate) ? null : ZonedDateTime.ofInstant(expirationDate.toInstant(), ZoneId.systemDefault()).isBefore(ZonedDateTime.now());
    }

    @Named("mapPaymentType")
    default PaymentInstrumentType mapPaymentType(String paymentType) {
        if (paymentType != null) {
            switch (paymentType.toUpperCase()) {
                case "DEBIT":
                case "CREDIT":
                case "CARD":
                    return PaymentInstrumentType.CARD;
                case "GIFTCARD":
                case "CORPGIFTCARD":
                    return PaymentInstrumentType.GIFTCARD;
                default:
                    return null;
            }
        }
        return null;
    }

    @Named("mapPaymentSubType")
    default PaymentInstrumentSubType mapPaymentSubType(EWSPaymentPreferenceDTO ewsPaymentPreferenceDTO) {
        if (StringUtils.isNotEmpty(ewsPaymentPreferenceDTO.getPaymentType())) {
            String paymentType = ewsPaymentPreferenceDTO.getPaymentType().toUpperCase();
            switch (paymentType) {
                case "DEBIT":
                    return PaymentInstrumentSubType.DEBIT_CARD;
                case "CREDIT":
                    return PaymentInstrumentSubType.CREDIT_CARD;
                case "GIFTCARD":
                    return PaymentInstrumentSubType.CASHI_WALLET;
                case "CORPGIFTCARD": {
                    if (Objects.nonNull(ewsPaymentPreferenceDTO.getCompany())) {
                        if (ewsPaymentPreferenceDTO.getCompany().getCompanyName().equals(WPSConstants.PaymentInstrument.ASSOCIATE_FOOD_VOUCHER_COMPANY_NAME)) {
                            return PaymentInstrumentSubType.ASSOCIATE_FOOD_VOUCHER;
                        }
                    }
                    return PaymentInstrumentSubType.CORP_CARD;
                }
                default:
                    return null;
            }
        }
        return null;
    }

}