package com.walmart.international.wallet.payment.core.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class GiftCardPaymentInstrument extends PaymentInstrument {
    private AdapterMetadata adapterMetadata;
    private Balance balance;
    private boolean isActive = true;
    private Date updateDate;
    private Date issuedate;
    private Company company;
    private String requestId;
    private String accertifyTokenId;
    private String accertifySessionId;
    private UUID parentPaymentPreferenceId;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Company {
        String companyName;
        String companyLogo;
        String companyImage;
        String companyColor;
        Boolean isVale;
        String applicableBanners;
        String whiteListedUpcs;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdapterMetadata {
        String tokenId;
        String walletId;
        String piHash;
        String accountNumber;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Balance {
        BigDecimal currencyAmount;
        String currencyUnit;
    }
}
