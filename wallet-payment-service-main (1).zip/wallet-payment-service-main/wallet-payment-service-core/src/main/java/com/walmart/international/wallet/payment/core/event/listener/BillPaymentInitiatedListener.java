package com.walmart.international.wallet.payment.core.event.listener;

import com.walmart.international.ewallet.services.events.config.Listener;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.event.payload.PayBillInitEventPayload;
import com.walmart.international.wallet.payment.core.service.FlowExecutor;
import com.walmart.international.wallet.payment.core.service.JPASessionManagementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class BillPaymentInitiatedListener {

    @Autowired
    private FlowExecutor flowExecutor;

    @Autowired
    private JPASessionManagementService sessionManagementService;

    @Listener(types = {WPSConstants.Event.PAY_BILL_INIT})
    public void handleEvent(PayBillInitEventPayload payBillInitEventPayload) {
        if (Objects.isNull(payBillInitEventPayload)) {
            log.error("Failed to process PAY_BILL_INIT event as payload is null");
            return;
        }
        executeWithinSession(payBillInitEventPayload);
    }

    private void executeWithinSession(PayBillInitEventPayload payBillInitEventPayload) {
        UUID sessionId = UUID.randomUUID();
        try {
            sessionManagementService.openSession(sessionId.toString());
            log.info("Successfully opened session with id:[{}]", sessionId);

            flowExecutor.executeFlowType(MXFlowType.PAY_BILL,
                    payBillInitEventPayload.getBillPayTxnRequestDomainContext(),
                    payBillInitEventPayload.getBillPayTxnResponseDomainContext());
        } finally {
            sessionManagementService.closeSession(sessionId.toString());
            log.info("Successfully closed session with id:[{}]", sessionId);
        }
    }
}
