package com.walmart.international.wallet.payment.core.domain.model.request;

import com.walmart.international.wallet.payment.core.domain.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionRequestDomainContext extends WPSRequestDomainContext {
    Transaction transaction;
}
