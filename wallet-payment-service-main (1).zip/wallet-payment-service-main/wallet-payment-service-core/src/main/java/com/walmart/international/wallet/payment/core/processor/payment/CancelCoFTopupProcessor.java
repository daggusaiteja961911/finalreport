package com.walmart.international.wallet.payment.core.processor.payment;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.domain.CoreTransactionStatus;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.request.CancelRequest;
import com.walmart.international.services.payment.core.response.CancelResponse;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CancelCoFTopupProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    PaymentCoreService paymentCoreService;

    @Autowired
    CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ProcessingException {
        CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        callPaymentCoreCancelTransaction(String.valueOf(coFTopUpTransaction.getTransactionId()));
        updateCoFTopupTxnStateFor3DSCancelled(coFTopupTxnResponseDomainContext);
        return true;
    }

    private void callPaymentCoreCancelTransaction(String transactionId) throws ProcessingException {
        log.info("calling paymentCore Cancel Transaction for transactionId : {}", transactionId);
        try {
            String clientTransactionId = String.join("_", String.valueOf(transactionId), "1");
            CancelRequest cancelRequest = CancelRequest.builder()
                    .clientTransactionId(clientTransactionId)
                    .build();
            CancelResponse cancelResponse = paymentCoreService.cancel(cancelRequest);

            if (!CoreTransactionStatus.CANCELLED.equals(cancelResponse.getStatus())) {
                String msg = String.format("paymentCore cancel failed for transactionId [%s] transactionStatus[%s]", transactionId, cancelResponse.getStatus());
                throw new BusinessValidationException(ErrorConstants.CancelCoFTopupTransaction.PAYMENT_CORE_CANCEL_PAYMENT_FAILED, msg);
            }
        } catch (PaymentCoreServiceException ex) {
            String msg = String.format("paymentCore cancel failed for transactionId : [%s]", transactionId);
            throw new ProcessingException(ErrorConstants.CancelCoFTopupTransaction.PAYMENT_CORE_CANCEL_PAYMENT_FAILED, msg, ex);
        }
    }

    private void updateCoFTopupTxnStateFor3DSCancelled(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO();
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        log.info("Updating transaction state for cancelled CoFTopupTransaction with transactionId : {}", coFTopupTransactionDO.getCoFTopupTransactionId());
        coFTopupTransactionDO.setState(TransactionStateEnum.FAILURE);
        coFTopupTransactionDO.setStateReason(CoFTopupTxnStateReason.DEBIT_3DS_CANCELLED);
        coFTopupTransactionDO.setAbortReason(coFTopUpTransaction.getAbortReason());
        coFTopupTransactionDO.updateLastEventDate();
        coFTopupTransactionDO = coFTopupTransactionRepository.save(coFTopupTransactionDO);
        coFTopupTxnResponseDomainContext.setCoFTopupTransactionDO(coFTopupTransactionDO);
    }
}
