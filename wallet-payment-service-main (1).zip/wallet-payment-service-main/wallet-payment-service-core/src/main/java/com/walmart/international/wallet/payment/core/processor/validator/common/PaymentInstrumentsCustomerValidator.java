package com.walmart.international.wallet.payment.core.processor.validator.common;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.TransactionRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@Slf4j
public class PaymentInstrumentsCustomerValidator implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        TransactionRequestDomainContext transactionRequestDomainContext = (TransactionRequestDomainContext) wpsRequestDomainContext;

        Customer customer = transactionRequestDomainContext.getTransaction().getCustomer();
        if (Objects.isNull(customer.getCustomerAccountId())) {
            throw new BusinessValidationException(ErrorConstants.FetchPaymentInstruments.CUSTOMER_ACCOUNT_ID_NULL);
        }
        return true;
    }
}