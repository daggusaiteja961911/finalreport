package com.walmart.international.wallet.payment.core.config;

import com.walmart.international.ewallet.payment.api.PangaeaConfig;
import com.walmart.international.ewallet.payment.api.PaymentBrokerConfig;
import com.walmart.international.ewallet.payment.api.dto.FraudCheckDetails;
import com.walmart.international.wallet.payment.core.config.ccm.PangaeaConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentBrokerConfiguration;
import com.walmart.kafka.producer.KafkaDRProducer;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class PaymentProviderCCMConfigs {

    @Autowired
//    @Qualifier("pbRefundRequestProducer")
    private KafkaDRProducer pbRefundRequestProducer;

    @ManagedConfiguration
    private PaymentBrokerConfiguration paymentBrokerConfiguration;

    @ManagedConfiguration
    private PangaeaConfiguration pangaeaConfiguration;

    @Bean
    public PangaeaConfig pangaeaConfig() {
        PangaeaConfig pangaeaConfig = new PangaeaConfig();
        pangaeaConfig.setBaseURL(pangaeaConfiguration.getBaseUrl());
        pangaeaConfig.setBaseURLForVertical102(pangaeaConfiguration.getBaseUrlForVertical102());
        pangaeaConfig.setPaymentMethodId(pangaeaConfiguration.getPaymentMethodId());
        pangaeaConfig.setLocaleId(pangaeaConfiguration.getLocaleId());
        pangaeaConfig.setTenantId(pangaeaConfiguration.getTenantId());
        pangaeaConfig.setTenantIdForVertical102(pangaeaConfiguration.getTenantIdForVertical102());
        pangaeaConfig.setPosVerticalId(pangaeaConfiguration.getPosVerticalId());
        pangaeaConfig.setMerchantVerticalId(pangaeaConfiguration.getMerchantVerticalId());
        pangaeaConfig.setOnlineVerticalId(pangaeaConfiguration.getOnlineVerticalId());
        pangaeaConfig.setSystemVerticalId(pangaeaConfiguration.getSystemVerticalId());
        pangaeaConfig.setAlternateMerchantId(pangaeaConfiguration.getAlternateMerchantId());
        pangaeaConfig.setConsumerId(pangaeaConfiguration.getServiceConsumerId());
        pangaeaConfig.setEnv(pangaeaConfiguration.getEnvironment());
        pangaeaConfig.setServiceName(pangaeaConfiguration.getServiceName());
        pangaeaConfig.setServiceVersion(pangaeaConfiguration.getServiceVersion());
        pangaeaConfig.setServiceKeyVersion(pangaeaConfiguration.getServiceKeyVersion());
        pangaeaConfig.setConnectionTimeoutMillis(pangaeaConfiguration.getWebClientConnectionTimeoutInMillis());
        pangaeaConfig.setResponseTimeoutMillis(pangaeaConfiguration.getWebClientResponseTimeoutInMillis());
        pangaeaConfig.setSaveLogsToDB(pangaeaConfiguration.isSaveLogsToDBEnabled());
        return pangaeaConfig;
    }

    @Bean
    public PaymentBrokerConfig paymentBrokerConfig() {
        PaymentBrokerConfig paymentBrokerConfig = new PaymentBrokerConfig();
        paymentBrokerConfig.setBaseURL(paymentBrokerConfiguration.getBaseUrl());
        paymentBrokerConfig.setConsumerId(paymentBrokerConfiguration.getConsumerId());
        paymentBrokerConfig.setBanner("Cashi");
        paymentBrokerConfig.setSource("Cashi");
        paymentBrokerConfig.setAuthUserName(paymentBrokerConfiguration.getAuthUserName());
        paymentBrokerConfig.setAuthPassword(paymentBrokerConfiguration.getAuthPassword());
        paymentBrokerConfig.setServiceKeyVersion(paymentBrokerConfiguration.getServiceKeyVersion());
        paymentBrokerConfig.setServiceName(paymentBrokerConfiguration.getServiceName());
        paymentBrokerConfig.setApplicationName(paymentBrokerConfiguration.getApplicationName());
        paymentBrokerConfig.setPrivateKey(paymentBrokerConfiguration.getPrivateKey());
        paymentBrokerConfig.setEnv(paymentBrokerConfiguration.getEnvironment());
        paymentBrokerConfig.setLanguage("esp_MEX");
        paymentBrokerConfig.setServiceMeshEnabled(true);
        paymentBrokerConfig.setKafkaDRProducer(pbRefundRequestProducer);
        paymentBrokerConfig.setFraudDetails(FraudCheckDetails.builder().passCutoff("60").failCutoff("40")
                .passwordStatus("R").salesRepId("Website").build());
        paymentBrokerConfig.setClient("cashi.walmart.com.mx");
        paymentBrokerConfig.setUsage("preauth");
        paymentBrokerConfig.setUseoverrides("N");
        paymentBrokerConfig.setRedirectUrl(paymentBrokerConfiguration.getRedirectCashiURL());
        paymentBrokerConfig.setConnectionTimeoutMillis(paymentBrokerConfiguration.getWebClientConnectionTimeoutInMillis());
        paymentBrokerConfig.setResponseTimeoutMillis(paymentBrokerConfiguration.getWebClientResponseTimeoutInMillis());
        paymentBrokerConfig.setSaveLogsToDB(paymentBrokerConfiguration.isSaveLogsToDBEnabled());
        log.info("PaymentBrokerConfig{}", paymentBrokerConfig);
        return paymentBrokerConfig;
    }

}