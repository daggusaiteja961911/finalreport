package com.walmart.international.wallet.payment.core.adapter.kafka.request.refund;

import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.ErrorDetails;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.GatewayDetails;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class RefundKafkaResponseDetails {
    private String paymentBrokerId;
    private String paymentId;
    private GatewayDetails gateway;
    private String creationDate;
    private String operationDate;
    private String cardId;
    private BigDecimal amount;
    private String refundType;
    private String status;
    private String source;
    private Integer retryCount;
    private ErrorDetails error;
    private String paymentBrokerChargeTxnId;
    private String tranType;
}
