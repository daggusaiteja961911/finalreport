package com.walmart.international.wallet.payment.core.adapter.cohort.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.walmart.commons.logging.slf4j.LoggerWrapperFactory;
import lombok.Data;
import org.slf4j.Logger;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerCohort implements Serializable {

    private static final Logger logger = LoggerWrapperFactory.getLogger(CustomerCohort.class);

    private UUID id;

    private UUID customerAccountId;

    private BigDecimal averagePaymentAmount;

    private Integer loadTransactionCount;

    private Integer billPaymentCount;

    private Integer accountPerDevice;

    private Integer nonBillPaymentCount;

    private String recurrentStoreId;

}
