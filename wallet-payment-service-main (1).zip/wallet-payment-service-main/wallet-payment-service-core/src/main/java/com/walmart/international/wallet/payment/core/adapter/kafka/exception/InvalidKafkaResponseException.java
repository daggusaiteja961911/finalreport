package com.walmart.international.wallet.payment.core.adapter.kafka.exception;

import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;

public class InvalidKafkaResponseException extends DataValidationException {

    public InvalidKafkaResponseException(String errorCode) {
        super(errorCode);
    }
}
