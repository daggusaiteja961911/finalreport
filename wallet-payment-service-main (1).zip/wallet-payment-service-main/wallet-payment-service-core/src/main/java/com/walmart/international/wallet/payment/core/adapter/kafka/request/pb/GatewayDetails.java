package com.walmart.international.wallet.payment.core.adapter.kafka.request.pb;

import lombok.Data;

@Data
public class GatewayDetails {
    private String name;
    private String referenceId;
    private String cardReference;
    private String transactionDate;
    private String authorization;
    private String affiliationNumber;
}
