package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WalletAccountDTO {

    public UUID walletAccountId;

    private Date createdDate;

    private Date modifiedDate;

    // list of gift card , credit card , debit cards
    private List<EWSPaymentPreferenceDTO> payments;

    // list of corporate cards of the user
    private List<EWSCorporatePreferenceDTO> corpPreferences;

    private BigDecimal totalBalance;

    private Boolean hasMaxCardLimitReached;

    private Integer maxCardLimit;

    private Boolean redeemListAvailable;
}
