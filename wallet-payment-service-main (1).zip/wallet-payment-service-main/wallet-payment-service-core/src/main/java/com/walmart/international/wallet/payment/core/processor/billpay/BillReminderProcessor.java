package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.notification.utils.EventHelper;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.BillReminderConfiguration;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.service.BillerCoreService;
import com.walmart.international.wallet.payment.data.dao.repository.BillerRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class BillReminderProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private CustomerBillAccountRepository customerBillAccountRepository;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    @ManagedConfiguration
    private BillReminderConfiguration billReminderConfiguration;

    @Autowired
    private BillerRepository billerRepository;

    @Autowired
    private EventHelper eventHelper;

    @Autowired
    private BillerCoreService billerCoreService;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) {

        BillRequestDomainContext billRequestDomainContext = (BillRequestDomainContext) wpsRequestDomainContext;
        BillResponseDomainContext billResponseDomainContext = (BillResponseDomainContext) wpsResponseDomainContext;


        return true;
    }
}
