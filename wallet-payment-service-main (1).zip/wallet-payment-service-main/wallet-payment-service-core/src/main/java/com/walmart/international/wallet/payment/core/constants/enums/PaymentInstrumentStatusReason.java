package com.walmart.international.wallet.payment.core.constants.enums;

public enum PaymentInstrumentStatusReason {
    DELETION_INITIATED,
    DELETION_INTERRUPTED,
    DELETION_FAILED,
    DELETION_SUCCESS;
}
