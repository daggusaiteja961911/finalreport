package com.walmart.international.wallet.payment.core.adapter.tas.response;

import lombok.Data;

import java.io.Serializable;

@Data
public class TxnEventRestConsumptionResponse implements Serializable {
    private static final long serialVersionUID = -8129949679782258137L;

    private String id;
}
