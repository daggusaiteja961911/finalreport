package com.walmart.international.wallet.payment.core.constants.enums.flow;

import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.processor.billpay.BillPayExternalBillProcessor;
import com.walmart.international.wallet.payment.core.processor.billpay.BillPayPaymentInstrumentsFetcher;
import com.walmart.international.wallet.payment.core.processor.billpay.BillPayPaymentInstrumentsWithPreselectionFetcher;
import com.walmart.international.wallet.payment.core.processor.billpay.BillPayPaymentProcessor;
import com.walmart.international.wallet.payment.core.processor.billpay.BillPayPostProcessor;
import com.walmart.international.wallet.payment.core.processor.billpay.BillPayPreProcessor;
import com.walmart.international.wallet.payment.core.processor.billpay.CancelBillPayPreProcessor;
import com.walmart.international.wallet.payment.core.processor.billpay.CreateBillProcessor;
import com.walmart.international.wallet.payment.core.processor.billpay.FetchBillPayPaymentOptionsPopulator;
import com.walmart.international.wallet.payment.core.processor.billpay.UpdateCustomerBillAccountProcessor;
import com.walmart.international.wallet.payment.core.processor.coftopup.CancelCoFTopupPostProcessor;
import com.walmart.international.wallet.payment.core.processor.coftopup.CoFTopupPaymentInstrumentsFetcher;
import com.walmart.international.wallet.payment.core.processor.coftopup.CoFTopupPaymentInstrumentsWithPreselectionFetcher;
import com.walmart.international.wallet.payment.core.processor.coftopup.CoFTopupPostProcessor;
import com.walmart.international.wallet.payment.core.processor.coftopup.CoFTopupPreProcessor;
import com.walmart.international.wallet.payment.core.processor.coftopup.CoFTopupProcessor;
import com.walmart.international.wallet.payment.core.processor.common.CVVLessInspector;
import com.walmart.international.wallet.payment.core.processor.common.OrderPaymentOptions;
import com.walmart.international.wallet.payment.core.processor.payment.CancelCoFTopupProcessor;
import com.walmart.international.wallet.payment.core.processor.validator.billpay.BillPayAMLValidator;
import com.walmart.international.wallet.payment.core.processor.validator.billpay.BillPayValidator;
import com.walmart.international.wallet.payment.core.processor.validator.billpay.CancelBillPayValidator;
import com.walmart.international.wallet.payment.core.processor.validator.billpay.CreateBillInputValidator;
import com.walmart.international.wallet.payment.core.processor.validator.billpay.UpdateCustomerBillAccountInputValidator;
import com.walmart.international.wallet.payment.core.processor.validator.coftopup.CancelCoFTopupValidator;
import com.walmart.international.wallet.payment.core.processor.validator.coftopup.CoFTopupAMLValidator;
import com.walmart.international.wallet.payment.core.processor.validator.coftopup.CoFTopupValidator;
import com.walmart.international.wallet.payment.core.processor.validator.common.PaymentInstrumentsCustomerValidator;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.LinkedList;

@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum MXFlowType implements FlowType<WPSRequestDomainContext, WPSResponseDomainContext> {

    CREATE_BILL("CREATE_BILL",
            new LinkedList<>(Arrays.asList(CreateBillInputValidator.class, CreateBillProcessor.class))),

    UPDATE_CUSTOMER_BILL_ACCOUNT("UPDATE_CUSTOMER_BILL_ACCOUNT",
            new LinkedList<>(Arrays.asList(UpdateCustomerBillAccountInputValidator.class, UpdateCustomerBillAccountProcessor.class))),

    FETCH_COFTOPUP_PAYMENT_INSTRUMENTS("FETCH_COFTOPUP_PAYMENT_INSTRUMENTS",
            new LinkedList<>(Arrays.asList(PaymentInstrumentsCustomerValidator.class, CoFTopupPaymentInstrumentsFetcher.class, CVVLessInspector.class))),

    FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION("FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION",
            new LinkedList<>(Arrays.asList(PaymentInstrumentsCustomerValidator.class, CoFTopupPaymentInstrumentsWithPreselectionFetcher.class,
                    CVVLessInspector.class, OrderPaymentOptions.class))),

    FETCH_BILL_PAY_PAYMENT_INSTRUMENTS("FETCH_BILL_PAY_PAYMENT_INSTRUMENTS",
            new LinkedList<>(Arrays.asList(PaymentInstrumentsCustomerValidator.class, BillPayPaymentInstrumentsFetcher.class,
                    FetchBillPayPaymentOptionsPopulator.class, CVVLessInspector.class))),

    FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION("FETCH_BILL_PAY_PAYMENT_INSTRUMENTS_WITH_PRESELECTION",
            new LinkedList<>(Arrays.asList(PaymentInstrumentsCustomerValidator.class, BillPayPaymentInstrumentsWithPreselectionFetcher.class,
                    FetchBillPayPaymentOptionsPopulator.class, CVVLessInspector.class, OrderPaymentOptions.class))),

    COF_TOPUP("COF_TOPUP",
            new LinkedList<>(Arrays.asList(CoFTopupValidator.class, CoFTopupAMLValidator.class, CoFTopupPreProcessor.class,
                    CoFTopupProcessor.class, CoFTopupPostProcessor.class))),

    VALIDATE_COF_TOPUP("VALIDATE_COF_TOPUP",
            new LinkedList<>(Arrays.asList(CoFTopupPreProcessor.class, CoFTopupProcessor.class, CoFTopupPostProcessor.class))),

    PAY_BILL_INIT("PAY_BILL_INIT",
            new LinkedList<>(Arrays.asList(BillPayValidator.class, BillPayAMLValidator.class, BillPayPreProcessor.class))),

    PAY_BILL("PAY_BILL",
            new LinkedList<>(Arrays.asList(BillPayPaymentProcessor.class, BillPayExternalBillProcessor.class, BillPayPostProcessor.class))),

    VALIDATE_CHARGE_INIT("VALIDATE_CHARGE_INIT",
            new LinkedList<>(Arrays.asList(BillPayPreProcessor.class))),

    CANCEL_COF_TOPUP("CANCEL_COF_TOPUP",
            new LinkedList<>(Arrays.asList(CancelCoFTopupValidator.class, CancelCoFTopupProcessor.class, CancelCoFTopupPostProcessor.class))),

    CANCEL_PAY_BILL_INIT("CANCEL_PAY_BILL_INIT",
            new LinkedList<>(Arrays.asList(CancelBillPayValidator.class, CancelBillPayPreProcessor.class)));

    private String flowName;

    private LinkedList<Class<? extends IProcessor<WPSRequestDomainContext, WPSResponseDomainContext>>> flow;
}
