package com.walmart.international.wallet.payment.core.processor.validator.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.validator.Validator;
import com.walmart.international.wallet.payment.core.config.ccm.AMLConfig;
import com.walmart.international.wallet.payment.core.constants.enums.AMLValidationType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.AMLValidationRequest;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.service.AMLValidationService;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.commons.collections.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class BillPayAMLValidator implements Validator<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private AMLValidationService amlValidationService;

    @ManagedConfiguration
    private AMLConfig amlConfiguration;

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Override
    public boolean validate(WPSRequestDomainContext wpsRequestDomainContext) throws ApplicationException {
        BillPayTxnRequestDomainContext billPayTxnRequestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BigDecimal amountRequested = Objects.nonNull(billPayTxnRequestDomainContext.getTransaction().getAmountRequested().getValue()) ? billPayTxnRequestDomainContext.getTransaction().getAmountRequested().getValue() : BigDecimal.ZERO;
        UUID customerAccountId = billPayTxnRequestDomainContext.getTransaction().getCustomer().getCustomerAccountId();
        AMLValidationRequest amlValidationRequest = AMLValidationRequest.builder().amlValidationType(AMLValidationType.PAY)
                .requestId(billPayTxnRequestDomainContext.getClientRequestId())
                .customerAccountId(customerAccountId)
                .amount(amountRequested)
                .build();

        if (amlConfiguration.amlEvaluationEnabled() && BigDecimal.ZERO.compareTo(amountRequested) != 0) {
            log.info("Evaluating AML check for transactionId[{}] and customerId:[{}]", billPayTxnRequestDomainContext.getTransaction().getTransactionId(), customerAccountId);
            try {
                amlValidationService.validateAMLChecks(amlValidationRequest);
            } catch (BusinessValidationException bve) {
                log.error("AML validation failed for BillPayTransaction with txnId:[{}] for customerAccountId[{}]", billPayTxnRequestDomainContext.getTransaction().getTransactionId(), customerAccountId);
                createBillPayTransactionInValidationFailureState(billPayTxnRequestDomainContext);
                throw bve;
            }
        }
        log.info("Validated AML restriction for BillPayTransaction with txnId:[{}] for customerAccountId[{}]", billPayTxnRequestDomainContext.getTransaction().getTransactionId(), customerAccountId);
        return true;
    }

    private void createBillPayTransactionInValidationFailureState(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransactionDO billPayTransactionDO = BillPayUtil.createBillPayTransactionDOInValidationFailureState(billPayTxnRequestDomainContext);
        billPayTransactionRepository.save(billPayTransactionDO);
    }
}
