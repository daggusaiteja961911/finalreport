package com.walmart.international.wallet.payment.core.domain.model;

import java.util.Objects;

public class DeviceAppVersion implements Comparable<DeviceAppVersion> {

    private String version;

    public final String get() {
        return this.version;
    }

    public DeviceAppVersion(String version) {
        if (Objects.isNull(version))
            throw new IllegalArgumentException("Version can not be null");
        if (!version.matches("[0-9]+(\\.[0-9]+)*"))
            throw new IllegalArgumentException("Invalid version format");
        this.version = version;
    }

    @Override
    public int compareTo(DeviceAppVersion that) {
        if (Objects.isNull(that))
            return 1;
        String[] thisParts = this.get().split("\\.");
        String[] thatParts = that.get().split("\\.");
        int length = Math.max(thisParts.length, thatParts.length);
        for (int i = 0; i < length; i++) {
            int thisPart = i < thisParts.length ?
                    Integer.parseInt(thisParts[i]) : 0;
            int thatPart = i < thatParts.length ?
                    Integer.parseInt(thatParts[i]) : 0;
            if (thisPart < thatPart)
                return -1;
            if (thisPart > thatPart)
                return 1;
        }
        return 0;
    }
}
