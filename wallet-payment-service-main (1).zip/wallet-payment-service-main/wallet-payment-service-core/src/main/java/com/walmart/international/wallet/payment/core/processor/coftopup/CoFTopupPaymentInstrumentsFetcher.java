package com.walmart.international.wallet.payment.core.processor.coftopup;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentType;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstruments;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopupPaymentOptions;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class CoFTopupPaymentInstrumentsFetcher implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    ICustomerServiceClient customerServiceClient;

    CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext = (CoFTopupTxnRequestDomainContext) wpsRequestDomainContext;
        CoFTopupTxnResponseDomainContext cofTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;
        UUID customerAccountId = cofTopupTxnRequestDomainContext.getTransaction().getCustomer().getCustomerAccountId();
        WalletResponse paymentInstrumentResponse = customerServiceClient.getPaymentInstruments(customerAccountId);
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = paymentInstrumentResponse.getPaymentInstruments();
        List<CardPaymentInstrument> cardPaymentInstruments = getCardPaymentInstruments(paymentInstrumentList);
        sortPaymentInstrument(cardPaymentInstruments);
        cofTopupTxnResponseDomainContext.setTransaction(CoFTopUpTransaction.builder()
                .cofTopupPaymentOptions(CoFTopupPaymentOptions.builder()
                        .cardPaymentInstruments(CardPaymentInstruments.builder()
                                .cardPaymentInstrumentList(cardPaymentInstruments)
                                .build())
                        .build())
                .build());
        return true;
    }

    private List<CardPaymentInstrument> getCardPaymentInstruments(List<WalletResponse.PaymentInstrument> paymentInstrumentList) {
        List<CardPaymentInstrument> cardPaymentInstruments = new ArrayList<>();
        for (WalletResponse.PaymentInstrument paymentInstrument : paymentInstrumentList) {
            if (PaymentInstrumentType.CARD.name().equals(paymentInstrument.getPaymentInstrumentType().name())) {
                cardPaymentInstruments.add(customerMapper.mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument));
            }
        }
        return cardPaymentInstruments;
    }

    public void sortPaymentInstrument(List<CardPaymentInstrument> paymentInstruments) {
        paymentInstruments.sort(new WalletPaymentServiceUtil.CardPaymentInstrumentListSortingComparator());
    }
}
