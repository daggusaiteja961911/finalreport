package com.walmart.international.wallet.payment.core.processor.validator.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@Slf4j
public class UpdateCustomerBillAccountInputValidator implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillRequestDomainContext billRequestDomainContext = (BillRequestDomainContext) wpsRequestDomainContext;

        CustomerBillAccount customerBillAccount = billRequestDomainContext.getCustomerBillAccount();
        if (Objects.isNull(customerBillAccount.getCustomerBillAccountId())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_ID_NULL);
        }

        if (Objects.isNull(customerBillAccount.getCustomerAccountId())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_ACCOUNT_ID_NULL);
        }
        return true;
    }
}
