package com.walmart.international.wallet.payment.core.config;

import com.walmart.international.digiwallet.service.basic.encryption.PIIEncryption;
import com.walmart.international.digiwallet.service.basic.util.CommonUtils;
import com.walmart.international.wallet.payment.core.config.ccm.DatabaseConfiguration;
import com.zaxxer.hikari.HikariDataSource;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.tunr.utils.client.ServiceConfigClientFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@Slf4j
public class JpaConfig {

    private static final String KEY_DB_USERNAME = "db.username";
    private static final String KEY_DB_PW = "db.password";

    @ManagedConfiguration
    private DatabaseConfiguration databaseConfiguration;

    @Bean
    @Primary
    public DataSource getDataSource() {
        Properties dbProperties = CommonUtils.getProperties(PIIEncryption.getSecretPath());
        if (null == databaseConfiguration) {
            databaseConfiguration = ServiceConfigClientFactory.getInstance()
                    .getServiceConfigVersionCache()
                    .getResolvedConfiguration(DatabaseConfiguration.CCM_ENTRY_NAME, DatabaseConfiguration.class, null);
        }
        HikariDataSource hikariDataSource = new HikariDataSource();
        hikariDataSource.setUsername(dbProperties.getProperty(KEY_DB_USERNAME));
        hikariDataSource.setPassword(dbProperties.getProperty(KEY_DB_PW));
        hikariDataSource.setJdbcUrl(databaseConfiguration.getJdbcUrl());
        hikariDataSource.setDriverClassName(databaseConfiguration.getDriver());
        hikariDataSource.setMaximumPoolSize(databaseConfiguration.getMaxPoolSize());
        hikariDataSource.setConnectionTimeout(databaseConfiguration.getConnectionTimeoutMs());
        hikariDataSource.setMaxLifetime(databaseConfiguration.getMaxLifetimeMs());
        hikariDataSource.setIdleTimeout(databaseConfiguration.getIdleTimeoutMs());
        return hikariDataSource;
    }
}