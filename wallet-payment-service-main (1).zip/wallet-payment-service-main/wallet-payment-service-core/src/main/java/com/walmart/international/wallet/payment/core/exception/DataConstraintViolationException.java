package com.walmart.international.wallet.payment.core.exception;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;

public class DataConstraintViolationException extends BusinessValidationException {

    public DataConstraintViolationException(String errorCode) {
        super(errorCode);
    }

    public DataConstraintViolationException(String errorCode, String message) {
        super(errorCode, message);
    }

    public DataConstraintViolationException(String errorCode, String message, Object[] args) {
        super(errorCode, message, args);
    }

    public DataConstraintViolationException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, cause);
    }

    public DataConstraintViolationException(String errorCode, String message, Object[] args, Throwable cause) {
        super(errorCode, message, args, cause);
    }
}
