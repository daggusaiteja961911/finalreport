package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

import java.util.List;

@Configuration(configName = BillPaymentConfiguration.CCM_ENTRY_NAME)
public interface BillPaymentConfiguration {
    String CCM_ENTRY_NAME = "bill-payment-config";

    @Property(propertyName = "b2b.for.split.allowed")
    Boolean getAllowB2BForSplitPayment();

    @Property(propertyName = "msi.for.split.allowed")
    Boolean getAllowMSIForSplitPayment();

    @Property(propertyName = "cof.allowed")
    Boolean getAllowCoF();

    @Property(propertyName = "multiple.b2b.for.split.allowed")
    Boolean getAllowMultipleB2BForSplitPayment();

    @Property(propertyName = "allowCoFBillPayment.android.min.version")
    String getAndroidMinVersionForCoFBillPayment();

    @Property(propertyName = "allowCoFBillPayment.ios.min.version")
    String getIOSMinVersionForCoFBillPayment();

    @Property(propertyName = "polling.interval")
    List<Integer> getBillPaymentPollingInterval();

}