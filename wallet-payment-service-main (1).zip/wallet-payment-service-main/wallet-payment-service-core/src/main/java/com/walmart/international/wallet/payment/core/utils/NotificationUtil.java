package com.walmart.international.wallet.payment.core.utils;

import com.walmart.international.notification.constants.MessagingEvent;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataActionStatus;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataCategory;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataDetails;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataStatus;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import io.strati.libs.commons.lang.StringUtils;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class NotificationUtil {

    public static NOCMetaDataDetails getNOCMetaData(@NonNull MessagingEvent messagingEvent, String action, String transactionId, Long expiryTimeInMillis) {
        NOCMetaDataCategory category = getCategory(messagingEvent);
        return NOCMetaDataDetails.builder()
                .category(category)
                .status(getStatus(messagingEvent))
                .actionStatus(getActionStatus(action))
                .categoryImageUrl(category == null ? null : category.getImageUrl())
                // TODO: compare this against action field
                .isActionable(!StringUtils.isEmpty(action))
                .transactionId(transactionId)
                .expiryBy(expiryTimeInMillis)
                .build();
    }

    public static NOCMetaDataStatus getStatus(MessagingEvent messagingEvent) {
        NOCMetaDataStatus status = null;
        switch (messagingEvent){
            case ACCOUNT_LOCKED:
                status = NOCMetaDataStatus.INFORMATIONAL;
                break;

            default:
                break;
        }

        return status;
    }

    public static NOCMetaDataCategory getCategory(@NonNull MessagingEvent messagingEvent) {
        NOCMetaDataCategory category = null;
        switch (messagingEvent) {
            case ACCOUNT_LOCKED:
                category = NOCMetaDataCategory.GENERIC_FAILURE;
                break;

            default:
                break;
        }

        return category;
    }

    public static NOCMetaDataActionStatus getActionStatus(String status) {
        NOCMetaDataActionStatus actionStatus = null;
        switch (status) {
            case WPSConstants.Notification.ACTION_CALL_HELP:
                actionStatus = NOCMetaDataActionStatus.NON_ACTIONABLE;
                break;

            default:
                break;
        }
        return actionStatus;
    }

    public static String getDeepLink(@NonNull String action, String txnId) {
        switch (action) {
            case WPSConstants.Notification.OPEN_CUSTOMER_SUPPORT:
                return "cashi://deeplink?action=" + action;
            case WPSConstants.Notification.SHOW_BONUS_HOME_SCREEN:
                return "cashi://deeplink?action=" + action;
            case WPSConstants.Notification.SHOW_PAYMENT_DETAILS:
                return "cashi://deeplink?action=" + action + "&code=" + txnId;
            case WPSConstants.Notification.SHOW_TRANSACTION:
                return "cashi://deeplink?action=showTransaction&code=" + txnId;
            case WPSConstants.Notification.OPEN_HOME:
                return "cashi://deeplink?action=" + action;
            default:
                log.error("Action did not match");
        }
        return null;
    }

}
