package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class GiftCardTransaction {
    private UUID paymentInstrumentId;
    private Amount amount;
    private GiftCardTransactionType giftCardTransactionType;
    private GiftCardPaymentInstrument giftCardPaymentInstrument;
    private GiftCardSubTransaction giftCardSubTransaction;

}
