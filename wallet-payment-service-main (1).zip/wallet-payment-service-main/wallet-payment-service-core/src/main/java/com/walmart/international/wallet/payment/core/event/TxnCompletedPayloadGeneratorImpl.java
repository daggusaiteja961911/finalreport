package com.walmart.international.wallet.payment.core.event;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.EventType;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.GCTransactionType;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.PayloadContentType;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.PaymentInstrument;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TransactionEventDTO;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TxnCompletedEventPayload;
import com.walmart.international.notification.txnaggregator.TxnCompletedPayloadGenerator;
import com.walmart.international.notification.utils.EventPayloadUtil;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.response.GetTxnDetailResponse;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentBrokerConfiguration;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.Transaction;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.mapper.TxnCompletedPayloadMapper;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class TxnCompletedPayloadGeneratorImpl extends TxnCompletedPayloadGenerator {

    @Autowired
    private PaymentCoreService paymentCoreService;

    @ManagedConfiguration
    private PaymentBrokerConfiguration paymentBrokerConfiguration;

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    private TxnCompletedPayloadMapper txnCompletedPayloadMapper = TxnCompletedPayloadMapper.INSTANCE;

    private CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @Override
    public EventPayload generatePayload(Object payloadRef, String correlationId) {
        EventPayload eventPayload = null;
        if (payloadRef instanceof Transaction) {
            Transaction transaction = (Transaction) payloadRef;
            eventPayload = createPayloadFromTransaction(transaction);
        } else if (payloadRef instanceof CoFTopupTransactionDO) {
            CoFTopupTransactionDO coFTopupTransactionDO = (CoFTopupTransactionDO) payloadRef;
            eventPayload = generatePayloadForCoFTopupTransaction(coFTopupTransactionDO);
            if (Objects.isNull(eventPayload)) {
                log.error("Event payload is null, skipping txn aggregator payload creation for customerAccountId: [{}] and transactionId: [{}[",
                        coFTopupTransactionDO.getCustomerAccountId(), coFTopupTransactionDO.getCoFTopupTransactionId());
            }
        } else if (payloadRef instanceof BillPayTransactionDO) {
            BillPayTransactionDO billPayTransactionDO = (BillPayTransactionDO) payloadRef;
            eventPayload = generatePayloadForBillPayTransaction(billPayTransactionDO);
            if (Objects.isNull(eventPayload)) {
                log.error("Event payload is null, skipping txn aggregator payload creation for customerAccountId: [{}] and transactionId: [{}[",
                        billPayTransactionDO.getCustomerAccountId(), billPayTransactionDO.getBillPayTransactionId());
            }
        }
        return eventPayload;
    }

    private EventPayload createPayloadFromTransaction(Transaction transaction) {
        EventPayload eventPayload = null;
        try {
            if (transaction instanceof CoFTopUpTransaction) {
                eventPayload = generatePayloadForCoFTopupTransaction((CoFTopUpTransaction) transaction);
            } else if (transaction instanceof BillPayTransaction) {
                eventPayload = generatePayloadForBillPayTransaction((BillPayTransaction) transaction);
            }
            if (Objects.isNull(eventPayload)) {
                log.error("Event payload is null, skipping txn aggregator payload creation for customerAccountId: [{}] and transactionId: [{}[",
                        transaction.getCustomer().getCustomerAccountId(), transaction.getTransactionId());
            }
        } catch (Exception ex) {
            log.error("Error while preparing txn aggregator payload for customerAccountId : {} and transactionId : {}. StackTrace: {}",
                    transaction.getCustomer().getCustomerAccountId(), transaction.getTransactionId(), ExceptionUtils.getStackTrace(ex));
        }
        return eventPayload;
    }

    private EventPayload generatePayloadForCoFTopupTransaction(CoFTopUpTransaction coFTopUpTransaction) {
        try {
            EventPayload eventPayload = EventPayloadUtil.getBasicPayload(EventType.TXN_COMPLETED.getType(), WPSConstants.Common.APPLICATION_NAME, PayloadContentType.JSON);
            TransactionEventDTO transactionEventDTO = txnCompletedPayloadMapper.mapCoFTopupTransactionToTransactionEvent(coFTopUpTransaction);
            TxnCompletedEventPayload txnCompletedEventPayload = new TxnCompletedEventPayload();
            txnCompletedEventPayload.setTransactionEvent(transactionEventDTO);
            eventPayload.setData(txnCompletedEventPayload);
            return eventPayload;
        } catch (Exception ex) {
            log.error("Error while generating payload for coFTopUpTransaction with id[{}]. StackTrace: [{}]", coFTopUpTransaction.getTransactionId(), ExceptionUtils.getStackTrace(ex));
            return null;
        }
    }

    private EventPayload generatePayloadForCoFTopupTransaction(CoFTopupTransactionDO coFTopupTransactionDO) {
        try {
            EventPayload eventPayload = EventPayloadUtil.getBasicPayload(EventType.TXN_COMPLETED.getType(), WPSConstants.Common.APPLICATION_NAME, PayloadContentType.JSON);
            TransactionEventDTO transactionEventDTO = txnCompletedPayloadMapper.mapCoFTopupTransactionDOToTransactionEvent(coFTopupTransactionDO);
            if (Objects.nonNull(coFTopupTransactionDO.getTxnReferenceId())) {
                Optional<BillPayTransactionDO> billPayTransactionDOOptional = billPayTransactionRepository.findById(UUID.fromString(coFTopupTransactionDO.getTxnReferenceId()));
                billPayTransactionDOOptional.ifPresent(billPayTransactionDO -> transactionEventDTO.setDeviceId(billPayTransactionDO.getDeviceId()));
            }
            transactionEventDTO.setPaymentInstruments(mapPaymentInstrumentsForCoFTopupTransaction(coFTopupTransactionDO));
            TxnCompletedEventPayload txnCompletedEventPayload = new TxnCompletedEventPayload();
            txnCompletedEventPayload.setTransactionEvent(transactionEventDTO);
            eventPayload.setData(txnCompletedEventPayload);
            return eventPayload;
        } catch (Exception ex) {
            log.error("Error while generating payload for coFTopUpTransaction with id[{}]. StackTrace: [{}]", coFTopupTransactionDO.getCoFTopupTransactionId(), ExceptionUtils.getStackTrace(ex));
            return null;
        }
    }

    private List<PaymentInstrument> mapPaymentInstrumentsForCoFTopupTransaction(CoFTopupTransactionDO coFTopupTransactionDO) throws PaymentCoreServiceException {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList = customerServiceClient.getPaymentInstruments(coFTopupTransactionDO.getCustomerAccountId()).getPaymentInstruments();

        String clientTransactionIdForPay = String.join("_", String.valueOf(coFTopupTransactionDO.getCoFTopupTransactionId()), "1");
        String clientTransactionIdForLoad = String.join("_", String.valueOf(coFTopupTransactionDO.getCoFTopupTransactionId()), "2");
        Map<String, GetTxnDetailResponse> coreTransactionDetailMap = paymentCoreService.getTransactionDetailForClientTransactionIds(Arrays.asList(clientTransactionIdForPay, clientTransactionIdForLoad));
        if (Objects.isNull(coreTransactionDetailMap) || coreTransactionDetailMap.isEmpty()) {
            return Collections.emptyList();
        }

        Optional<GetTxnDetailResponse.CoreTransaction> oCoreTransactionForPay = Optional.empty();
        Optional<GetTxnDetailResponse.CoreTransaction> oCoreTransactionForLoad = Optional.empty();
        if (Objects.nonNull(coreTransactionDetailMap.get(clientTransactionIdForPay))) {
            oCoreTransactionForPay = Optional.ofNullable(coreTransactionDetailMap.get(clientTransactionIdForPay).getCoreTransactions().get(0));
        }
        if (Objects.nonNull(coreTransactionDetailMap.get(clientTransactionIdForLoad))) {
            oCoreTransactionForLoad = Optional.ofNullable(coreTransactionDetailMap.get(clientTransactionIdForLoad).getCoreTransactions().get(0));
        }
        if (oCoreTransactionForPay.isEmpty() && oCoreTransactionForLoad.isEmpty()) {
            return Collections.emptyList();
        }

        if (oCoreTransactionForPay.isPresent()) {
            GetTxnDetailResponse.CoreTransaction coreTransactionForPay = oCoreTransactionForPay.get();
            if (CollectionUtils.isNotEmpty(coreTransactionForPay.getCardSubTransactions())) {
                for (GetTxnDetailResponse.CardSubTransactionDetail cardSubTransactionDetail : coreTransactionForPay.getCardSubTransactions()) {
                    PaymentInstrument paymentInstrument = getPaymentInstrumentForCardSubTransactionDetail(cardSubTransactionDetail, customerPaymentInstrumentList);
                    paymentInstruments.add(paymentInstrument);
                }
            }
        }

        if (oCoreTransactionForLoad.isPresent()) {
            GetTxnDetailResponse.CoreTransaction coreTransactionForLoad = oCoreTransactionForLoad.get();
            if (CollectionUtils.isNotEmpty(coreTransactionForLoad.getGiftCardSubTransactions())) {
                for (GetTxnDetailResponse.GiftCardSubTransactionDetail giftCardSubTransactionDetail : coreTransactionForLoad.getGiftCardSubTransactions()) {
                    PaymentInstrument paymentInstrument = getPaymentInstrumentForGiftCardSubTransactionDetail(giftCardSubTransactionDetail, customerPaymentInstrumentList);
                    paymentInstrument.setTransactionType(GCTransactionType.ADD_BALANCE);
                    paymentInstruments.add(paymentInstrument);
                }
            }
        }

        return paymentInstruments;
    }

    private List<PaymentInstrument> mapPaymentInstrumentsForBillPayTransaction(BillPayTransactionDO billPayTransactionDO) throws PaymentCoreServiceException {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList = customerServiceClient.getPaymentInstruments(billPayTransactionDO.getCustomerAccountId()).getPaymentInstruments();

        String clientTransactionId = billPayTransactionDO.getBillPayTransactionId().toString();
        GetTxnDetailResponse coreTransactionDetail = paymentCoreService.getTransactionDetail(clientTransactionId);
        if (Objects.isNull(coreTransactionDetail)) {
            return Collections.emptyList();
        }

        Optional<GetTxnDetailResponse.CoreTransaction> oCoreTransaction = Optional.ofNullable(coreTransactionDetail.getCoreTransactions().get(0));
        if (oCoreTransaction.isEmpty()) {
            return Collections.emptyList();
        }

        if (CollectionUtils.isNotEmpty(oCoreTransaction.get().getCardSubTransactions())) {
            for (GetTxnDetailResponse.CardSubTransactionDetail cardSubTransactionDetail : oCoreTransaction.get().getCardSubTransactions()) {
                PaymentInstrument paymentInstrument = getPaymentInstrumentForCardSubTransactionDetail(cardSubTransactionDetail, customerPaymentInstrumentList);
                paymentInstruments.add(paymentInstrument);
            }
        }

        if (CollectionUtils.isNotEmpty(oCoreTransaction.get().getGiftCardSubTransactions())) {
            for (GetTxnDetailResponse.GiftCardSubTransactionDetail giftCardSubTransactionDetail : oCoreTransaction.get().getGiftCardSubTransactions()) {
                PaymentInstrument paymentInstrument = getPaymentInstrumentForGiftCardSubTransactionDetail(giftCardSubTransactionDetail, customerPaymentInstrumentList);
                paymentInstrument.setTransactionType(GCTransactionType.AUTHORIZE);
                paymentInstruments.add(paymentInstrument);
            }
        }

        return paymentInstruments;
    }

    private PaymentInstrument getPaymentInstrumentForCardSubTransactionDetail(GetTxnDetailResponse.CardSubTransactionDetail cardSubTransactionDetail,
                                                                              List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList) {
        PaymentInstrument paymentInstrument = txnCompletedPayloadMapper.mapToPaymentInstrumentFromCardSubTransactionDetail(cardSubTransactionDetail);
        CardPaymentInstrument cardPaymentInstrument = getCardPaymentInstrumentUsedInCardSubTransaction(customerPaymentInstrumentList, cardSubTransactionDetail.getPaymentProviderInstrumentId());
        if (Objects.nonNull(cardPaymentInstrument)) {
            paymentInstrument.setPaymentPreference(txnCompletedPayloadMapper.mapToPaymentPreferenceFromCardPaymentInstrument(cardPaymentInstrument));
        }
        paymentInstrument.setRedirectUrl(paymentBrokerConfiguration.getRedirectCashiURL());
        paymentInstrument.setTimeoutMinsFor3ds(paymentBrokerConfiguration.getTimeoutMinsFor3ds());
        return paymentInstrument;
    }

    private PaymentInstrument getPaymentInstrumentForGiftCardSubTransactionDetail(GetTxnDetailResponse.GiftCardSubTransactionDetail giftCardSubTransactionDetail,
                                                                                  List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList) {
        PaymentInstrument paymentInstrument = txnCompletedPayloadMapper.mapToPaymentInstrumentFromGiftCardSubTransactionDetail(giftCardSubTransactionDetail);
        GiftCardPaymentInstrument giftCardPaymentInstrument = getGiftCardPaymentInstrumentUsedInGiftCardSubTransaction(customerPaymentInstrumentList, giftCardSubTransactionDetail.getPaymentProviderInstrumentId());
        if (Objects.nonNull(giftCardPaymentInstrument)) {
            paymentInstrument.setParentPaymentPreferenceId(giftCardPaymentInstrument.getParentPaymentPreferenceId());
            paymentInstrument.setPaymentPreference(txnCompletedPayloadMapper.mapToPaymentPreferenceFromGiftCardPaymentInstrument(giftCardPaymentInstrument));
        }
        return paymentInstrument;
    }

    private GiftCardPaymentInstrument getGiftCardPaymentInstrumentUsedInGiftCardSubTransaction(List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList, String paymentProviderInstrumentId) {
        for (WalletResponse.PaymentInstrument paymentInstrument : customerPaymentInstrumentList) {
            if (Objects.nonNull(paymentInstrument.getAdapterMetadata().getPiHash()) &&
                    paymentInstrument.getAdapterMetadata().getPiHash().equals(paymentProviderInstrumentId)) {
                return customerMapper.mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument);
            }
        }
        return null;
    }

    private CardPaymentInstrument getCardPaymentInstrumentUsedInCardSubTransaction(List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList, String paymentProviderInstrumentId) {
        for (WalletResponse.PaymentInstrument paymentInstrument : customerPaymentInstrumentList) {
            if (Objects.nonNull(paymentInstrument.getAdapterMetadata().getTokenId()) &&
                    paymentInstrument.getAdapterMetadata().getTokenId().equals(paymentProviderInstrumentId)) {
                return customerMapper.mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument);
            }
        }
        return null;
    }

    private EventPayload generatePayloadForBillPayTransaction(BillPayTransaction billPayTransaction) {
        try {
            EventPayload eventPayload = EventPayloadUtil.getBasicPayload(EventType.TXN_COMPLETED.getType(), WPSConstants.Common.APPLICATION_NAME, PayloadContentType.JSON);
            TransactionEventDTO transactionEventDTO = txnCompletedPayloadMapper.mapBillPayTransactionToTransactionEvent(billPayTransaction);
            TxnCompletedEventPayload txnCompletedEventPayload = new TxnCompletedEventPayload();
            txnCompletedEventPayload.setTransactionEvent(transactionEventDTO);
            eventPayload.setData(txnCompletedEventPayload);
            return eventPayload;
        } catch (Exception ex) {
            log.error("Error while generating payload for billPayTransaction with id[{}]. StackTrace: [{}]", billPayTransaction.getTransactionId(), ExceptionUtils.getStackTrace(ex));
            return null;
        }
    }

    private EventPayload generatePayloadForBillPayTransaction(BillPayTransactionDO billPayTransactionDO) {
        try {
            EventPayload eventPayload = EventPayloadUtil.getBasicPayload(EventType.TXN_COMPLETED.getType(), WPSConstants.Common.APPLICATION_NAME, PayloadContentType.JSON);
            TransactionEventDTO transactionEventDTO = txnCompletedPayloadMapper.mapBillPayTransactionDOToTransactionEvent(billPayTransactionDO);
            transactionEventDTO.setPaymentInstruments(mapPaymentInstrumentsForBillPayTransaction(billPayTransactionDO));
            TxnCompletedEventPayload txnCompletedEventPayload = new TxnCompletedEventPayload();
            txnCompletedEventPayload.setTransactionEvent(transactionEventDTO);
            eventPayload.setData(txnCompletedEventPayload);
            return eventPayload;
        } catch (Exception ex) {
            log.error("Error while generating payload for coFTopUpTransaction with id[{}]. StackTrace: [{}]", billPayTransactionDO.getBillPayTransactionId(), ExceptionUtils.getStackTrace(ex));
            return null;
        }
    }
}
