package com.walmart.international.wallet.payment.core.event.payload;

import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PayBillInitEventPayload {
    private BillPayTxnRequestDomainContext billPayTxnRequestDomainContext;
    private BillPayTxnResponseDomainContext billPayTxnResponseDomainContext;
}
