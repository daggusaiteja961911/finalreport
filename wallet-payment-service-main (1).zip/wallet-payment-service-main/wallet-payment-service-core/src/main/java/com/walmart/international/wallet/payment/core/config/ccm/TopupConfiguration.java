package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "topup-config")
public interface TopupConfiguration {

    @Property(propertyName = "cof.topup.wallet.enabled")
    Boolean getCoFTopupToWalletEnabled();

    @Property(propertyName = "cof.topup.wallet.min.amount")
    Double getCoFTopupToWalletMinAmount();

    @Property(propertyName = "cof.topup.wallet.bill.pay.min.amount")
    Double getCoFTopupToWalletMinAmountForBillPay();

    @Property(propertyName = "cof.topup.wallet.merchant.pay.min.amount")
    Double getCoFTopupToWalletMinAmountForMerchantPay();

    @Property(propertyName = "send.cof.topup.confirmation.email")
    Boolean getSendCoFTopupConfirmationEmail();

    @Property(propertyName = "topup.max.wallet.balance.allowed")
    Double getMaxWalletBalanceAllowed();
}
