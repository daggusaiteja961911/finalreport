package com.walmart.international.wallet.payment.core.adapter.kafka.service;

import com.walmart.international.ewallet.services.events.WalletEventService;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.dto.accounting.AccountingEventType;
import com.walmart.international.notification.dto.accounting.AccountingPayload;
import com.walmart.international.notification.utils.EventHelper;
import com.walmart.international.services.payment.core.dto.CardTransactionDTO;
import com.walmart.international.services.payment.core.model.CoreTransactionDO;
import com.walmart.international.wallet.payment.core.adapter.kafka.accounting.BillPayAccountingPayloadGenerator;
import com.walmart.international.wallet.payment.core.adapter.kafka.accounting.CoFTopupAccountingPayloadGenerator;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.InvalidKafkaPayloadException;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.TransactionType;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class DataCommunicationService {

    @Autowired
    private BillPayAccountingPayloadGenerator billPayAccountingPayloadGenerator;

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;


    @Autowired
    private CoFTopupAccountingPayloadGenerator coFTopupAccountingPayloadGenerator;

    @Autowired
    private WalletEventService<AccountingPayload> eventService;

    @Autowired
    private EventHelper eventHelper;

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;


    public void sendAccountingMessage(AccountingEventType eventType, String orderId,
                                      CardTransactionDTO cardTransactionDetails, TransactionType transactionType) {

        AccountingPayload accountingPayload = null;
        if (transactionType.equals(TransactionType.BILL)) {
            accountingPayload = billPayAccountingPayloadGenerator.generatePayload(eventType, orderId, cardTransactionDetails);
        } else if (transactionType.equals(TransactionType.COF)) {
            accountingPayload = coFTopupAccountingPayloadGenerator.generatePayload(eventType, orderId, cardTransactionDetails);
        }

        if (accountingPayload != null) {
            eventService.raiseEvent(WPSConstants.Event.ACCOUNTING_EVENT, accountingPayload);
        }

    }

    /**
     * Raises TXN_COMPLETED event for bill pay or Cof type transaction
     *
     * @param cardTransactionDO
     * @param transactionType
     */
    public <T> void raiseTxnAggregatorEvent(CardTransactionDTO cardTransactionDO, TransactionType transactionType) {
        UUID transactionId = null;
        Optional<T> transactionDO = null;
        try {
            transactionId = getTransactionIdFromCardTransaction(cardTransactionDO.getCoreTransaction().getClientTransactionId());
            transactionDO = getTransactionBasedOnTransactionType(transactionType, transactionId);
        } catch (Exception ex) {
            log.error("Error occurred while fetching transaction data for publishing txn payload for txnId : {}", transactionId, ex);
            return;
        }

        if (transactionDO.isEmpty())
            throw new InvalidKafkaPayloadException(ErrorConstants.KafkaChargeRecon.TRANSACTION_DOES_NOT_EXIST_IN_SYSTEM);

        eventHelper.publishAsync(transactionId.toString(), transactionDO.get(), WalletEventType.TXN_COMPLETED,
                List.of(com.walmart.international.notification.constants.EventDownstream.TXN_AGGREGATER_SERVICE));

    }

    private <T> Optional<T> getTransactionBasedOnTransactionType(TransactionType transactionType, UUID transactionID) {
        if (transactionType.equals(TransactionType.BILL)) {
            return (Optional<T>) billPayTransactionRepository.findById(transactionID);
        } else if (transactionType.equals(TransactionType.COF)) {
            return (Optional<T>) coFTopupTransactionRepository.findById(transactionID);
        } else {
            throw new InvalidKafkaPayloadException(ErrorConstants.KafkaChargeRecon.INVALID_TRANSACTION_TYPE_FOR_WPS);
        }
    }


    public TransactionType getAccountingTransactionType(CoreTransactionDO coreTransactionDO) {
        UUID transactionId = getTransactionIdFromCardTransaction(coreTransactionDO.getClientTransactionId());

        if (billPayTransactionRepository.doesExistById(transactionId)) {
            return TransactionType.BILL;
        } else {
            //assuming transaction already exists in system and can be only bILL,COF
            return TransactionType.COF;
        }
    }

    private UUID getTransactionIdFromCardTransaction(String clientTransactionID) {
        return UUID.fromString(clientTransactionID.split("_")[0]);
    }
}
