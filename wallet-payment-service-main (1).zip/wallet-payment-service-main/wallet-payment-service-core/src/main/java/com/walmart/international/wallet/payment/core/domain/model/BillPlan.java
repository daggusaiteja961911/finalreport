package com.walmart.international.wallet.payment.core.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillPlan implements Serializable {

    private static final long serialVersionUID = 821448564422721626L;

    private String plan;

    private List<BillDetail> billDetails;
}
