package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EWSPaymentPreferenceDTO {

    private static final long serialVersionUID = -140144552339311156L;

    @NotNull(message = ErrorConstants.PaymentAccept.PAYMENT_ID_REQUIRED)
    private String paymentId;

    private Balance balance;

    private String piHash;

    private String accountNumber;

    @JsonIgnore
    private Date createDate;

    private Date issueDate;

    private Boolean isActive;

    private String paymentType;

    private EWSCorporatePreferenceDTO corporatePreferenceDTO;

    private String cardholderName;

    private String aliasName;

    private String cardNumber;

    private String last4Digits;

    private String expirationMonth;

    private String expirationYear;

    private String brand;

    private String tokenId;

    private String paymentBrokerWalletId;

    private String accertifyCardTokenId;

    private BillingAddress billingAddress;

    private Boolean cardExpired;

    private Boolean favoriteCard;

    private WalletCardBinsResponse.CardBinDTO binDetails;

    private Boolean isLoadAllowed;

    private String kycStatus;

    private String kycMessage;

    private Boolean cvvVerified;

    private BigDecimal maxPayableAmount;

    private MSIDetails msiInfo;

    private Boolean cvvRequired;

    private B2bCompanyDTO company;

    private List<UPCsPayable> upcsPayable;

    @Data
    public static class BillingAddress {
        String street;
        String exteriorNum;
        String interiorNum;
        String city;
        String colony;
        String postalCode;
        String stateCode;
        String countryCode;
    }

    @Data
    public static class Balance {
        BigDecimal currencyAmount;
        CurrencyUnit currencyUnit;
    }

}
