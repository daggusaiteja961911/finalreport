package com.walmart.international.wallet.payment.core.domain.model;

public class CardsMetadata {
}
