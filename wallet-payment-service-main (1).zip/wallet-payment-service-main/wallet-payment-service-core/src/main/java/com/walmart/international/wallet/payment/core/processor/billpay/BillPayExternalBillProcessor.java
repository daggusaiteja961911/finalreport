package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.notification.NotificationAdapter;
import com.walmart.international.notification.constants.MessagingType;
import com.walmart.international.notification.dto.NotificationDetails;
import com.walmart.international.notification.dto.NotificationPayload;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.domain.CoreTransactionStatus;
import com.walmart.international.services.payment.core.domain.GiftCardSubTransaction;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.request.ReversalRequest;
import com.walmart.international.services.payment.core.response.ReversalResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.BillProcessor;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.BillProcessorFactory;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorValidationException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.PayBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentNotificationTemplateConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.mapper.TransactionMapper;
import com.walmart.international.wallet.payment.core.service.TxnAggregatorDataSyncService;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component
@Slf4j
public class BillPayExternalBillProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private BillProcessorFactory billProcessorFactory;

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private PaymentCoreService paymentCoreService;

    @Autowired
    private NotificationAdapter<NotificationPayload> notificationPayloadNotificationAdapter;

    @ManagedConfiguration
    private PaymentNotificationTemplateConfiguration paymentNotificationTemplateConfiguration;

    @Autowired
    private WalletPaymentServiceUtil walletPaymentServiceUtil;

    @Autowired
    private TxnAggregatorDataSyncService txnAggregatorDataSyncService;

    private TransactionMapper transactionMapper = TransactionMapper.INSTANCE;

    private BillPayMapper billPayMapper = BillPayMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        PayBillResponse payBillResponse;
        try {
            payBillResponse = processBillProcessorPayment(billPayTxnResponseDomainContext);
        } catch (ApplicationException ae) {
            log.error("Bill Pay txn failed for transactionId:[{}], with errorCode:[{}}. StackTrace:[{}]",
                    billPayTxnResponseDomainContext.getTransaction().getTransactionId(), ae.getErrorCode(), ExceptionUtils.getStackTrace(ae));
            txnAggregatorDataSyncService.pushTransactionDataToTAAS(billPayTxnResponseDomainContext);
            sendBillPaymentFailurePushNotification(billPayTxnResponseDomainContext.getTransaction());
            return false;
        }
        try {
            handleBillProcessorSuccessResponse(payBillResponse, billPayTxnResponseDomainContext);
        } catch (ProcessingException pe) {
            log.error("Bill Pay txn failed for transactionId:[{}], with errorCode:[{}}. StackTrace:[{}]",
                    billPayTxnResponseDomainContext.getTransaction().getTransactionId(), pe.getErrorCode(), ExceptionUtils.getStackTrace(pe));
            return false;
        }
        return true;
    }

    private PayBillResponse processBillProcessorPayment(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        CustomerBillAccount customerBillAccount = billPayTransaction.getCustomerBillAccount();
        Customer customer = billPayTransaction.getCustomer();
        try {
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.PENDING,
                    BillPayTxnStateReason.BILL_PROCESSOR_PAYMENT_INITIATED);
            log.info("Calling bill processor PayBill API for customerAccountId[{}], processorBillerId[{}], accountNumber[{}] and amount[{}]", customer.getCustomerAccountId(),
                    customerBillAccount.getProcessorBillerId(), customerBillAccount.getAccountNumber(), billPayTransaction.getAmountRequested().getValue());
            return callBillProcessorPayBill(billProcessorFactory.getBillProcessor(), customerBillAccount, billPayTransaction);
        } catch (ApplicationException ae) {
            log.error("Failed to complete billProcessor payment for BillPayTransaction with txnId[{}]. Proceeding with reversal of payment.", billPayTransaction.getTransactionId());
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    BillPayTxnStateReason.BILL_PROCESSOR_PAYMENT_FAILED);
            reversePayment(billPayTransaction.getTransactionId().toString(), billPayTxnResponseDomainContext);
            throw ae;
        } catch (Exception ex) {
            log.error("Failed to complete billProcessor payment for BillPayTransaction with txnId[{}]. Proceeding with reversal of payment.", billPayTransaction.getTransactionId());
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    BillPayTxnStateReason.BILL_PROCESSOR_PAYMENT_FAILED);
            String msg = String.format("Failed to complete billProcessor payment for BillPayTransaction with txnId[%s]", billPayTransaction.getTransactionId());
            throw new ProcessingException(ErrorConstants.PayBillInit.BILL_PROCESSOR_PAYMENT_FAILED, msg, ex);
        }
    }

    private PayBillResponse callBillProcessorPayBill(BillProcessor billProcessor,
                                          CustomerBillAccount customerBillAccount,
                                          BillPayTransaction billPayTransaction) {
        PayBillResponse payBillResponse;
        try {
            PayBillRequest payBillRequest = PayBillRequest.builder()
                    .amount(billPayTransaction.getAmountRequested().getValue())
                    .currency(billPayTransaction.getAmountRequested().getCurrencyUnit().name())
                    .accountNumber(customerBillAccount.getAccountNumber())
                    .processorBillerId(customerBillAccount.getProcessorBillerId())
                    .externalId(billPayTransaction.getCashiOrderId())
                    .processorBillAccountId(Objects.nonNull(customerBillAccount.getProcessorBillAccountId())
                            && !customerBillAccount.getProcessorBillAccountId().equals("0") ? customerBillAccount.getProcessorBillAccountId() : null)
                    .build();
            payBillResponse = billProcessor.payBill(payBillRequest, customerBillAccount.getBiller().getArcusAuthKeyVersion());
        } catch (BillProcessorValidationException ex) {
            String msg = String.format("Validation error in PayBill for customerAccountId[%s], processorBillerId[%s] , accountNumber[%s] and amount[%s]",
                    customerBillAccount.getCustomerAccountId(), customerBillAccount.getBiller().getProcessorBillerId(),
                    customerBillAccount.getAccountNumber(), billPayTransaction.getAmountRequested().getValue());
            throw new BusinessValidationException(ex.getErrorCode(), msg, ex);
        } catch (BillProcessorException ex) {
            String msg = String.format("Processing error in PayBill for customerAccountId[%s], processorBillerId[%s] , accountNumber[%s] and amount[%s]",
                    customerBillAccount.getCustomerAccountId(), customerBillAccount.getBiller().getProcessorBillerId(),
                    customerBillAccount.getAccountNumber(), billPayTransaction.getAmountRequested().getValue());
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, ex);
        }
        return payBillResponse;
    }

    private void handleBillProcessorSuccessResponse(PayBillResponse payBillResponse, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        log.info("Handling success response from bill processor for BillPayTransaction with txnId[{}]",
                billPayTxnResponseDomainContext.getBillPayTransactionDO().getBillPayTransactionId());
        try {
            billPayMapper.mapPayBillResponseToBillPayTransactionDO(payBillResponse, billPayTxnResponseDomainContext.getBillPayTransactionDO());
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.SUCCESS,
                    BillPayTxnStateReason.BILL_PROCESSOR_PAYMENT_SUCCESS);
        } catch (Exception ex) {
            String msg = String.format("Error while updating BillPayTransaction with txnId[%s] to SUCCESS",
                    billPayTxnResponseDomainContext.getBillPayTransactionDO().getBillPayTransactionId());
            throw new ProcessingException(ErrorConstants.PayBillInit.SUCCESSFUL_BILL_PAYMENT_DB_UPDATE_FAILURE, msg, ex);
        }
    }

    private void updateBillPayTxnState(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext,
                                       TransactionStateEnum state,
                                       BillPayTxnStateReason stateReason) {
        BillPayTransactionDO billPayTransactionDO = billPayTxnResponseDomainContext.getBillPayTransactionDO();
        log.info("Updating BillPayTransaction with txnId:[{}] with state:[{}] and stateReason:[{}]",
                billPayTransactionDO.getBillPayTransactionId(), state, stateReason);
        if (!state.equals(billPayTransactionDO.getState())
                && (state.equals(TransactionStateEnum.FAILURE) || state.equals(TransactionStateEnum.SUCCESS))) {
            billPayTransactionDO.updateTxnReqCompletedDate();
        }

        billPayTransactionDO = walletPaymentServiceUtil.updateLastEventDateCheck(billPayTransactionDO , state , stateReason);

        billPayTransactionDO.setState(state);
        billPayTransactionDO.setStateReason(stateReason);
        billPayTransactionDO = billPayTransactionRepository.save(billPayTransactionDO);
        billPayTxnResponseDomainContext.setBillPayTransactionDO(billPayTransactionDO);

        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        billPayTransaction.setState(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.valueOf(state.name()));
        billPayTransaction.setStateReason(com.walmart.international.wallet.payment.core.constants.enums.BillPayTxnStateReason.valueOf(stateReason.name()));
        if (state.equals(TransactionStateEnum.SUCCESS)) {
            billPayTransaction.setAmountFulfilled(Amount.builder()
                    .value(billPayTransactionDO.getAmount())
                    .currencyUnit(CurrencyUnit.valueOf(billPayTransactionDO.getCurrencyUnit().name()))
                    .build());
        }
    }

    private void reversePayment(String clientTransactionId, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        try {
            log.info("Processing payment reversal for BillPayTransaction with txnId:[{}]",
                    billPayTxnResponseDomainContext.getTransaction().getTransactionId());
            ReversalRequest reversalRequest = ReversalRequest.builder()
                    .clientTransactionId(clientTransactionId)
                    .build();
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    BillPayTxnStateReason.DEBIT_REVERSAL_INITIATED);
            ReversalResponse reversalResponse = paymentCoreService.reverse(reversalRequest);
            mapReversalResponseToContext(reversalResponse, billPayTxnResponseDomainContext.getTransaction());
            if (reversalResponse.getStatus().equals(CoreTransactionStatus.FAILED)) {
                updateBillPayTxnState(billPayTxnResponseDomainContext,
                        TransactionStateEnum.FAILURE,
                        BillPayTxnStateReason.DEBIT_REVERSAL_INIT_FAILED);
                checkErrorCodeAndSendGiftCardAccountLockedPushNotification(billPayTxnResponseDomainContext);
                throw new ProcessingException(ErrorConstants.PayBillInit.PAYMENT_CORE_GIFT_CARD_REVERSAL_FAILED, reversalResponse.getFailureDescription());
            }
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    BillPayTxnStateReason.DEBIT_REVERSAL_SUCCESS);
        } catch (PaymentCoreServiceException ex) {
            updateBillPayTxnState(billPayTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    BillPayTxnStateReason.DEBIT_REVERSAL_INIT_FAILED);
            throw new ProcessingException(ErrorConstants.PayBillInit.PAYMENT_CORE_GIFT_CARD_REVERSAL_FAILED, ex.getDescription());
        }
    }

    private void mapReversalResponseToContext(ReversalResponse reversalResponse, BillPayTransaction billPayTransaction) {
        log.info("Mapping reversal response to context for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
        transactionMapper.mapReversalResponseToTransaction(reversalResponse, billPayTransaction);
        for (GiftCardSubTransaction giftCardSubTransaction : reversalResponse.getGiftCardSubTransactions()) {
            Optional<GiftCardTransaction> oGiftCardPaymentTransaction = billPayTransaction.getGiftCardPaymentTransactionList().stream()
                    .filter(giftCardPaymentTransaction -> giftCardPaymentTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash()
                            .equals(giftCardSubTransaction.getPaymentProviderInstrumentId()))
                    .findFirst();
            oGiftCardPaymentTransaction.ifPresent(giftCardPaymentTransaction ->
                    giftCardPaymentTransaction.setGiftCardSubTransaction(transactionMapper.mapGiftCardSubTxnFromPaymentCoreResponse(giftCardSubTransaction)));
        }
    }

    private void checkErrorCodeAndSendGiftCardAccountLockedPushNotification(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        List<String> accountLockedErrorCodes = Arrays.asList("VOIDP-101", "VOIDP-102");
        if (accountLockedErrorCodes.contains(billPayTransaction.getFailureCode())) {
            sendGiftCardAccountLockedPushNotification(billPayTransaction.getCustomer().getCustomerAccountId().toString());
        }
    }

    private void sendGiftCardAccountLockedPushNotification(String customerAccountId) {
        try {
            log.info("Sending giftCard account locked push notification for customerAccountId:[{}]", customerAccountId);
            NotificationPayload notificationPayload = BillPayUtil.getNotificationPayloadForGiftCardAccountLockedPushNotification(customerAccountId);
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.PUSH));
        } catch (Exception ex) {
            log.error("Error while sending account locked push notification for customerAccountId[{}}. StackTrace: [{}]", customerAccountId, ExceptionUtils.getStackTrace(ex));
        }
    }

    private void sendBillPaymentFailurePushNotification(BillPayTransaction billPayTransaction) {
        try {
            log.info("Sending bill pay failure push notification for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
            NotificationPayload<NotificationDetails> notificationPayload = BillPayUtil.getNotificationPayloadForPayBillFailurePushNotification(billPayTransaction,
                    paymentNotificationTemplateConfiguration.getPaymentFailedReversalNotificationWarningLogo(),
                    paymentNotificationTemplateConfiguration.getPaymentFailedReversalPushExpiryTime());
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.PUSH));
        } catch (Exception ex) {
            log.error("Error in sendPayBillFailurePushNotification method for billPayTransaction:[{}]. StackTrace: [{}]",
                    billPayTransaction.getTransactionId(), ExceptionUtils.getStackTrace(ex));
        }
    }

}
