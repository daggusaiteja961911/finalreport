package com.walmart.international.wallet.payment.core.adapter.billprocessor.exception;

public class BillProcessorResourceNotFoundException extends BillProcessorProcessingException {
    public BillProcessorResourceNotFoundException(String errorCode, String message) {
        super(errorCode, message);
    }

    public BillProcessorResourceNotFoundException(String errorCode, String message, Object[] args) {
        super(errorCode, message, args);
    }

    public BillProcessorResourceNotFoundException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, cause);
    }

    public BillProcessorResourceNotFoundException(String errorCode, String message, Object[] args, Throwable cause) {
        super(errorCode, message, args, cause);
    }
}
