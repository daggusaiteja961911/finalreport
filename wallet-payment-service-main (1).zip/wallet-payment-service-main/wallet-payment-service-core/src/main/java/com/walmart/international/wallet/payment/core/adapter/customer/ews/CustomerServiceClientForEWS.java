package com.walmart.international.wallet.payment.core.adapter.customer.ews;

import com.walmart.international.digiwallet.customer.api.dto.request.paymentInstrument.UpdateCardLastUsedDateRequest;
import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.UpdateCardLastUsedDateResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.wallet.payment.core.adapter.customer.CustomerAPIName;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.mapper.EWSCustomerResponseMapper;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.mapper.EWSPaymentInstrumentsResponseMapper;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.EWSCustomerResponse;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.EWSPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.core.config.ccm.EWSConfig;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class CustomerServiceClientForEWS implements ICustomerServiceClient {

    @ManagedConfiguration
    private EWSConfig ewalletServiceConfig;

    @Autowired
    @Qualifier("ewsWebClient")
    private WebClientV2 webClientV2;

    private EWSCustomerResponseMapper ewsCustomerResponseMapper = EWSCustomerResponseMapper.INSTANCE;

    private EWSPaymentInstrumentsResponseMapper ewsPaymentInstrumentsResponseMapper = EWSPaymentInstrumentsResponseMapper.INSTANCE;


    private HttpHeaders getEWSHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(WPSConstants.Headers.CORRELATION_ID, UUID.randomUUID().toString());
        headers.add(WPSConstants.Headers.WM_SVC_NAME, ewalletServiceConfig.getSvcName());
        headers.add(WPSConstants.Headers.WM_SVC_ENV, ewalletServiceConfig.getSvcEnv());
        headers.add(WPSConstants.Headers.WM_CONSUMER_ID, ewalletServiceConfig.getSvcConsumerId());
        headers.add(WPSConstants.Headers.WM_SVC_VERSION, ewalletServiceConfig.getSvcVersion());
        return headers;
    }

    @Override
    public CustomerResponse getCustomerDetailsById(UUID customerAccountId) throws ProcessingException {
        log.info("Calling getCustomerByCustomerIdV3 to get customer details from EWS : [{}]", customerAccountId);
        HttpHeaders headers = getEWSHeaders();
        String url = String.format("%s/internal/v3/account/%s", ewalletServiceConfig.getBaseUrl(), customerAccountId);
        ResponseEntity<EWSCustomerResponse> ewsResponse = null;
        try {
            ewsResponse = webClientV2.get(url, null, headers, EWSCustomerResponse.class, CustomerAPIName.GET_CUSTOMER_BY_ID);
            log.info("response [{}] on calling get customer details for customer [{}]", ewsResponse.getBody(), customerAccountId);
        } catch (Throwable e) {
            String msg = "Error while calling EWS to get customer details";
            throw new ProcessingException(ErrorConstants.EWSClient.EWS_CLIENT_GENERIC_FAILURE, msg, e);
        }
        if (Objects.isNull(ewsResponse) || Objects.isNull(ewsResponse.getBody())
                || ewsResponse.getStatusCode() != HttpStatus.OK) {
            String msg = String.format("EWS client failed with statusCode[%s]", ewsResponse.getStatusCodeValue());
            throw new ProcessingException(ErrorConstants.EWSClient.EWS_CLIENT_FAILURE_RESPONSE, msg);
        }
        return ewsCustomerResponseMapper.mapToCustomerResponse(ewsResponse.getBody().getResult(), ewsResponse.getBody().getMessage());
    }

    @Override
    public WalletResponse getPaymentInstruments(UUID customerAccountId) throws ApplicationException {
        log.info("Calling getPaymentInstruments to get customer payment instruments details from EWS for customerAccountId: [{}]", customerAccountId);
        HttpHeaders headers = getEWSHeaders();
        String url = String.format("%s/customer/%s/payment-instruments", ewalletServiceConfig.getBaseUrl(), customerAccountId);
        ResponseEntity<EWSPaymentInstrumentsResponse> ewsResponse = null;
        try {
            ewsResponse = webClientV2.get(url, null, headers, EWSPaymentInstrumentsResponse.class, CustomerAPIName.GET_PAYMENT_INSTRUMENTS);
            log.info("response [{}] on calling get payment instruments for customer [{}]", ewsResponse.getBody(), customerAccountId);
        } catch (Throwable e) {
            String msg = "Error while calling EWS to  get payment instruments details";
            throw new ProcessingException(ErrorConstants.EWSClient.EWS_CLIENT_GENERIC_FAILURE, msg, e);
        }
        if (Objects.isNull(ewsResponse) || Objects.isNull(ewsResponse.getBody())
                || ewsResponse.getStatusCode() != HttpStatus.OK) {
            String msg = String.format("EWS client failed with statusCode[%s]", ewsResponse.getStatusCodeValue());
            throw new ProcessingException(ErrorConstants.EWSClient.EWS_CLIENT_FAILURE_RESPONSE, msg);
        }
        return ewsPaymentInstrumentsResponseMapper.mapToWalletResponse(ewsResponse.getBody());
    }

    @Override
    public void updateCardLastUsedDate(UpdateCardLastUsedDateRequest request) throws ApplicationException {
        log.info("Calling updateLastUsedCardDate to update last-used-card-date for paymentInstrumentId: [{}]", request.getPaymentInstrumentId());
        HttpHeaders headers = getEWSHeaders();
        String url = String.format("%s/last-used-card/update", ewalletServiceConfig.getBaseUrl());
        try {
            ResponseEntity<UpdateCardLastUsedDateResponse> ewsResponse = webClientV2.post(url, null, headers, request, UpdateCardLastUsedDateResponse.class, CustomerAPIName.UPDATE_LAST_USED_CARD_DATE);
            log.info("response [{}] on calling updating payment instruments for paymentInstrumentId: [{}]", ewsResponse.getBody(), request.getPaymentInstrumentId());
        } catch (Throwable e) {
            log.error("Error while calling EWS to update last-used-card for paymentInstrumentId: [{}] ", request.getPaymentInstrumentId());
        }
    }
}
