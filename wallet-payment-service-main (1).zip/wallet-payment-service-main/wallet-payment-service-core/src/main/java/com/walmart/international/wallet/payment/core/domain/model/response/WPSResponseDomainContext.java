package com.walmart.international.wallet.payment.core.domain.model.response;

import com.walmart.international.digiwallet.service.flow.domain.model.IResponseDomainContext;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.util.MultiValueMap;

import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class WPSResponseDomainContext implements IResponseDomainContext {
    MultiValueMap<String, String> headers;
    String clientRequestId;
    String clientName;

    /**
     * Returns the header value by header name. In case headers are not present or key is not present ,
     * it returns null
     * @param key - header name
     * @return
     */
    public String getHeaderValue(String key) {
        return this.getHeaders() != null && this.getHeaders().containsKey(key) ?
                this.getHeaders().get(key).get(0) :
                null;
    }

    public DeviceInformation getDeviceInfo() {
        String ip = getHeaderValue(WPSConstants.Headers.X_FORWARDED_FOR);
        return DeviceInformation.builder()
                .fingerPrint(getHeaderValue(WPSConstants.Headers.DEVICE_FINGERPRINT))
                .platform(getHeaderValue(WPSConstants.Headers.DEVICE_PLATFORM))
                .ip(Objects.nonNull(ip) ? ip.split(",")[0] : null)
                .build();
    }
}
