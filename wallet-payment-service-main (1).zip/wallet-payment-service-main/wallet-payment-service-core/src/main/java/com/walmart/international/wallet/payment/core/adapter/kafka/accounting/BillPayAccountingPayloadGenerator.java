package com.walmart.international.wallet.payment.core.adapter.kafka.accounting;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.notification.dto.accounting.AccountingEventType;
import com.walmart.international.notification.dto.accounting.AccountingPayload;
import com.walmart.international.notification.dto.accounting.OrderLine;
import com.walmart.international.services.payment.core.dto.CardTransactionDTO;
import com.walmart.international.services.payment.core.model.CardTransactionDO;
import com.walmart.international.wallet.payment.core.constants.AccountingConstants;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
public class BillPayAccountingPayloadGenerator extends AccountingPayloadGenerator {
    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;


    @Override
    public AccountingPayload generatePayload(AccountingEventType eventType, String orderId, CardTransactionDTO cardTransactionDetails) {

        UUID transactionId = UUID.fromString(cardTransactionDetails.getCoreTransaction().getClientTransactionId().split("_")[0]);

        Optional<BillPayTransactionDO> billPayTransactionDOOptional = billPayTransactionRepository.findById(transactionId);
        BillPayTransactionDO billPayTransaction = billPayTransactionDOOptional.get();
        AccountingPayload payload = initialiseAndGetPayload(eventType, orderId, cardTransactionDetails, cardTransactionDetails.getAmount());

        List<WalletResponse.PaymentInstrument> paymentInstruments = findPaymentInstrumentsForTransaction(billPayTransaction.getCustomerAccountId(),
                cardTransactionDetails.getPaymentInstrumentId());

        payload.setOrderPlacedBy(AccountingConstants.Accounting.BILL_PAYMENT);
        payload.setCashiTransactionId(billPayTransaction.getBillPayTransactionId().toString());
        payload.setOrderDate(Date.from(billPayTransaction.getCreateDate().toInstant(ZoneOffset.UTC)));
        payload.setPaymentMethods(getPaymentMethods(cardTransactionDetails, paymentInstruments.get(0), PM_ID));
        return payload;
    }

    @Override
    protected void setSetSellerInOrderLine(OrderLine orderLine) {
        orderLine.setSeller(OrderLine.Seller.builder()
                .id(AccountingConstants.Accounting.SELLER_ID)
                .shipNodeType(AccountingConstants.Accounting.SHIP_NODE_TYPE_BP)
                .build()
        );
    }
}
