package com.walmart.international.wallet.payment.core.adapter.customer.ews.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ErrorConstants {

    public static class PaymentAccept {
        public static final String PAYMENT_ID_REQUIRED = "PAC-1020";
    }
}
