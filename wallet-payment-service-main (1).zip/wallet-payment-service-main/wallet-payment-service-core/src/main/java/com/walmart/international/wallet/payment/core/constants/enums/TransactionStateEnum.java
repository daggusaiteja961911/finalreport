package com.walmart.international.wallet.payment.core.constants.enums;

public enum TransactionStateEnum {
    INITIATED,
    PENDING,
    FAILURE,
    SUCCESS,
    CANCELLED
}
