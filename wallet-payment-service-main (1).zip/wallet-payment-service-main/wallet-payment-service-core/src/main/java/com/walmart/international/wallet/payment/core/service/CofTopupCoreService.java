package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class CofTopupCoreService {

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    public void updateTransactionForReversalStatus(UUID transactionId, CoFTopupTxnStateReason stateReason) {
        try {
            Optional<CoFTopupTransactionDO> coFTopupTransactionDOOptional = coFTopupTransactionRepository.findById(transactionId);

            if (coFTopupTransactionDOOptional.isPresent()) {
                CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTransactionDOOptional.get();
                coFTopupTransactionDO.setStateReason(stateReason);
                coFTopupTransactionRepository.save(coFTopupTransactionDO);
            } else {
                log.error("CoF transaction does not exist for transactionID :{}, can not update refund state", transactionId);
            }
        } catch (Exception ex) {
            log.error("Error occurred while updating cof top up transaction : {} for refund status", transactionId, ex);
        }
    }
}
