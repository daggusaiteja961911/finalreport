package com.walmart.international.wallet.payment.core.adapter.tas.request;

import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TransactionEventDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionSyncRequest implements Serializable{
    List<TransactionEventDTO> transactions;
    Map<String, String> metadata;
}
