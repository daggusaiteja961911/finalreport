package com.walmart.international.wallet.payment.core.constants;

public class AccountingConstants {
    public static final String EVENT_TYPE_CHARGE_SUCCESS = "charge.success";
    public static final String EVENT_TYPE_REFUND_SUCCESS = "refund.success";

    public static final String CURRENCY_UNIT = "MXN";


    public interface Accounting {
        String VERTICAL_ID = "CASHI_BU";
        String ORDER_SOURCE = "CASHIAPP";
        String TOPUP = "TOPUP";
        String SFStore = "SFStore";
        String REDEMPTION = "REDEMPTION";
        String BILL_PAYMENT = "BILLPAYMENT";
        String SHIP_NODE_TYPE_BP = "BP";
        String SELLER_ID = "CASHI_9175";
        String SELLER_ID_PREFIX = "STORE_";
        String CASHI_ITEM = "CASHI ITEM";
        Integer PRIME_LINE_NO = 1000001;

        String CHARGE_SUCCESS_STATUS_CODE = "3700";
        String CHARGE_SUCCESS_STATUS_DESC = "Embarcado";
        String CHARGE_SUCCESS_STATUS = "SHIPPED";

        String REFUND_SUCCESS_STATUS_CODE = "3700.02";
        String REFUND_SUCCESS_STATUS_DESC = "Devolución Recibida";
        String REFUND_SUCCESS_STATUS = "RETURNED";

        String RETURN_STATUS = "PROCESSING";
        String RETURN_STATUS_CODE = "3950.01";
        String RETURN_STATUS_DESC = "Devolucion Concluida";
        String RETURN_REASON = "Devolucion Cashi";
        String RETURN_REASON_CODE = "CASHI RETURN";

        String PRODUCT_OFFER_ID = "00000000000001";
        String PRODUCT_OFFER_UPC = "00000000000001";

        String ORDER_BY_FD = "REDEMPTION_ECOM_FD";
        String ORDER_BY_OP = "REDEMPTION_ECOM_OP";

        String SHIP_NODE_TYPE_WALLET = "WALLET";
        String SHIP_NODE_CARD = "ECOMM";
        String SELLER_ID_EA = "STORE_1920";

        String PRODUCT_OFFER_ID_ECOMM = "00000000000002";
        String PRODUCT_OFFER_UPC_ECOMM = "00000000000002";

        String CASHI_ITEM_ECOMM = "CASHI PURCHASE ITEM";
        String REFUND_SUCCESS_STATUS_ECOMM_CARD = "RETURN RECEIVED";
        String REFUND_SUCCESS_STATUS_ECOM_GC = "RETURN RETURNED";

        String SHIP_NODE_CASHBACK = "CBW";

        String SHIP_NODE_CASHBACK_COF_POS = "CBCRP";

        String SHIP_NODE_CASHBACK_COF_ECOMM = "CBCRE";

        String SHIP_NODE_CASHBACK_WALLET_PARTIAL_ADJUSTMENT = "CBWRA";

        String SHIP_NODE_CASHBACK_WALLET_FULL_ADJUSTMENT = "CBWR";

        String CASHBACK_BY_WALLET_ECOMM = "CBECOMFD";
        String CASHBACK_BY_COF_ECOMM = "CBECOM";

        String CASHBACK_BY_WALLET_POS = "CBFD";

        String CASHBACK_BY_COF_POS = "CBREDEPMTION";

        String DISPOSITION_CODE_ACTUAL_YEAR = "CBACTUALYEAR";

        String DISPOSITION_CODE_PREVIOUS_YEAR = "CBPREVYEAR";

    }
}
