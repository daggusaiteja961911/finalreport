package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CacheAction;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.mapper.BillerMapper;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryVersionMappingDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerSearchDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillerCategoryVersionMappingRepository;
import com.walmart.international.wallet.payment.data.dao.repository.BillerRepository;
import com.walmart.international.wallet.payment.data.dao.repository.BillerSearchRepository;
import io.strati.libs.commons.collections.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import net.spy.memcached.WmClient;
import net.spy.memcached.internal.OperationFuture;
import org.apache.commons.collections4.ListUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class BillerCoreService {

    @Autowired
    private BillerRepository billerRepository;

    @Autowired
    private WmClient wmClient;

    @Autowired
    private BillerCategoryVersionMappingRepository billerCategoryVersionMappingRepository;

    @Autowired
    private BillerSearchRepository billerSearchRepository;

    BillerMapper billerMapper = BillerMapper.INSTANCE;

    public Biller fetchAndCacheBillerData(String processorBillerId) throws ApplicationException {
        return fetchAndCacheBillerData(null, processorBillerId);
    }

    public Biller fetchAndCacheBillerData(UUID billerId, String processorBillerId) throws ApplicationException {
        Biller biller = null;
        String billerDataCacheKey = processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA;
        String billerDataUpdatedAtCacheKey = processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT;

        //TODO: start caching using UUID of biller when callBy billerId is enabled.
        if (Objects.nonNull(billerId)) {
            throw new BusinessValidationException(ErrorConstants.BillerData.BILLER_ID_PROCESSING_NOT_ENABLED);
        }
        if (Objects.nonNull(processorBillerId)) {
            try {
                biller = (Biller) wmClient.get(billerDataCacheKey);
                log.info("Biller data from cache for key[{}]: [{}]", billerDataCacheKey, biller);
            } catch (Exception ex) {
                String msg = String.format("Error while fetching biller data from cache for key:[%s]", billerDataCacheKey);
                log.error(msg, ex);
            }
        }

        if (Objects.isNull(biller)) {
            BillerDO billerDO = getBillerDO(null, processorBillerId);
            biller = prepareBillerFromDO(billerDO);
            Biller finalBiller = biller;

            if (Objects.nonNull(processorBillerId)) {
                log.info("Putting billerData and billerDataUpdatedAt values in cache");
                wmClient.set(billerDataCacheKey, 0, finalBiller).addListener(res -> log.info("For biller data:: added key - {} with val - {} --- status - {}",
                        billerDataCacheKey, finalBiller, res.getStatus()));
                wmClient.set(billerDataUpdatedAtCacheKey, 0, finalBiller.getMaxUpdateTimestamp()).addListener(res -> log.info("For biller data last updated at timestamp:: added key - {} with val - {} --- status - {}",
                        billerDataUpdatedAtCacheKey, finalBiller.getMaxUpdateTimestamp(), res.getStatus()));
            }
        }
        return biller;
    }

    private Biller prepareBillerFromDO(BillerDO billerDO) {
        Biller biller = billerMapper.mapBillerDOToBillerWithoutSubBillersAndBillPlans(billerDO);
        biller.setBillPlans(billerMapper.mapBillPlans(billerDO));
        biller.setSubBillers(billerMapper.mapSubBillerDOsToBillers(billerDO));
        biller.setMaxUpdateTimestamp(BillPayUtil.computeMaxUpdatedTimestampForBillerData(billerDO));
        biller.setBillerBehaviourCode(BillPayUtil.getBillerBehaviourCode(biller));
        return biller;
    }

    private BillerDO getBillerDO(UUID billerId, String processorBillerId) throws ApplicationException {
        BillerDO billerDO;
        if (Objects.nonNull(billerId)) {
            try {
                log.info("Fetching biller info from DB for billerId[{}]", billerId);
                billerDO = billerRepository.getByBillerIdAndEnabled(billerId, Boolean.TRUE).orElseThrow(() -> new BusinessValidationException(
                        ErrorConstants.BillerData.BILLER_NOT_FOUND_OR_NOT_ENABLED, String.format("Biller record not found/not enabled for billerId: [%s]", billerId)));
            } catch (BusinessValidationException bve) {
                throw bve;
            } catch (Exception ex) {
                String msg = String.format("Exception while fetching billerDO from DB for billerId: [%s]", billerId);
                throw new ProcessingException(ErrorConstants.BillerData.BILLER_DB_FETCH_ERROR, msg, ex);
            }
            return billerDO;
        }
        try {
            log.info("Fetching biller info from DB for processorBillerId[{}]", processorBillerId);
            billerDO = billerRepository.getByProcessorBillerIdAndEnabled(processorBillerId, Boolean.TRUE).orElseThrow(() -> new BusinessValidationException(
                    ErrorConstants.BillerData.BILLER_NOT_FOUND_OR_NOT_ENABLED, String.format("Biller record not found/not enabled for processorBillerId: [%s]", processorBillerId)));
        } catch (BusinessValidationException bve) {
            throw bve;
        } catch (Exception ex) {
            String msg = String.format("Exception while fetching billerDO from DB for processorBillerId: [%s]", processorBillerId);
            throw new ProcessingException(ErrorConstants.BillerData.BILLER_DB_FETCH_ERROR, msg, ex);
        }
        return billerDO;
    }

    public List<BillerCategory> getBillerCategoriesList(Integer billerCategoryVersion) {
        List<BillerCategory> billerCategoriesList = null;
        try {
            String cacheKey = WPSConstants.Biller.BILLER_CATEGORIES_MAP_CACHE_KEY + billerCategoryVersion;
            billerCategoriesList = (List<BillerCategory>) wmClient.get(cacheKey);
            log.info("BillerCategoriesMap from cache with key [{}] :: [{}]", cacheKey, billerCategoriesList);
        } catch (Exception e) {
            log.error("Error while fetching BillerCategoriesMap from meghacache", e);
        }
        if (CollectionUtils.isEmpty(billerCategoriesList)) {
            log.info("Fetching BillerCategoriesMap from database");
            billerCategoriesList = fetchAndCacheBillerCategoriesMap(List.of(billerCategoryVersion)).get(billerCategoryVersion);
        }
        return billerCategoriesList;
    }

    public Map<Integer, List<BillerCategory>> fetchAndCacheBillerCategoriesMap(List<Integer> billerCategoryVersions) {
        List<BillerCategory> billerCategoriesList;
        Map<Integer, List<BillerCategory>> versionToBillerCategoriesMap = new HashMap<>();

        List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList;
        try {
            billerCategoryVersionMappingDOList = billerCategoryVersionMappingRepository.getBillerCategoriesWithBillers(billerCategoryVersions);
        } catch (Exception ex) {
            String msg = String.format("Error while fetching BillerCategoryVersionMapping data from DB for billerCategoryVersions [%s]", billerCategoryVersions);
            throw new ProcessingException(ErrorConstants.Common.BILLER_CATEGORY_VERSION_MAPPING_DB_FETCH_ERROR, msg, ex);
        }
        if (CollectionUtils.isNotEmpty(billerCategoryVersionMappingDOList)) {
            billerCategoriesList = billerMapper.mapBillerCategoryVersionMappingsDOsToBillerCategoryList(billerCategoryVersionMappingDOList);
            versionToBillerCategoriesMap = mapBillerVersionToBillerCategories(billerCategoriesList);
            for (Map.Entry<Integer, List<BillerCategory>> entry : versionToBillerCategoriesMap.entrySet()) {
                String cacheKey = WPSConstants.Biller.BILLER_CATEGORIES_MAP_CACHE_KEY + entry.getKey();
                OperationFuture<Boolean> operationFuture = wmClient.set(cacheKey, 0, entry.getValue());
                List<BillerCategory> finalBillerCategoriesList = entry.getValue();
                operationFuture.addListener(res -> log.info("Added key - {} with val - {} --- status - {}", cacheKey, finalBillerCategoriesList,
                        res.getStatus()));
            }
        }
        return versionToBillerCategoriesMap;
    }

    private Map<Integer, List<BillerCategory>> mapBillerVersionToBillerCategories(List<BillerCategory> billerCategories) {
        Map<Integer, List<BillerCategory>> map = new HashMap<>();
        billerCategories.forEach(billerCategory -> {
            map.putIfAbsent(billerCategory.getBillerCategoryVersion(), new ArrayList<>());
            map.get(billerCategory.getBillerCategoryVersion()).add(billerCategory);
        });
        return map;
    }

    public Date fetchBillerCategoryDataLastUpdatedAtTimestamp() {
        Date billerCategoryDataLastUpdatedAt = null;

        try {
            billerCategoryDataLastUpdatedAt = (Date) wmClient.get(WPSConstants.Biller.BILLER_CATEGORY_DATA_UPDATED_AT_CACHE_KEY);
            log.info("Biller category data last updated at timestamp from cache [{}]", billerCategoryDataLastUpdatedAt);
        } catch (Exception e) {
            log.error("Error while fetching biller category updated at timestamp from cache", e);
        }

        // if cache miss
        if (Objects.isNull(billerCategoryDataLastUpdatedAt)) {
            log.info("Fetching biller category data last updated at timestamp from database");
            billerCategoryDataLastUpdatedAt = fetchAndCacheBillerCategoryDataUpdatedAtTimestamp();
        }
        return billerCategoryDataLastUpdatedAt;
    }

    public Date fetchAndCacheBillerCategoryDataUpdatedAtTimestamp() {
        Date billerCategoryDataLastUpdatedAt;
        try {
            billerCategoryDataLastUpdatedAt = billerCategoryVersionMappingRepository.getBillerCategoryDataUpdateTimestamp();
        } catch (Exception ex) {
            String msg = "Error while fetching billerCategoryData last updated at timestamp from DB";
            throw new ProcessingException(ErrorConstants.Common.BILLER_CATEGORY_DATA_UPDATED_AT_DB_FETCH_ERROR, msg, ex);
        }
        OperationFuture<Boolean> operationFuture = wmClient.set(WPSConstants.Biller.BILLER_CATEGORY_DATA_UPDATED_AT_CACHE_KEY, 0, billerCategoryDataLastUpdatedAt);
        operationFuture.addListener(res -> log.info("Biller category data last updated at timestamp added in cache: key - {} with val - {} --- status - {}",
                WPSConstants.Biller.BILLER_CATEGORY_DATA_UPDATED_AT_CACHE_KEY, billerCategoryDataLastUpdatedAt, res.getStatus()));
        return billerCategoryDataLastUpdatedAt;
    }

    public Map<String, Object> fetchBillerDataLastUpdatedAtMap(List<String> processorBillerIds) {
        Map<String, Object> billerDataLastUpdateAtMap = fetchBillerDataLastUpdatedAtMapFromCache(processorBillerIds);
        if (Objects.isNull(billerDataLastUpdateAtMap) || billerDataLastUpdateAtMap.isEmpty()) {
            return fetchBillerDataLastUpdatedAtMapFromDB(processorBillerIds);
        } else if (billerDataLastUpdateAtMap.size() < processorBillerIds.size()) {
            List<String> processorBillerIdsNotPresentInCache = processorBillerIds.stream().filter(processorBillerId ->
                            !billerDataLastUpdateAtMap.containsKey(processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT))
                    .collect(Collectors.toList());
            billerDataLastUpdateAtMap.putAll(fetchBillerDataLastUpdatedAtMapFromDB(processorBillerIdsNotPresentInCache));
            return billerDataLastUpdateAtMap;
        } else {
            return billerDataLastUpdateAtMap;
        }
    }

    private Map<String, Object> fetchBillerDataLastUpdatedAtMapFromCache(List<String> processorBillerIds) {
        Map<String, Object> billerDataLastUpdateAtMapFromCache = new HashMap<>();

        try {
            if (CollectionUtils.isNotEmpty(processorBillerIds)) {
                List<String> cacheKeysForBillerDataUpdate = processorBillerIds.stream().map(processorBillerId -> processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT)
                        .collect(Collectors.toList());
                billerDataLastUpdateAtMapFromCache = wmClient.getBulk(cacheKeysForBillerDataUpdate);
            }
        } catch (Exception e) {
            log.error("Error while fetching biller data last updated at timestamp from cache", e);
        }

        return billerDataLastUpdateAtMapFromCache;
    }

    private Map<String, Object> fetchBillerDataLastUpdatedAtMapFromDB(List<String> processorBillerIds) {
        Map<String, Object> billerDataLastUpdateAtMap = new HashMap<>();
        List<BillerDO> billerDOS;
        try {
            billerDOS = billerRepository.getBillersInfo(processorBillerIds, false);
        } catch (Exception ex) {
            String msg = String.format("Error while fetching biller data for following processorBillerIds[%s] from DB", processorBillerIds);
            throw new ProcessingException(ErrorConstants.BillerDateUpdateInfo.BILLER_DB_FETCH_ERROR, msg, ex);
        }
        billerDOS.forEach(biller -> {
            LocalDateTime billerDataLastUpdatedAt = BillPayUtil.computeMaxUpdatedTimestampForBillerData(biller);
            String billerDataUpdatedAtCacheKey = biller.getProcessorBillerId() + WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT;
            billerDataLastUpdateAtMap.put(billerDataUpdatedAtCacheKey, billerDataLastUpdatedAt);
            OperationFuture<Boolean> operationFuture = wmClient.set(billerDataUpdatedAtCacheKey, 0, billerDataLastUpdatedAt);
            operationFuture.addListener(res -> log.info("Biller data last updated at timestamp added in cache: key - {} with val - {} --- status - {}",
                    billerDataUpdatedAtCacheKey, billerDataLastUpdatedAt, res.getStatus()));
        });
        return billerDataLastUpdateAtMap;
    }

    public void reloadCacheForBillerCategoryData(List<Integer> billerCategoryVersions) {
        if (CollectionUtils.isNotEmpty(billerCategoryVersions)) {
            fetchAndCacheBillerCategoriesMap(billerCategoryVersions);
        }
        fetchAndCacheBillerCategoryDataUpdatedAtTimestamp();
    }

    public void reloadIncorrectSearchDataInCache() {
        fetchAndCacheBillerIncorrectSearchKeywordMap();
        fetchAndCacheBillerIncorrectSearchDataUpdateTimestamp();
    }

    public Set<String> reloadCacheForBillerData(Set<String> processorBillerIds) {
        Set<String> retryProcessorBillerIds = new HashSet<>();
        List<String> processorBillerIdsInRequest = new ArrayList<>(processorBillerIds);
        List<BillerDO> billerDOs;
        try {
            billerDOs = billerRepository.getBillersInfo(processorBillerIdsInRequest, true);
        } catch (Exception ex) {
            String msg = String.format("Error while fetching biller data for following processorBillerIds[%s] from DB", processorBillerIdsInRequest);
            throw new ProcessingException(ErrorConstants.ReloadCacheForBillerData.BILLER_DB_FETCH_ERROR, msg, ex);
        }
        List<String> processorBillerIdsPresentInDB = billerDOs.stream().map(BillerDO::getProcessorBillerId).collect(Collectors.toList());
        List<String> processorBillerIdsToEvictFromCache = ListUtils.subtract(processorBillerIdsInRequest, processorBillerIdsPresentInDB);
        if (CollectionUtils.isNotEmpty(processorBillerIdsToEvictFromCache)) {
            evictDataFromCacheForBillersNotPresentInDB(processorBillerIdsToEvictFromCache);
        }

        List<BillerDO> billersToCache = new ArrayList<>();
        for (BillerDO billerDO : billerDOs) {
            if (BillPayUtil.isBillerHavingProducts(billerDO)) {
                log.info("Biller with billerId:[{}], processorBillerId:[{}] skipped from caching due to having products", billerDO.getBillerId(), billerDO.getProcessorBillerId());
            } else if (BillPayUtil.isBillerAProduct(billerDO)) {
                billersToCache.add(billerDO);
            } else {
                if (Objects.isNull(billerDO.getParentBiller()) || Boolean.FALSE.equals(billerDO.getParentBiller().getEnabled())) {
                    billersToCache.add(billerDO);
                } else {
                    billersToCache.add(billerDO.getParentBiller());
                }
            }
        }
        if (CollectionUtils.isNotEmpty(billersToCache)) {
            retryProcessorBillerIds.addAll(reloadCacheForBillerAndUpdateTimestampData(billersToCache));
        }

        return retryProcessorBillerIds;
    }

    private void evictDataFromCacheForBillersNotPresentInDB(List<String> processorBillerIdsToEvict) {
        log.info("Cache eviction for deleted billers started at {}", new Date());
        processorBillerIdsToEvict.forEach(processorBillerId -> {
            String billerDataCacheKey = processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA;
            OperationFuture<Boolean> billerDataOperationFuture = wmClient.delete(billerDataCacheKey);
            billerDataOperationFuture.addListener(res -> log.info("Biller data key deleted with val - {} --- status - {}",
                    billerDataCacheKey, res.getStatus()));

            String billerDataUpdateAtCachekey = processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT;
            OperationFuture<Boolean> billerDataUpdatedAtOperationFuture = wmClient.delete(billerDataUpdateAtCachekey);
            billerDataUpdatedAtOperationFuture.addListener(res -> log.info("Biller data updated at timestamp key deleted with val - {} --- status - {}",
                    billerDataUpdateAtCachekey, res.getStatus()));
        });
        log.info("Cache eviction for deleted billers ended at {}", new Date());
    }

    private Set<String> reloadCacheForBillerAndUpdateTimestampData(List<BillerDO> billersToCache) {
        Set<String> retryProcessorBillerIds = new HashSet<>();
        List<OperationFuture> billerDataFutureList = new ArrayList<>();
        List<OperationFuture> billerDataUpdatedAtTimestampFutureList = new ArrayList<>();
        for (BillerDO billerDO : billersToCache) {
            Biller biller = prepareBillerFromDO(billerDO);

            String billerDataCacheKey = billerDO.getProcessorBillerId() + WPSConstants.Biller.SUFFIX_BILLER_DATA;
            billerDataFutureList.add(wmClient.set(billerDataCacheKey, 0, biller));

            String billerDataLastUpdatedAtCacheKey = billerDO.getProcessorBillerId() + WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT;
            billerDataUpdatedAtTimestampFutureList.add(wmClient.set(billerDataLastUpdatedAtCacheKey, 0, biller.getMaxUpdateTimestamp()));
        }
        retryProcessorBillerIds.addAll(BillPayUtil.filterBillersFailedToCache(billerDataFutureList,
                CacheAction.WRITE, WPSConstants.Biller.SUFFIX_BILLER_DATA));
        retryProcessorBillerIds.addAll(BillPayUtil.filterBillersFailedToCache(billerDataUpdatedAtTimestampFutureList,
                CacheAction.WRITE, WPSConstants.Biller.SUFFIX_BILLER_DATA));
        return retryProcessorBillerIds;
    }


    public List<Biller> getPopularBillers() throws BusinessValidationException {
        List<BillerDO> billerDOList;
        try {
            billerDOList =  billerRepository.getPopularBillersAndSubBillers();
        } catch (Exception ex) {
            String msg = "Error while fetch popular billers from DB";
            throw new ProcessingException(ErrorConstants.GetPopularBillers.POPULAR_BILLERS_DB_FETCH_ERROR, msg, ex);
        }

        if (CollectionUtils.isEmpty(billerDOList)) {
            throw new BusinessValidationException(ErrorConstants.GetPopularBillers.NO_POPULAR_BILLERS_FOUND);
        }

        return billerMapper.mapBillerDOsToBillerList(billerDOList);
    }

    public List<String> getProcessorBillerIdsOfBillersWhoseDataIsCached() {
        try {
            return billerRepository.getProcessorBillerIdsOfBillersWhoseDataIsCached();
        } catch (Exception ex) {
            String msg = "Error while fetching processorBillerIds from DB";
            throw new ProcessingException(ErrorConstants.EvictCacheForBillerData.BILLER_DB_FETCH_ERROR, msg, ex);
        }
    }

    public Set<String> evictCacheForBillerAndUpdateTimestampData(List<String> processorBillerIdsToEvict) {
        Set<String> retryProcessorBillerIds = new HashSet<>();
        List<OperationFuture> billerDataFutureList = new ArrayList<>();
        List<OperationFuture> billerDataUpdatedAtTimestampFutureList = new ArrayList<>();

        processorBillerIdsToEvict.forEach(processorBillerId -> {
            String billerDataCacheKey = processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA;
            billerDataFutureList.add(wmClient.delete(billerDataCacheKey));

            String billerDataLastUpdatedAtCacheKey = processorBillerId + WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT;
            billerDataUpdatedAtTimestampFutureList.add(wmClient.delete(billerDataLastUpdatedAtCacheKey));
        });
        retryProcessorBillerIds.addAll(BillPayUtil.filterBillersFailedToCache(billerDataFutureList,
                CacheAction.EVICT, WPSConstants.Biller.SUFFIX_BILLER_DATA));
        retryProcessorBillerIds.addAll(BillPayUtil.filterBillersFailedToCache(billerDataUpdatedAtTimestampFutureList,
                CacheAction.EVICT, WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT));
        return retryProcessorBillerIds;
    }

    public HashMap<String, List<String>> fetchBillerIncorrectSearchKeywordMap() {
        HashMap<String, List<String>> billerIncorrectSearchKeywordsMap = new HashMap<>();
        try {
            String cacheKey = WPSConstants.Biller.BILLER_INCORRECT_SEARCH_KEYWORDS_MAP_CACHE_KEY;
            billerIncorrectSearchKeywordsMap = (HashMap<String, List<String>>) wmClient.get(cacheKey);
            log.info("Biller Incorrect Search Keywords from Cache : [{}]", billerIncorrectSearchKeywordsMap);
        } catch (Exception e) {
            log.info("Failed to read BillerIncorrectSearchKeywordsMap from meghacache", e);
        }
        //if cache miss, fetch from db
        if (Objects.isNull(billerIncorrectSearchKeywordsMap)) {
            log.info("Fetching BillerIncorrectSearchKeywordsMap from database");
            billerIncorrectSearchKeywordsMap = fetchAndCacheBillerIncorrectSearchKeywordMap();
        }
        return billerIncorrectSearchKeywordsMap;
    }

    public HashMap<String, List<String>> fetchAndCacheBillerIncorrectSearchKeywordMap() {
        HashMap<String, List<String>> billerIncorrectSearchKeywordsMap;
        List<BillerSearchDO> billerSearchKeywords;
        try {
            billerSearchKeywords = billerSearchRepository.getAllEnabledBillerSearchDO();
        } catch (Exception ex) {
            String msg = String.format("Error while fetching incorrect biller search data from DB");
            throw new ProcessingException(ErrorConstants.IncorrectSearchBillerData.BILLER_SEARCH_DB_FETCH_ERROR, msg, ex);
        }

        billerIncorrectSearchKeywordsMap = billerSearchKeywords
                .stream()
                .collect(Collectors.toMap(
                        BillerSearchDO::getIncorrectKeyword,
                        billerSearchDO -> getBillerNamesFromBillerIncorrectMappingSet(billerSearchDO.getBillers()),
                        ((billerSearchDO, billerSearchDO1) -> billerSearchDO),
                        LinkedHashMap::new
                ));

        billerIncorrectSearchKeywordsMap.values().removeAll(Collections.singleton(null));
        final HashMap<String, List<String>> finalBillerIncorrectSearchKeywordMap = billerIncorrectSearchKeywordsMap;
        OperationFuture<Boolean> operationFuture = wmClient.set(WPSConstants.Biller.BILLER_INCORRECT_SEARCH_KEYWORDS_MAP_CACHE_KEY, 0, finalBillerIncorrectSearchKeywordMap);
        operationFuture.addListener(res -> log.info("Added key - {} with val - {} --- status - {}", WPSConstants.Biller.BILLER_INCORRECT_SEARCH_KEYWORDS_MAP_CACHE_KEY,
                finalBillerIncorrectSearchKeywordMap, res.getStatus()));

        return finalBillerIncorrectSearchKeywordMap;
    }

    private List<String> getBillerNamesFromBillerIncorrectMappingSet(List<BillerDO> billersDOList){
        if (billersDOList == null || billersDOList.isEmpty()) {
            return Collections.emptyList();
        }
        return billersDOList.stream().filter(BillerDO::getEnabled).map(BillerDO::getBillerName).collect(Collectors.toList());
    }
    public Date fetchBillerIncorrectSearchDataUpdateTimestamp() {
        Date billerIncorrectSearchKeywordsLastUpdatedAt = null;
        try {
            billerIncorrectSearchKeywordsLastUpdatedAt = (Date) wmClient.get(WPSConstants.Biller.BILLER_INCORRECT_SEARCH_KEYWORD_MAP_UPDATED_AT_CACHE_KEY);
            log.info("Biller incorrect search data update timestamp from cache:: [{}]", billerIncorrectSearchKeywordsLastUpdatedAt);
        } catch (Exception e) {
            log.error("Error while fetching biller incorrect search data update info from cache : ", e);
        }
        // if cache miss
        if (Objects.isNull(billerIncorrectSearchKeywordsLastUpdatedAt)) {
            log.info("Fetching biller incorrect search data last updated at timestamp from database");
            billerIncorrectSearchKeywordsLastUpdatedAt = fetchAndCacheBillerIncorrectSearchDataUpdateTimestamp();
        }
        return billerIncorrectSearchKeywordsLastUpdatedAt;
    }

    private Date fetchAndCacheBillerIncorrectSearchDataUpdateTimestamp() {
        Date billerIncorrectSearchKeywordsLastUpdatedAt = billerSearchRepository.getBillerIncorrectSearchDataUpdateTimestamp();
        OperationFuture<Boolean> operationFuture = wmClient.set(WPSConstants.Biller.BILLER_INCORRECT_SEARCH_KEYWORD_MAP_UPDATED_AT_CACHE_KEY, 0, billerIncorrectSearchKeywordsLastUpdatedAt);
        operationFuture.addListener(res -> log.info("Biller incorrect search data update timestamp :: added key - {} with val - {} --- status - {}",
                WPSConstants.Biller.BILLER_INCORRECT_SEARCH_KEYWORD_MAP_UPDATED_AT_CACHE_KEY, billerIncorrectSearchKeywordsLastUpdatedAt, res.getStatus()));
        return billerIncorrectSearchKeywordsLastUpdatedAt;
    }
}