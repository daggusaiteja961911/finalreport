package com.walmart.international.wallet.payment.core.dto;

import com.walmart.international.notification.constants.MessagingEvent;
import com.walmart.international.services.notificationservice.naas.ReminderSubCategoryType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReminderCategoryDTO {

    private ReminderSubCategoryType reminderSubCategoryType;

    private MessagingEvent messagingEvent;
}
