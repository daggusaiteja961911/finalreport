package com.walmart.international.wallet.payment.core.domain.model.request;

import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.data.dao.entity.BillDetailDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class BillPayTxnRequestDomainContext extends TransactionRequestDomainContext {

    private BillerDO billerDO;
    private BillDetailDO billDetailDO;

    public BillPayTransaction getTransaction() {
        return (BillPayTransaction) super.transaction;
    }

}
