package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import lombok.Data;

import java.util.Date;

@Data
public class EWSCorporatePreferenceDTO extends EWSPaymentPreferenceDTO {
    private static final long serialVersionUID = 8144925710360910460L;

    private String corporateEmail;

    private Boolean emailVerified;

    private Boolean active;

    private Date linkDate;

    private Date endDate;

    private B2bCompanyDTO company;

    private EWSPaymentPreferenceDTO EWSPaymentPreferenceDTO;

}
