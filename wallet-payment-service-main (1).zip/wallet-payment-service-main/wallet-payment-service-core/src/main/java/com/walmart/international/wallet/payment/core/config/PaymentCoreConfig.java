package com.walmart.international.wallet.payment.core.config;

import com.walmart.international.ewallet.payment.api.CardPaymentAdapter;
import com.walmart.international.ewallet.payment.api.CardPaymentProviderConfig;
import com.walmart.international.ewallet.payment.api.GiftCardPaymentAdapter;
import com.walmart.international.ewallet.payment.api.GiftCardPaymentProviderConfig;
import com.walmart.international.ewallet.payment.api.PangaeaConfig;
import com.walmart.international.ewallet.payment.api.PaymentBrokerConfig;
import com.walmart.international.ewallet.payment.api.dto.FraudCheckDetails;
import com.walmart.international.ewallet.payment.common.constant.CardPaymentProvider;
import com.walmart.international.ewallet.payment.common.constant.GiftcardPaymentProvider;
import com.walmart.international.ewallet.payment.exception.CardPaymentValidationException;
import com.walmart.international.ewallet.payment.exception.GiftCardPaymentValidationException;
import com.walmart.international.services.payment.core.config.PaymentAdapterConfig;
import com.walmart.international.services.payment.core.config.PaymentProviderConfig;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentBrokerConfiguration;
import com.walmart.kafka.producer.KafkaDRProducer;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PaymentCoreConfig {

    @Autowired
    PaymentAdapterConfig paymentAdapterConfig;

    @Bean
    public PaymentProviderConfig paymentProviderConfig(PangaeaConfig pangaeaConfig, PaymentBrokerConfig paymentBrokerConfig) {
        PaymentProviderConfig paymentProviderConfig = new PaymentProviderConfig();
        GiftCardPaymentProviderConfig giftCardPaymentProviderConfig = new GiftCardPaymentProviderConfig();
        giftCardPaymentProviderConfig.setGiftcardPaymentProvider(GiftcardPaymentProvider.PANGAEA);
        giftCardPaymentProviderConfig.setPangaeaConfig(pangaeaConfig);

        CardPaymentProviderConfig cardPaymentProviderConfig = new CardPaymentProviderConfig();
        cardPaymentProviderConfig.setCardPaymentProvider(CardPaymentProvider.PAYMENT_BROKER);
        cardPaymentProviderConfig.setPaymentBrokerConfig(paymentBrokerConfig);

        paymentProviderConfig.setCardPaymentProviderConfig(cardPaymentProviderConfig);
        paymentProviderConfig.setGiftCardPaymentProviderConfig(giftCardPaymentProviderConfig);
        return paymentProviderConfig;
    }

    @Bean
    public GiftCardPaymentAdapter giftCardPaymentAdapter(PaymentProviderConfig paymentProviderConfig)
            throws GiftCardPaymentValidationException {
        return paymentAdapterConfig.getGiftCardPaymentAdapter(paymentProviderConfig.getGiftCardPaymentProviderConfig());
    }

    @Bean
    public CardPaymentAdapter cardPaymentAdapter(PaymentProviderConfig paymentProviderConfig)
            throws CardPaymentValidationException {
        return paymentAdapterConfig.getCardPaymentAdapter(paymentProviderConfig.getCardPaymentProviderConfig());
    }

}
