package com.walmart.international.wallet.payment.core.adapter.billprocessor.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateBillResponse {

    private String processorBillAccountId;

    private String processorBillerId;

    private String accountNumber;

    private BigDecimal dueAmount;

    private String dueAmountCurrency;

    private String dueInfoUpdatedAt;

    private String status;

    private String type;

    private String billPaidDate;

    private String dueDate;

    private String nameOnAccount;
}
