package com.walmart.international.wallet.payment.core.adapter.kafka.service;

import com.walmart.international.wallet.payment.core.adapter.kafka.consumer.PBChargeKafkaListener;
import com.walmart.international.wallet.payment.core.adapter.kafka.consumer.PBRefundKafkaListener;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.PBChargeKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.refund.PBReverseKafkaResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class KafkaService {

    @Autowired
    PBChargeKafkaListener pbChargeKafkaListener;

    @Autowired
    PBRefundKafkaListener pbRefundKafkaListener;

    public void consumeChargeReconPayload(PBChargeKafkaResponse response) {
        pbChargeKafkaListener.listen(response);
    }

    public void consumeRefundReconPayload(PBReverseKafkaResponse response) {
        pbRefundKafkaListener.listen(response);
    }
}
