package com.walmart.international.wallet.payment.core.adapter.kafka.exception;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;

public class TransactionNotFoundException extends BusinessValidationException {
    public TransactionNotFoundException(String errorCode) {
        super(errorCode);
    }
}
