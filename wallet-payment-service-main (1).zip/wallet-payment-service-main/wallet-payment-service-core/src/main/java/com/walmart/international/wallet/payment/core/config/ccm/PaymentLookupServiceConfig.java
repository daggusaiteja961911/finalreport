package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "payment-lookup-service-config")
public interface PaymentLookupServiceConfig extends WebClientCCMConfigs{

    @Property(propertyName = "lookup.service.base.url")
    String lookupServiceBaseURL();
}
