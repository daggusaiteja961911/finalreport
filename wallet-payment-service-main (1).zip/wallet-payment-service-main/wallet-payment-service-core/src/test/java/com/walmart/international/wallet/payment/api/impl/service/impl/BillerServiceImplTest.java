//package com.walmart.international.wallet.payment.api.impl.service.impl;
//
//import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
//import com.walmart.international.wallet.payment.MockUtils;
//import com.walmart.international.wallet.payment.api.dto.response.billpay.BillerByIdResponse;
//import com.walmart.international.wallet.payment.core.utils.BillPaymentServiceHelper;
//import net.spy.memcached.WmClient;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Spy;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//public class BillerServiceImplTest {
//
//    @Mock
//    private WmClient wmClient;
//
//    @Mock
//    private BillPaymentServiceHelper billPaymentServiceHelper;
//
//    @Spy
//    @InjectMocks
//    private BillerServiceImpl billerService;
//
////    @Test
////    public void shouldGetResponseFromCacheWhenAvailable() throws ApplicationException {
////        BillerByIdResponse billerByIdResponse = MockUtils.getBillerByIdResponse();
////
////        when(wmClient.get(anyString())).thenReturn(billerByIdResponse);
////
////        Assertions.assertEquals(billerByIdResponse, billerService.getBillerById(null, "13674"));
////    }
//
////    @Test
////    public void shouldGetResponseFromDBWhenCacheNotAvailable() throws ApplicationException {
////        BillerByIdResponse billerByIdResponse = MockUtils.getBillerByIdResponse();
////        BillerDO billerDO = MockUtils.getBillerDO();
////
////        doReturn(billerDO).when(billerService.getBillerDO(any(UUID.class), anyString()));
////        doReturn(billerByIdResponse).when(billerService.prepareBillProviderDataObject(any(BillerDO.class)));
//////        when(billerService.getBillerDO(any(UUID.class), anyString())).thenReturn(billerDO);
//////        when(billerService.prepareBillProviderDataObject(any(BillerDO.class))).thenReturn(billerByIdResponse);
////        when(billPaymentServiceHelper.computeMaxUpdatedTimestampForBillProviderDetails(any(BillerDO.class))).thenReturn(LocalDateTime.now());
////
////        Assertions.assertEquals(billerByIdResponse, billerService.getBillerById(null, "13674"));
////    }
//}
