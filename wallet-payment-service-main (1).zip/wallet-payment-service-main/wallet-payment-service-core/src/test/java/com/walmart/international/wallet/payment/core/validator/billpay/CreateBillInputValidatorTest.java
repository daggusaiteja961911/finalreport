package com.walmart.international.wallet.payment.core.validator.billpay;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CreateBillInputValidatorTest {
//
//    @Mock
//    CustomerServiceAdapter customerServiceAdapter;
//
//    @Mock
//    BillerRepository billerRepository;
//
//    @Mock
//    CustomerBillAccountRepository customerBillAccountRepository;
//
//    @InjectMocks
//    CreateBillInputValidator createBillInputValidator;
//
//    @Test
//    void shouldThrowExceptionWhenCustomerContextIsMissing() {
//        BillPaymentRequestDomainContext createBillRequestDomainContext = MockUtils.getCreateBillRequestDomainContextForCreateBill();
//        createBillRequestDomainContext.getCustomer().setCustomerAccountId(null);
//
//        DataValidationException dve = Assertions.assertThrows(DataValidationException.class, () ->
//                createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext()));
//        Assertions.assertEquals(ErrorConstants.CreateBill.INVALID_CUSTOMER_ACCOUNT_ID, dve.getErrorCode());
//        Assertions.assertEquals("CustomerAccountId cannot be null", dve.getMessage());
//    }
//
//    @Test
//    void shouldThrowExceptionWhenCustomerRecordNotFound() throws BaseException {
//        BillPaymentRequestDomainContext createBillRequestDomainContext = MockUtils.getCreateBillRequestDomainContextForCreateBill();
//
//        when(customerServiceAdapter.getCustomerById(any(UUID.class))).thenReturn(null);
//
//        BusinessValidationException bve = Assertions.assertThrows(BusinessValidationException.class, () ->
//                createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext()));
//        Assertions.assertEquals(ErrorConstants.CreateBill.INVALID_CUSTOMER_ACCOUNT_ID, bve.getErrorCode());
//        Assertions.assertEquals(String.format("Customer record not found for customerAccountId [%s]", createBillRequestDomainContext.getCustomer().getCustomerAccountId()), bve.getMessage());
//    }
//
//    @Test
//    void shouldThrowExceptionWhenBillerContextIsMissing() throws BaseException {
//        BillPaymentRequestDomainContext createBillRequestDomainContext = MockUtils.getCreateBillRequestDomainContextForCreateBill();
//        CustomerResponse customerResponse = MockUtils.getCustomerResponseForCreateBill();
//
//        when(customerServiceAdapter.getCustomerById(any(UUID.class))).thenReturn(customerResponse);
//
//        // Scenario 1
//        createBillRequestDomainContext.getBillerDetails().setProcessorBillerId(null);
//
//        DataValidationException dve = Assertions.assertThrows(DataValidationException.class, () ->
//                createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext()));
//        Assertions.assertEquals(ErrorConstants.CreateBill.BILLER_ID_AND_PROCESSOR_ID_MISSING, dve.getErrorCode());
//        Assertions.assertEquals("Both billerId and processorBillerId cannot be null simultaneously", dve.getMessage());
//
//        // Scenario 2
//        createBillRequestDomainContext.getBillerDetails().setProcessorBillerId("35");
//
//        when(billerRepository.getByProcessorBillerId(anyString())).thenReturn(Optional.empty());
//
//        BusinessValidationException bve1 = Assertions.assertThrows(BusinessValidationException.class, () ->
//                createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext()));
//        Assertions.assertEquals(ErrorConstants.CreateBill.INVALID_PROCESSOR_BILLER_ID, bve1.getErrorCode());
//        Assertions.assertEquals(String.format("Biller record not found for processorBillerId [%s]", createBillRequestDomainContext.getBillerDetails().getProcessorBillerId()), bve1.getMessage());
//
//        // Scenario 3
//        createBillRequestDomainContext.getBillerDetails().setBillerId(UUID.randomUUID());
//        createBillRequestDomainContext.getBillerDetails().setProcessorBillerId(null);
//
//        when(billerRepository.getByBillerId(any(UUID.class))).thenReturn(Optional.empty());
//        BusinessValidationException bve2 = Assertions.assertThrows(BusinessValidationException.class, () ->
//                createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext()));
//        Assertions.assertEquals(ErrorConstants.CreateBill.INVALID_BILLER_ID, bve2.getErrorCode());
//        Assertions.assertEquals(String.format("Biller record not found for billerId [%s]", createBillRequestDomainContext.getBillerDetails().getBillerId()), bve2.getMessage());
//    }
//
//    @Test
//    void shouldExtractAccountNumberFromBarcodeInput() throws BaseException, ApplicationException {
//        BillPaymentRequestDomainContext createBillRequestDomainContext = MockUtils.getCreateBillRequestDomainContextForCreateBill();
//        createBillRequestDomainContext.getBillerDetails().setAccountNumber("119999999999991111111111111111");
//        CustomerResponse customerResponse = MockUtils.getCustomerResponseForCreateBill();
//        BillerDO billerDO = MockUtils.getBillerDOForCreateBill();
//
//        when(customerServiceAdapter.getCustomerById(any(UUID.class))).thenReturn(customerResponse);
//        when(billerRepository.getByProcessorBillerId(anyString())).thenReturn(Optional.of(billerDO));
//
//        createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext());
//        Assertions.assertEquals("999999999999", createBillRequestDomainContext.getBillerDetails().getAccountNumber());
//    }
//
//    @Test
//    void shouldThrowExceptionWhenUnableToFetchCustomerBillAccountRecord() throws BaseException {
//        BillPaymentRequestDomainContext createBillRequestDomainContext = MockUtils.getCreateBillRequestDomainContextForCreateBill();
//        createBillRequestDomainContext.getBillerDetails().setProcessorBillerId("29866");
//        CustomerResponse customerResponse = MockUtils.getCustomerResponseForCreateBill();
//        BillerDO billerDO = MockUtils.getBillerDOForCreateBill();
//        billerDO.setProcessorBillerId("29866");
//
//        when(customerServiceAdapter.getCustomerById(any(UUID.class))).thenReturn(customerResponse);
//        when(billerRepository.getByProcessorBillerId(anyString())).thenReturn(Optional.of(billerDO));
//        when((customerBillAccountRepository.findByCustomerAccountIdAndAccountNumberAndBiller(any(UUID.class), anyString(), any(BillerDO.class)))).thenThrow(new DataAccessException("DB Error") {
//            @Override
//            public String getMessage() {
//                return super.getMessage();
//            }
//        });
//
//        ProcessingException pe = Assertions.assertThrows(ProcessingException.class, () -> createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext()));
//        Assertions.assertEquals(ErrorConstants.Common.INTERNAL_SERVER_ERROR, pe.getErrorCode());
//        Assertions.assertEquals(String.format("Exception while fetching customerBillAccountDO from DB for customerAccountId[%s}, accountNumber[%s}, processorBillerId[%s]",
//                customerResponse.getCustomerAccountId(), createBillRequestDomainContext.getBillerDetails().getAccountNumber(), billerDO.getProcessorBillerId()), pe.getMessage());
//    }
//
//    @Test
//    void shouldReturnTrueOnSuccessfulCompletion() throws BaseException, ApplicationException {
//        BillPaymentRequestDomainContext createBillRequestDomainContext = MockUtils.getCreateBillRequestDomainContextForCreateBill();
//        CustomerResponse customerResponse = MockUtils.getCustomerResponseForCreateBill();
//        BillerDO billerDO = MockUtils.getBillerDOForCreateBill();
//
//        when(customerServiceAdapter.getCustomerById(any(UUID.class))).thenReturn(customerResponse);
//        when(billerRepository.getByProcessorBillerId(anyString())).thenReturn(Optional.of(billerDO));
//        when((customerBillAccountRepository.findByCustomerAccountIdAndAccountNumberAndBiller(any(UUID.class), anyString(), any(BillerDO.class)))).thenReturn(new CustomerBillAccountDO());
//
//        Assertions.assertTrue(createBillInputValidator.process(createBillRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }

}
