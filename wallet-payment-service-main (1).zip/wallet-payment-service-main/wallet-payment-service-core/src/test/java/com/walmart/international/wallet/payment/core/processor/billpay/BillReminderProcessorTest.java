//package com.walmart.international.wallet.payment.core.processor.billpay;
//
//import com.walmart.commons.utils.DateUtils;
//
//import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
//import com.walmart.international.notification.utils.EventHelper;
//import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
//import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
//import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
//import com.walmart.international.wallet.payment.core.service.BillerCoreService;
//import com.walmart.international.wallet.payment.dao.entity.BillerDO;
//import com.walmart.international.wallet.payment.MockUtils;
//import com.walmart.international.wallet.payment.dao.entity.CustomerBillAccountDO;
//import com.walmart.international.wallet.payment.dao.repository.BillerRepository;
//import com.walmart.international.wallet.payment.dao.repository.CustomerBillAccountRepository;
//import com.walmart.international.wallet.payment.core.domain.model.request.BillPaymentRequestDomainContext;
//import com.walmart.international.wallet.payment.core.domain.model.response.BillPaymentResponseDomainContext;
//import com.walmart.international.wallet.payment.core.constants.Constants;
//import org.joda.time.DateTime;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.math.BigDecimal;
//import java.util.Date;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//public class BillReminderProcessorTest {
//
//
//    @InjectMocks
//    BillReminderProcessor billReminderProcessor;
//
//    @Mock
//    BillPaymentConfiguration billPaymentConfiguration;
//
//    @Mock
//    BillerRepository billerRepository;
//
//    @Mock
//    EventHelper eventHelper;
//
//    @Mock
//    CustomerBillAccountRepository customerBillAccountRepository;
//
//    @Mock
//    BillerCoreService billerCoreService;
//
//    @Test
//    public void shouldReturnParentProcessorBillerId() {
//        //Given
//        BillerDO billerDO = MockUtils.getBillerDO();
//        //then
//        Optional<String> processorBillerId = billReminderProcessor.getWrapperProcessorBillerId(billerDO);
//        assertEquals(billerDO.getParentBiller().getProcessorBillerId(), processorBillerId.orElse(null));
//    }
//
//    @Test
//    public void shouldReturnParentProcessorBillerIdAsNull() {
//        //Given
//        BillerDO billerDO = MockUtils.getBillerDO();
//        billerDO.setParentBiller(null);
//
//        //then
//        Optional<String> processorBillerId = billReminderProcessor.getWrapperProcessorBillerId(billerDO);
//        assertNull(processorBillerId.orElse(null));
//    }
//
//    @Test
//    public void shouldReturnParentBillerProcessorBillerIdAsQueryProcessorBillerId() {
//        //given
//        BillerDO biller = MockUtils.getBillerDO();
//        biller.setProductDisplayName(null);
//
//        //then
//        String processorBillerId = billReminderProcessor.getQueryProcessorBillerId(biller);
//        assertEquals(biller.getParentBiller().getProcessorBillerId(), processorBillerId);
//    }
//
//    @Test
//    public void shouldReturnProcessorBillerIdAsQueryProcessorBillerId() {
//        //given
//        BillerDO billerDO = MockUtils.getBillerDO();
//        billerDO.setParentBiller(null);
//
//        //then
//        String processorBillerId = billReminderProcessor.getQueryProcessorBillerId(billerDO);
//        assertEquals(billerDO.getProcessorBillerId(), processorBillerId);
//    }
//
//    @Test
//    public void shouldReturnDateSameAsPlannedReminderDate() {
//        //given
//        Date currentDate = DateTime.now().toDate();
//        Date plannedReminderDate = DateUtils.addDays(currentDate, 5);
//        Date reminderDateLastDay = DateUtils.addDays(currentDate, 10);
//
//        //then
//        Date reminderDate = billReminderProcessor.getDate(currentDate, plannedReminderDate, reminderDateLastDay);
//        assertEquals(plannedReminderDate, reminderDate);
//    }
//
//    @Test
//    public void shouldReturnDateSameAsNextToCurrentDate() {
//        //given
//        Date currentDate = DateTime.now().toDate();
//        Date plannedReminderDate = DateUtils.addDays(currentDate, -1);
//        Date reminderDateLastDay = DateUtils.addDays(currentDate, 2);
//
//        //then
//        Date reminderDate = billReminderProcessor.getDate(currentDate, plannedReminderDate, reminderDateLastDay);
//        assertEquals(DateUtils.addDays(currentDate, 1), reminderDate);
//    }
//
//    @Test
//    public void shouldReturnFirstBillPayReminderDate() throws BusinessValidationException {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        customerBillAccount.setDueDate(DateUtils.addDays(DateTime.now().toDate(), 5).toString());
//        Date currentDate = DateTime.now().toDate();
//
//        //when
//        when(billPaymentConfiguration.getDaysForFirstBillPayReminder()).thenReturn(3);
//        when(billPaymentConfiguration.getDaysForSecondBillPayReminder()).thenReturn(1);
//        //then
//        Date firstReminderDate = billReminderProcessor.getFirstBillPayReminderDate(customerBillAccount, currentDate);
//        assertEquals(DateUtils.addDays(MockUtils.getFormattedDate(customerBillAccount.getDueDate()), -3), firstReminderDate);
//    }
//
//    @Test
//    public void shouldReturnFirstBillPayReminderDateWhenCurrentDateIsGreaterThanFirstBillpayReminderDate() throws BusinessValidationException {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        customerBillAccount.setDueDate(DateUtils.addDays(DateTime.now().toDate(), 5).toString());
//        Date currentDate = DateUtils.addDays(MockUtils.getFormattedDate(customerBillAccount.getDueDate()), -3);
//
//        //when
//        when(billPaymentConfiguration.getDaysForFirstBillPayReminder()).thenReturn(3);
//        when(billPaymentConfiguration.getDaysForSecondBillPayReminder()).thenReturn(1);
//        //then
//        Date firstReminderDate = billReminderProcessor.getFirstBillPayReminderDate(customerBillAccount, currentDate);
//        assertEquals(DateUtils.addDays(currentDate, 1), firstReminderDate);
//    }
//
//    @Test
//    public void shouldReturnFirstBillPayReminderDateAsNullWhenCurrentDateIsGreaterThanFirstBillpayReminderLastDate() throws BusinessValidationException {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        customerBillAccount.setDueDate(DateUtils.addDays(DateTime.now().toDate(), 5).toString());
//        Date currentDate = DateUtils.addDays(MockUtils.getFormattedDate(customerBillAccount.getDueDate()), -2);
//
//        //when
//        when(billPaymentConfiguration.getDaysForFirstBillPayReminder()).thenReturn(3);
//        when(billPaymentConfiguration.getDaysForSecondBillPayReminder()).thenReturn(1);
//        //then
//        Date firstReminderDate = billReminderProcessor.getFirstBillPayReminderDate(customerBillAccount, currentDate);
//        assertNull(firstReminderDate);
//    }
//
//    @Test
//    public void shouldReturnSecondBillPayReminderDate() throws BusinessValidationException {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        customerBillAccount.setDueDate(DateUtils.addDays(DateTime.now().toDate(), 5).toString());
//        Date currentDate = DateTime.now().toDate();
//
//        //when
//        when(billPaymentConfiguration.getDaysForSecondBillPayReminder()).thenReturn(1);
//        //then
//        Date secondReminderDate = billReminderProcessor.getSecondBillPayReminderDate(customerBillAccount, currentDate);
//        assertEquals(DateUtils.addDays(MockUtils.getFormattedDate(customerBillAccount.getDueDate()), -1), secondReminderDate);
//    }
//
//    @Test
//    public void shouldReturnSecondBillPayReminderDateWhenCurrentDateIsGreaterThanSecondBillpayReminderDate() throws BusinessValidationException {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        customerBillAccount.setDueDate(DateUtils.addDays(DateTime.now().toDate(), 5).toString());
//        Date currentDate = DateUtils.addDays(MockUtils.getFormattedDate(customerBillAccount.getDueDate()), -1);
//
//        //when
//        when(billPaymentConfiguration.getDaysForSecondBillPayReminder()).thenReturn(1);
//        //then
//        Date secondReminderDate = billReminderProcessor.getSecondBillPayReminderDate(customerBillAccount, currentDate);
//        assertEquals(DateUtils.addDays(currentDate, 1), secondReminderDate);
//    }
//
//    @Test
//    public void shouldReturnSecondBillPayReminderDateAsNullWhenCurrentDateIsGreaterThanSecondBillpayReminderLastDate() throws BusinessValidationException {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        customerBillAccount.setDueDate(DateUtils.addDays(DateTime.now().toDate(), 5).toString());
//        Date currentDate = DateUtils.addDays(MockUtils.getFormattedDate(customerBillAccount.getDueDate()), 1);
//
//        //when
//        when(billPaymentConfiguration.getDaysForSecondBillPayReminder()).thenReturn(1);
//        //then
//        Date secondReminderDate = billReminderProcessor.getSecondBillPayReminderDate(customerBillAccount, currentDate);
//        assertNull(secondReminderDate);
//    }
//
//    @Test
//    public void shouldReturnBillpayReminderDeeplinkWithAccountAlias() {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        BillerDO billerDO = MockUtils.getBillerDO();
//        String actualDeeplink = "cashi://deeplink?action=" + Constants.BillPay.SHOW_BILLER_ACTION + "&code=" + billerDO.getParentBiller().getProcessorBillerId() + "&billerId=" + billerDO.getProcessorBillerId() + "&accountNumber=" + customerBillAccount.getAccountNumber() + "accountAlias=" + customerBillAccount.getAlias();
//
//        //then
//        assertEquals(actualDeeplink, billReminderProcessor.getBillPayReminderDeeplink(customerBillAccount, billerDO));
//    }
//
//    @Test
//    public void shouldReturnBillpayReminderDeeplinkWithoutAccountAlias() {
//        //given
//        CustomerBillAccount customerBillAccount = MockUtils.getCustomerBillAccount();
//        customerBillAccount.setAlias(null);
//        BillerDO billerDO = MockUtils.getBillerDO();
//        String actualDeeplink = "cashi://deeplink?action=" + Constants.BillPay.SHOW_BILLER_ACTION + "&code=" + billerDO.getParentBiller().getProcessorBillerId() + "&billerId=" + billerDO.getProcessorBillerId() + "&accountNumber=" + customerBillAccount.getAccountNumber();
//
//        //then
//        assertEquals(actualDeeplink, billReminderProcessor.getBillPayReminderDeeplink(customerBillAccount, billerDO));
//    }
//
//    @Test
//    public void shouldReturnBillpayReminderDeeplinkAsNull() {
//        //given
//        CustomerBillAccount customerBillAccount = null;
//        BillerDO billerDO = null;
//
//        //then
//        assertNull(billReminderProcessor.getBillPayReminderDeeplink(customerBillAccount, billerDO));
//    }
//
//    @Test
//    public void shouldReturnBillerCategory() {
//        //given
//        BillerDO billerDO = MockUtils.getBillerDO();
//        billerDO.setProcessorBillerId("123");
//        List<BillerCategory> billerCategoriesList = List.of(MockUtils.getBillerCategory());
//        billerCategoriesList.get(0).getBillers().get(0).setProcessorBillerId("123");
//        billerCategoriesList.get(0).setCategoryName("abc");
//
//        //when
//        when(billerCoreService.getBillerCategoriesList(2)).thenReturn(billerCategoriesList);
//
//        //then
//        assertEquals("abc", billReminderProcessor.getBillerCategory(billerDO));
//    }
//
//    @Test
//    public void shouldReturnEmptyStringForBillerCategory() {
//        //given
//        BillerDO billerDO = MockUtils.getBillerDO();
//        billerDO.setProcessorBillerId("123");
//        List<BillerCategory> billerCategoriesList = List.of(MockUtils.getBillerCategory());
//        billerCategoriesList.get(0).getBillers().get(0).setProcessorBillerId("1234");
//        billerCategoriesList.get(0).setCategoryName("abc");
//
//        //when
//        when(billerCoreService.getBillerCategoriesList(2)).thenReturn(billerCategoriesList);
//
//        //then
//        assertEquals("", billReminderProcessor.getBillerCategory(billerDO));
//    }
//
//    @Test
//    public void shouldCreateBillPaymentReminder() {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        BillPaymentResponseDomainContext billPaymentResponseDomainContext = new BillPaymentResponseDomainContext();
//        BillerDO billerDO = MockUtils.getBillerDO();
//        List<BillerCategory> billerCategoriesList = List.of(MockUtils.getBillerCategory());
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        billPaymentResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
//
//        //when
//        when(billerRepository.getByBillerId(customerBillAccountDO.getBiller().getBillerId())).thenReturn(Optional.of(billerDO));
//        when(billerCoreService.getBillerCategoriesList(2)).thenReturn(billerCategoriesList);
//
//        //then
//        assertTrue(billReminderProcessor.process(billPaymentRequestDomainContext, billPaymentResponseDomainContext));
//    }
//
//    @Test
//    public void shouldCreateBillPaymentReminderWithoutAlias() {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        BillPaymentResponseDomainContext billPaymentResponseDomainContext = new BillPaymentResponseDomainContext();
//        BillerDO billerDO = MockUtils.getBillerDO();
//        List<BillerCategory> billerCategoriesList = List.of(MockUtils.getBillerCategory());
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        customerBillAccountDO.setAlias(null);
//        billPaymentResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
//
//        //when
//        when(billerRepository.getByBillerId(customerBillAccountDO.getBiller().getBillerId())).thenReturn(Optional.of(billerDO));
//        when(billerCoreService.getBillerCategoriesList(2)).thenReturn(billerCategoriesList);
//
//        //then
//        assertTrue(billReminderProcessor.process(billPaymentRequestDomainContext, billPaymentResponseDomainContext));
//    }
//
//    @Test
//    public void shouldUpdateCustomerBillAccountDetailsAsDueAmountIsNullAndDoesNotCreateReminder() {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        BillPaymentResponseDomainContext billPaymentResponseDomainContext = new BillPaymentResponseDomainContext();
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setDueAmount(null);
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        billPaymentResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
//
//        //when
//        when(customerBillAccountRepository.save(customerBillAccountDO)).thenReturn(null);
//        //then
//        assertTrue(billReminderProcessor.process(billPaymentRequestDomainContext, billPaymentResponseDomainContext));
//    }
//
//    @Test
//    public void shouldUpdateCustomerBillAccountDetailsAsDueAmountIsZeroAndDoesNotCreateReminder() {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        BillPaymentResponseDomainContext billPaymentResponseDomainContext = new BillPaymentResponseDomainContext();
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setDueAmount(BigDecimal.ZERO);
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        billPaymentResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
//
//        //when
//        when(customerBillAccountRepository.save(customerBillAccountDO)).thenReturn(null);
//        //then
//        assertTrue(billReminderProcessor.process(billPaymentRequestDomainContext, billPaymentResponseDomainContext));
//    }
//
//    @Test
//    public void shouldNotCreateBillPaymentReminderAsBillerDOIsNull() {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        BillPaymentResponseDomainContext billPaymentResponseDomainContext = new BillPaymentResponseDomainContext();
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        billPaymentResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
//
//        //when
//        when(billerRepository.getByBillerId(customerBillAccountDO.getBiller().getBillerId())).thenReturn(Optional.empty());
//
//        //then
//        assertTrue(billReminderProcessor.process(billPaymentRequestDomainContext, billPaymentResponseDomainContext));
//    }
//
//    @Test
//    public void shouldCreateBillPaymentReminderWithBillerCategoryAsEmpty() {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        BillPaymentResponseDomainContext billPaymentResponseDomainContext = new BillPaymentResponseDomainContext();
//        BillerDO billerDO = MockUtils.getBillerDO();
//        List<BillerCategory> billerCategoriesList = List.of(MockUtils.getBillerCategory());
//        billerCategoriesList.get(0).getBillers().get(0).setProcessorBillerId("789");
//        billerDO.setProcessorBillerId("123");
//        billerDO.getParentBiller().setProcessorBillerId("456");
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        billPaymentResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
//
//        //when
//        when(billerRepository.getByBillerId(customerBillAccountDO.getBiller().getBillerId())).thenReturn(Optional.of(billerDO));
//        when(billerCoreService.getBillerCategoriesList(2)).thenReturn(billerCategoriesList);
//
//        //then
//        assertTrue(billReminderProcessor.process(billPaymentRequestDomainContext, billPaymentResponseDomainContext));
//    }
//
//}
