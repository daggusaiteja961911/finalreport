//package com.walmart.international.wallet.payment.core.processor.billpay;
//
//import com.walmart.commons.utils.DateUtils;
//import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
//import com.walmart.international.digiwallet.service.web.rest.i8n.local.SimpleMessageResolver;
//import com.walmart.international.wallet.payment.api.dto.response.billpay.BillerDetails;
//import com.walmart.international.wallet.payment.core.config.ccm.ArcusConfiguration;
//import com.walmart.international.wallet.payment.dao.entity.CustomerBillAccountDO;
//import com.walmart.international.wallet.payment.dao.repository.CustomerBillAccountRepository;
//import com.walmart.international.wallet.payment.core.domain.model.request.BillPaymentRequestDomainContext;
//import com.walmart.international.wallet.payment.core.domain.model.request.CustomerBillAccountDetails;
//import com.walmart.international.wallet.payment.core.domain.model.response.BillPaymentResponseDomainContext;
//import com.walmart.international.wallet.payment.MockUtils;
//import org.joda.time.DateTime;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//public class UpdateCustomerBillAccountProcessorTest {
//
//    @Mock
//    CustomerBillAccountRepository customerBillAccountRepository;
//
//    @Mock
//    ArcusConfiguration arcusConfig;
//
//    @InjectMocks
//    UpdateCustomerBillAccountProcessor updateSavedBillsProcessor;
//
//    @Mock
//    SimpleMessageResolver simpleMessageResolver;
//
//    @Test
//    public void shouldUpdateDueDateAndDueAmount() throws BusinessValidationException {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        customerBillAccountDetails.setAccountAlias(null); customerBillAccountDetails.setCustomerBillAccountId(null); customerBillAccountDetails.setCustomerAccountId(null);
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        customerBillAccountDO.setCustomerAccountId(customerBillAccountDetails.getCustomerAccountId());
//
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(customerBillAccountDO);
//        when(customerBillAccountRepository.save(customerBillAccountDO)).thenReturn(null);
//
//        //then
//        assertTrue(updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldUpdateAccountAlias() throws BusinessValidationException {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        customerBillAccountDetails.setProcessorBillAccountId(null); customerBillAccountDetails.setProcessorBillerId(null); customerBillAccountDetails.setDueDate(null); customerBillAccountDetails.setDueAmount(null); customerBillAccountDetails.setDueAmountCurrencyUnit(null);
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        customerBillAccountDO.setCustomerAccountId(customerBillAccountDetails.getCustomerAccountId());
//
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(customerBillAccountDO);
//        when(customerBillAccountRepository.getCountByCustomerAccountIdAndBiller_BillerIdAndAlias(customerBillAccountDetails.getCustomerAccountId(), customerBillAccountDetails.getAccountAlias(),
//                customerBillAccountDO.getBiller().getBillerId())).thenReturn(Long.valueOf(0));
//        when(customerBillAccountRepository.save(customerBillAccountDO)).thenReturn(null);
//
//        //then
//        assertTrue(updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//    @Test
//    public void shouldSearchForBillRecordToUpdateAliasAndThrowException() {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        customerBillAccountDetails.setProcessorBillAccountId(null); customerBillAccountDetails.setProcessorBillerId(null); customerBillAccountDetails.setDueDate(null); customerBillAccountDetails.setDueAmount(null); customerBillAccountDetails.setDueAmountCurrencyUnit(null);
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        billPaymentRequestDomainContext.getHeaders().put("wm_consumer.id", List.of("123456"));
//
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(null);
//        when(arcusConfig.getConsumerId()).thenReturn("12345");
//
//        //then
//        assertThrows(BusinessValidationException.class, () -> updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldSearchForBillRecordToUpdateDueDateAndReturnFalse() throws BusinessValidationException {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        billPaymentRequestDomainContext.getHeaders().put("wm_consumer.id", List.of("123456"));
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(null);
//        when(arcusConfig.getConsumerId()).thenReturn("123456");
//
//        //then
//        assertFalse(updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldFailedValidationCustomerAccountIdMismatchAndThrowException() {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        customerBillAccountDetails.setProcessorBillAccountId(null); customerBillAccountDetails.setProcessorBillerId(null); customerBillAccountDetails.setDueDate(null); customerBillAccountDetails.setDueAmount(null); customerBillAccountDetails.setDueAmountCurrencyUnit(null);
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(customerBillAccountDO);
//
//        //then
//        assertThrows(BusinessValidationException.class, () -> updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldFailedValidationDueDateDuplicatedAndThrowException() throws BusinessValidationException {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        customerBillAccountDetails.setAccountAlias(null); customerBillAccountDetails.setCustomerBillAccountId(null); customerBillAccountDetails.setCustomerAccountId(null);
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        customerBillAccountDO.setCustomerAccountId(customerBillAccountDetails.getCustomerAccountId());
//        customerBillAccountDO.setDueDate(MockUtils.getFormattedDate(customerBillAccountDetails.getDueDate()));
//
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(customerBillAccountDO);
//
//        //then
//        assertThrows(BusinessValidationException.class, () -> updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldFailedValidationDueDatePastCurrentDateAndThrowException() throws BusinessValidationException {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        customerBillAccountDetails.setAccountAlias(null); customerBillAccountDetails.setCustomerBillAccountId(null); customerBillAccountDetails.setCustomerAccountId(null);
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        customerBillAccountDO.setCustomerAccountId(customerBillAccountDetails.getCustomerAccountId());
//        customerBillAccountDetails.setDueDate(DateUtils.addDays(DateTime.now().toDate(), -1).toString());
//
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(customerBillAccountDO);
//
//        //then
//        assertThrows(BusinessValidationException.class, () -> updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldFailedValidationAliasUniquenessAndThrowException() {
//        //Given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        CustomerBillAccountDetails customerBillAccountDetails = billPaymentRequestDomainContext.getCustomerBillAccountDetails();
//        customerBillAccountDetails.setProcessorBillAccountId(null); customerBillAccountDetails.setProcessorBillerId(null); customerBillAccountDetails.setDueDate(null); customerBillAccountDetails.setDueAmount(null); customerBillAccountDetails.setDueAmountCurrencyUnit(null);
//        BillerDetails billerDetails = billPaymentRequestDomainContext.getBillerDetails();
//        CustomerBillAccountDO customerBillAccountDO = MockUtils.getCustomerBillAccountDO();
//        customerBillAccountDO.setCustomerAccountId(customerBillAccountDetails.getCustomerAccountId());
//
//        //when
//        when(customerBillAccountRepository.getCustomerBillAccountDO(customerBillAccountDetails.getProcessorBillAccountId(), customerBillAccountDetails.getCustomerBillAccountId())).thenReturn(customerBillAccountDO);
//        when(customerBillAccountRepository.getCountByCustomerAccountIdAndBiller_BillerIdAndAlias(customerBillAccountDetails.getCustomerAccountId(), customerBillAccountDetails.getAccountAlias(),
//                customerBillAccountDO.getBiller().getBillerId())).thenReturn(Long.valueOf(1));
//
//        //then
//        assertThrows(BusinessValidationException.class, () -> updateSavedBillsProcessor.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//}
