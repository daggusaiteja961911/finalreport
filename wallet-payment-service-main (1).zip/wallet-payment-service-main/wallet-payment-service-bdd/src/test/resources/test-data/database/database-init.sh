#!/bin/bash

for script in /tmp/database/ddl*.sql
    do /opt/mssql-tools/bin/sqlcmd -S database -U sa -P Pass@word -l 30 -e -i $script
done

for script in /tmp/database/dml*.sql
    do /opt/mssql-tools/bin/sqlcmd -S database -U sa -P Pass@word -l 30 -e -i $script
done
wait $pid