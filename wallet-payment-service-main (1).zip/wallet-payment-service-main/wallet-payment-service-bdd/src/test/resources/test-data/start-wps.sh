#!/bin/bash

curl \
https://repository.walmart.com/content/repositories/pangaea_releases/io/strati/tunr/utils/strati-af-tunr-utils-agent/2.0.7/strati-af-tunr-utils-agent-2.0.7.jar \
--output /tmp/ccm2.jar

java -jar -Dccm.serviceId=wallet-payment-service \
-Dccm.serviceConfigVersion=NON-PROD-1.0 \
-Dccm.envName=bdd \
-Dccm.envProfile=bdd \
-Dccm.zone=bdd \
-Dccm.node=bdd \
-Dccm.configs.dir=/tmp/ccm2/wallet-payment-service-NON-PROD-1_0/ \
/tmp/ccm2.jar > /tmp/ccm2.log &

sleep 10;

exec java -javaagent:/opt/org.jacoco.agent-runtime.jar=destfile=/opt/jacoco-it.exec \
$JAVA_OPTS \
-XX:+UseContainerSupport \
-Dsecrets.path=/tmp/test-data/vault/wps/secret_props.properties \
-Dsecrets.password.path=/tmp/test-data/vault/wps/password.properties \
-Dscm.server.url=http://tunr.non-prod.walmart.com/scm-app/v2 \
-Druntime.context.environmentType=bdd \
-Druntime.context.environment=bdd \
-Druntime.context.appName=wallet-payment-service \
-Druntime.context.cloud=bdd \
-Druntime.context.cashi.tenant=MX \
-Dcom.walmart.platform.config.runOnEnv=bdd \
-Dccm.configs.dir=/tmp/ccm2/wallet-payment-service-NON-PROD-1_0/ \
-Dscm.server.url=http://tunr.non-prod.walmart.com/scm-app/v2 \
-Dcom.walmart.platform.txnmarking.otel.type=LOGGING \
-Dcom.walmart.platform.logging.profile=OTEL \
-Dcom.walmart.platform.telemetry.otel.enabled=true \
-Dcom.walmart.platform.txnmarking.kafka.brokerList=null \
-Dcom.walmart.platform.txnmarking.file.path=/dev/null \
-Dcom.walmart.platform.logging.file.enabled=false \
-Dcom.walmart.platform.metrics.file.path=/dev/null \
-Dcom.walmart.platform.logging.file.path=/dev/null \
-Dcom.walmart.platform.metrics.forwardToRawlog=false \
-Dcom.walmart.platform.logging.console.enabled=true \
-Dcom.walmart.platform.logging.kafka.brokerList=null \
-Druntime.context.system.property.override.enabled=true \
-Dcom.walmart.platform.metrics.log=true \
-Djsse.enableSNIExtension=true \
-Dserver.port=8090 \
-jar /opt/app/app.jar