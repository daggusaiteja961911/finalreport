#!/bin/sh
# blocks until kafka is reachable
kafka-topics --bootstrap-server kafka:29092 --list
echo -e 'Creating kafka topics'
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_notification_generic_dev --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_caas_budget_dev --replication-factor 1 --partitions 1

kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic mx-ewallet-cache --replication-factor 1 --partitions 1
#kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_notification_generic_dev --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic cashi-charge-outbound-event-qa --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic cashi-refund-outbound-event-qa --replication-factor 1 --partitions 1

kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_notification_status_change_stg --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_notification_status_change_dev --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_transaction_aggregator_dev --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic acc-orderprcsor-events-qa --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic mx_payments_refund_request_qa --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic pb_external_webhook_request --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_notification_generic_stg --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_caas_budget_dev --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_notification_reminder_dev --replication-factor 1 --partitions 1
kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic intlsap_digitalwallet_notification_service_qa --replication-factor 1 --partitions 1
echo -e 'Successfully created the following topics:'
kafka-topics --bootstrap-server kafka:29092 --list