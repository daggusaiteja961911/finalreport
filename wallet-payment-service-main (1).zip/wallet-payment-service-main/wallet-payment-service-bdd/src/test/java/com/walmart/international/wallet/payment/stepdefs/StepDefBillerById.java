package com.walmart.international.wallet.payment.stepdefs;

import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdResponse;
import com.walmart.international.wallet.payment.utils.CommonUtils;
import com.walmart.international.wallet.payment.utils.Constants;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;

import java.util.Map;
import java.util.UUID;

@Slf4j
public class StepDefBillerById {

    BillerByIdResponse response;

    Context ctx = new Context();

    public StepDefBillerById() {

    }

    public StepDefBillerById(Context context) {
        this.ctx = context;
    }

    @Given("Prepare Biller By Id API Request")
    public void prepareBillerByIdRequest() {
        CommonUtils.initializeApi(ctx);
    }

    @And("Set Path Param")
    public void setPathParamBillerId(Map<String, String> pathParam) {
        if (pathParam.containsKey("billerId")) {
            ctx.request.pathParam("billerId", pathParam.get("billerId"));
        }
    }

    @When("User fetch from Biller By Id API")
    public void userSubmitRequestToBillerByIDAPI() {
        ctx.response = ctx.request.get(Constants.GET_BILL_BY_ID);

        if (ctx.response.getStatusCode() >= 200 && ctx.response.getStatusCode() < 400) {
            response = ctx.response.getBody().as(BillerByIdResponse.class);
        }

        System.out.println(ctx.response.asPrettyString());
    }

    @Then("Verify API has return response {}")
    public void verifyHttpStatusResponse(String httpStatus) {
        Assert.assertEquals(httpStatus, String.valueOf(ctx.response.statusCode()));
    }

    @And("result map should have following Non null value")
    public void resultMapShouldHaveNonNullValues(Map<String, String> resultMap) {
        if (resultMap == null || resultMap.isEmpty()) return;

        Assert.assertNotNull(response);
        Assert.assertNotNull(response.getBillers());
        BillerByIdDTO biller = response.getBillers().get(0);
        Assert.assertNotNull(biller);

        if (resultMap.containsKey("billerId"))
            Assert.assertEquals(UUID.fromString(resultMap.get("billerId")), biller.getBillerId());

        if (resultMap.containsKey("processorBillerId"))
            Assert.assertEquals(resultMap.get("processorBillerId"),  biller.getProcessorBillerId());

        if (resultMap.containsKey("displayName"))
            Assert.assertEquals(resultMap.get("displayName"), biller.getDisplayName());

//        if (resultMap.containsKey("isNewBiller"))
//            Assert.assertEquals(Boolean.valueOf(resultMap.get("isNewBiller")), biller.getIsNewBiller());
//
//        if (resultMap.containsKey("isPopular"))
//            Assert.assertEquals(Boolean.valueOf(resultMap.get("isPopular")), biller.getIsPopular());
//
//        if (resultMap.containsKey("popularPriority"))
//            Assert.assertEquals(Integer.valueOf(resultMap.get("popularPriority")), biller.getPopularPriority());
//
//        if (resultMap.containsKey("imageURL"))
//            Assert.assertEquals(resultMap.get("imageURL"), biller.getImageURL());
    }

    @And("Status Code Should be {}")
    public void statusCodeInResponseBe(String statusCode) {
        Assert.assertEquals(statusCode, ctx.response.getBody().path("statusCode"));
    }

    @And("Status in Response should be {string}")
    public void statusInResponseBe(String status) {
        Assert.assertEquals(status, ctx.response.getBody().path("status"));
    }

    @And("Verify statusMessage as {}")
    public void verifyStatusMessageAsStatusMessage(String statusMessage) {
        Assert.assertEquals(statusMessage, ctx.response.getBody().path("statusMessage"));
    }

}
