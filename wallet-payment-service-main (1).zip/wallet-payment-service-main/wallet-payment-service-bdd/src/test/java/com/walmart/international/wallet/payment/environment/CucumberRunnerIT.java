package com.walmart.international.wallet.payment.environment;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import lombok.extern.slf4j.Slf4j;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@Slf4j
@CucumberOptions(
        features = {"src/test/java/com/walmart/international/wallet/payment/service/features"},
        glue = {"com/walmart/international/wallet/payment/app/impl/service/stepdefs"},
        plugin = {"pretty", "html:target/cucumber-reports/cucumber.html",
                "json:target/cucumber-reports/cucumber.json",
                "com.walmart.testburst.listener.cucumberListener"})
public class CucumberRunnerIT {

    @AfterClass
    public static void post() {
        log.info("stopping all containers after test execution");
        Environment.stopContainers();
    }
}
