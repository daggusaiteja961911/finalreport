package com.walmart.international.wallet.payment.stepdefs;

import com.walmart.international.wallet.payment.dto.response.billpay.GetPopularBillersBillerDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.PopularBillersResponse;
import com.walmart.international.wallet.payment.utils.CommonUtils;
import com.walmart.international.wallet.payment.utils.Constants;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.Assert;

import static org.hamcrest.MatcherAssert.assertThat;

@Slf4j
public class StepDefPopularBillers {

    Context ctx = new Context();

    public StepDefPopularBillers() {}
    private PopularBillersResponse response;

    public StepDefPopularBillers(Context context) {
        this.ctx = context;
    }

    @When("User Submit Request to Get Popular Billers API")
    public void userSubmitRequestToGetPopularBillersAPI() {
        CommonUtils.initializeApi(ctx);
        ctx.response = ctx.request.get(Constants.POPULAR_BILLER_API);
        if (ctx.response.getStatusCode() == 200) {
            response = ctx.response.getBody().as(PopularBillersResponse.class);
            log.info("Popular biller Response:: [{}]", ctx.response.asPrettyString());
        }
    }

    @Then("Verify Popular Billers API has return response {int}")
    public void verifyPopularBillersAPIHasReturnResponseStatusCode(int statusCode) {
        Assert.assertEquals(statusCode, ctx.response.statusCode());
    }

    @And("Verify Response has Return All popular billers {int}")
    public void verifyResponseHasReturnAllPopularBillers(int size) {
        Assert.assertEquals(response.getBillers().size(), size);
    }

    @And("Popular Billers Response should have Attributes with Not Null Value")
    public void popularBillersResponseShouldHaveAttributesWithNotNullValue() {
        for (GetPopularBillersBillerDTO biller : response.getBillers()) {
//            Assert.assertEquals(biller.getIsPopular(), true);
            assertThat(biller.getProcessorBillerId(), Matchers.notNullValue());
            assertThat(biller.getDisplayName(), Matchers.notNullValue());
            assertThat(biller.getIsNewBiller(), Matchers.notNullValue());
//            assertThat(biller.getPopularPriority(), Matchers.notNullValue());
        }
    }
}
