package com.walmart.international.wallet.payment.stepdefs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.utils.CommonUtils;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Objects;
import java.util.Map;
import java.util.UUID;

import static org.junit.Assert.assertEquals;


@Slf4j
public class StepDefUpdateCustomerBillAccount {

    private Context ctx = new Context();
    private UpdateCustomerBillAccountRequest request;
    private UpdateCustomerBillAccountRequest requestFromInputFile;
    ObjectMapper objectMapper = new ObjectMapper();


    @Given("Prepare BillDueDate Request from (.+)$")
    public void prepareBillDueDateRequestFromInputFile(String inputFile) throws IOException {

        request = CommonUtils.createRequestFromFileAndInitializeApi(objectMapper, UpdateCustomerBillAccountRequest.class,  requestFromInputFile, inputFile);
        CommonUtils.initializeApi(ctx);
    }

    @And("Update Request Parameter for BillDueDate")
    public void updateRequestParameterForBillDueDate(Map<String, String> params) {

        if (params.containsKey("customerBillAccountId")) {
            request.setCustomerBillAccountId(Objects.isNull(params.get("customerBillAccountId")) ? null : UUID.fromString(params.get("customerBillAccountId")));
        }
//        if (params.containsKey("billerId")) {
//            request.setBillerId(Objects.isNull(params.get("billerId")) ? null : UUID.fromString(params.get("billerId")));
//        }
//        if (params.containsKey("accountNumber")) {
//            request.setAccountNumber(Objects.isNull(params.get("accountNumber")) ? null : params.get("accountNumber"));
//        }
//        if (params.containsKey("dueDate")) {
//            if (("null").equals(params.get("dueDate"))) {
//                request.setDueDate(request.getDueDate());
//            } else
//                request.setDueDate(params.get("dueDate"));
//        }
//        if (params.containsKey("dueAmount")) {
//            request.setDueAmount(Objects.isNull(params.get("dueAmount")) ? null : BigDecimal.valueOf(Double.parseDouble(params.get("dueAmount"))));
//        }
    }

    @And("Update BillDueDate Header Value")
    public void updateBillDueDateHeaderValue(Map<String, String> headers) {
        ctx.request.headers(CommonUtils.createHeaders(headers));
    }

    @When("User Submit Request to BillDueDate API")
    public void userSubmitRequestToBillDueDateAPI() throws UnsupportedEncodingException {
        ctx.response = ctx.request.body(request)
                .post("/services/v1/bill-payment/bills/update");

    }

    @Then("Verify BillDueDate API has return response {int}")
    public void verify_api_has_return_response(int expectedStatusCode) {
        // Verify that the response status code matches the expected code
        assertEquals(expectedStatusCode, ctx.response.getStatusCode());
    }


    @And("BillDueDate Status should be {string}")
    public void billDueDateStatusShouldBe(String status) {
        assertEquals(status, ctx.getResponse().path("status"));
    }


    @And("Status Code in BillDueDate Response Should be {string}")
    public void statusCodeInBillDueDateResponseShouldBe(String statusCode) {
        assertEquals(statusCode, ctx.getResponse().path("statusCode"));
    }

    @And("Status Message in BillDueDate Response should be  {string}")
    public void statusMessageInBillDueDateResponseShouldBeMessage(String message) {
        assertEquals(message, ctx.getResponse().path("message"));
    }

    @And("Error Status Message in BillDueDate Response should be  {string}")
    public void errorStatusMessageInBillDueDateResponseShouldBeMessage(String statusMessage) {
        assertEquals(statusMessage, ctx.getResponse().path("statusMessage"));
    }
}
