package com.walmart.international.wallet.payment.environment;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import javax.sql.DataSource;

@TestConfiguration
@ComponentScan({"com.walmart.international.wallet.payment.service.stepdefs"})
public class TestJpaConfig {
    @Value("${db.username}")
    private String username;
    @Value("${db.password}")
    private String password;
    @Value("${db.name}")
    private String databaseName;

    @Bean
    public DataSource getDataSource() {
        DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
        dataSourceBuilder.url(Environment.getJdbcUrl() + databaseName + ";encrypt=true;trustServerCertificate=true;");
        dataSourceBuilder.username(username);
        dataSourceBuilder.password(password);
        return dataSourceBuilder.build();
    }

    @Bean
   // @DependsOn({"liquibase"})
    public static void initiateWPSAndDataIfNotExists(){
        if (!Environment.app.isCreated()){
            Environment.app.start();
            Environment.apiBaseUrl = "http://" + Environment.app.getHost() + ":8090";
        }
    }
}
