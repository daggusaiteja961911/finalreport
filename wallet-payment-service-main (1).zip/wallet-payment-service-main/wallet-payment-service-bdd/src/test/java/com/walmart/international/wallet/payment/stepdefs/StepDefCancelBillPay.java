package com.walmart.international.wallet.payment.stepdefs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.utils.CommonUtils;
import com.walmart.international.wallet.payment.utils.Constants;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testcontainers.shaded.com.google.common.base.Strings;
import org.testng.Assert;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

@Slf4j
public class StepDefCancelBillPay {

    CancelPayBillInitRequest request;

    Context ctx;

    @Autowired
    ObjectMapper objectMapper;

    public StepDefCancelBillPay(Context ctx) {
        this.ctx = ctx;
    }

    @Given("Prepare the Cancel Payment request from {string}")
    public void prepareTheCancelPaymentRequestFrom(String inputFile) throws IOException {
        if (!"null".equals(inputFile)) {
            request = CommonUtils.createRequestFromFileAndInitializeApi(objectMapper, CancelPayBillInitRequest.class, request, inputFile);
        } else {
            request = new CancelPayBillInitRequest();
        }
        CommonUtils.initializeApi(ctx);
    }

    @When("User Submit Request to validate Cancel Payment Bill Pay API")
    public void userSubmitRequestToValidateCancelPaymentBillPayAPI() {
        ctx.response = ctx.request.body(request).post(Constants.CANCEL_BILL_PAY);
        log.info("Response is : [{}]", ctx.response.asPrettyString());
    }

    @And("Response should have {string} and {string} values")
    public void responseShouldHaveAndValues(String state, String stateReason) {
        Map<String, Object> transaction = ctx.response.path("transaction");
        Assert.assertEquals(state, transaction.get("state"));
        Assert.assertEquals(stateReason, transaction.get("stateReason"));
    }

    @And("Update Request Parameter For Cancel Payment Bill Pay API")
    public void updateRequestParameterForCancelPaymentBillPayAPI(Map<String, String> params) {
        if (params.containsKey("transactionId")) {
            if (!Strings.isNullOrEmpty(params.get("transactionId")) &&
                    params.get("transactionId").equals("null")) {
                request.setTransactionId(null);
            } else {
                request.setTransactionId(UUID.fromString(params.get("transactionId")));
            }
        }
        if (params.containsKey("CustomerAccountId")) {
            if (!Strings.isNullOrEmpty(params.get("CustomerAccountId")) &&
                    params.get("CustomerAccountId").equals("null")) {
                request.setCustomerAccountId(null);
            } else {
                request.setCustomerAccountId(UUID.fromString(params.get("CustomerAccountId")));
            }
        }
    }

    @And("Response should have {string} {string} and {string}")
    public void responseShouldHaveAnd(String status, String statusMessage, String errorStatusCode) {
        Assert.assertEquals(status, ctx.response.path("status"));
        Assert.assertEquals(statusMessage, ctx.response.path("statusMessage"));
        Assert.assertTrue(ctx.response.path("statusCode").toString().contains(errorStatusCode));
    }

    @Then("Verify Cancel Payment API has return response {string}")
    public void verifyCancelPaymentAPIHasReturnResponse(String statusCode) {
        Assert.assertEquals(Integer.parseInt(statusCode), ctx.getResponse().getStatusCode());
    }

    @When("User Submit Empty Request to validate Cancel Payment Bill Pay API")
    public void userSubmitEmptyRequestToValidateCancelPaymentBillPayAPI() {
        ctx.response = ctx.request.post(Constants.CANCEL_BILL_PAY);
        log.info("Response is : [{}]", ctx.response.asPrettyString());
    }

    @And("Empty Response should have {string} {string} and {string}")
    public void emptyResponseShouldHaveAnd(String status, String statusMessage, String statusCode) {
        Assert.assertEquals(status, ctx.response.path("status"));
        Assert.assertEquals(statusCode, ctx.response.path("statusCode"));
        Assert.assertTrue(ctx.response.path("statusMessage").toString().contains(statusMessage));
    }
}
