package com.walmart.international.wallet.payment.stepdefs;

import com.walmart.international.wallet.payment.utils.CommonUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;

import static org.junit.Assert.assertEquals;

@Slf4j
public class StepDefBillerCategories {

    private Context ctx = new Context();

    @When("User Submit Request to BillerCategoryDTO API")
    public void userSubmitRequestToBillerCategoryAPI() {
        CommonUtils.initializeApi(ctx);
        ctx.response = ctx.request.get("/services/bill-payment/biller/categories");
        log.info("Response is : [{}]", ctx.response.asPrettyString());
    }

    @Then("Verify BillerCategoryDTO API has return response {int}")
    public void verifyBillerCategoryAPIHasReturnResponseHttpStatusCode(int expectedStatusCode) {
        assertEquals(expectedStatusCode, ctx.getResponse().getStatusCode());

    }

    @And("Status in BillerCategoryDTO Response should be {string}")
    public void statusInBillerCategoryResponseShouldBe(String status) {
        assertEquals(status, ctx.getResponse().path("status"));
    }

    @And("Status Code in BillerCategoryDTO Response Should be {string}")
    public void statusCodeInBillerCategoryResponseShouldBe(String statusCode) {
        assertEquals(statusCode, ctx.getResponse().path("statusCode"));
    }

    @And("Status Message in BillerCategoryDTO Response Should be {string}")
    public void statusMessageInBillerCategoryResponseShouldBe(String statusMessage) {
        assertEquals(statusMessage, ctx.getResponse().path("statusMessage"));
    }
}

