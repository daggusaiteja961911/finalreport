package com.walmart.international.wallet.payment.stepdefs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.wallet.payment.environment.Environment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Slf4j
public class StepDefLoadMoney {

    private static final String BASE_URL = Environment.getApiBaseUrl() + "/wallet-service";

    private Context ctx;

    private ObjectMapper mapper = new ObjectMapper();

    public StepDefLoadMoney(Context context) {
        this.ctx = context;
    }
}
