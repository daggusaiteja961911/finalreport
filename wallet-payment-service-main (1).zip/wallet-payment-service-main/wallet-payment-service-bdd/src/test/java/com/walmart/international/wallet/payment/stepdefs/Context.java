package com.walmart.international.wallet.payment.stepdefs;

import io.cucumber.spring.CucumberTestContext;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.Data;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Data
@Component
@Scope(CucumberTestContext.SCOPE_CUCUMBER_GLUE)
public class Context {

    public RequestSpecification request;
    public Response response;
}
